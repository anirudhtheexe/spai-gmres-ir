# SPAI-GMRES-IR

Sparse linear-system solvers for CPU and NVIDIA CUDA, with separate FP32 and
FP64 implementations. The solver combines an adaptive sparse approximate
inverse (SPAI), left-preconditioned GMRES, and iterative refinement.

## Requirements

- CMake 3.18 or newer and a C++11 compiler.
- Python 3.10 or newer for the independent numerical checks.
- For GPU execution: a compatible NVIDIA GPU, CUDA Toolkit, 64-bit host compiler,
  cuBLAS, cuSPARSE, and cuSOLVER.

Tested with GCC 6.3, MSVC 19.44, CUDA 13.4, CMake 3.31, and an RTX 4060 Laptop
GPU (CUDA architecture 89).

## Build and test

CPU with GCC or Clang:

```sh
cmake -S . -B build/cpu -DCMAKE_BUILD_TYPE=Debug
cmake --build build/cpu
ctest --test-dir build/cpu --output-on-failure
```

CUDA, from an environment with a supported host compiler:

```sh
cmake -S cuda -B build/cuda -DCMAKE_BUILD_TYPE=Debug -DCMAKE_CUDA_ARCHITECTURES=89
cmake --build build/cuda
ctest --test-dir build/cuda --output-on-failure
```

Replace `89` with the architecture of the target GPU. On Windows, the provided
script locates Visual Studio C++ Build Tools and its CMake/Ninja installation:

```bat
scripts\build_windows.cmd cpu
scripts\build_windows.cmd cuda 89
```

Set `CUDA_PATH` to the toolkit directory. Windows output directories are
`build/cpu-Debug` and `build/cuda-Debug/solver`. An optional third argument selects
`Release`. The default architecture argument, `native`, requires CMake 3.24+.

MSVC has no wider-than-double `long double`, which three original CPU numerical
tests require. The Windows CPU script therefore runs the two compatible suites
and an independent 80-digit Decimal check. All five CPU suites can be run with
a compiler providing the wider type. Details are in the validation section below.

The root build also accepts `-DBSPAI_ENABLE_CUDA=ON` for both backends in one
build tree. Use `-DBUILD_TESTING=OFF` for libraries and programs only.
Set `CUBLAS_EMULATE_DOUBLE_PRECISION=0` for CUDA FP64 execution.

## Run

Each program accepts:

```text
PROGRAM MATRIX.mtx [epsilon=0.3] [outercap=20] [innercap=0]
```

The input must be a nonempty square real matrix in Matrix Market coordinate
format. The RHS uses equal components with unit 2-norm. An inner cap of zero
selects the matrix dimension. For the included test matrix, use epsilon `0.5`:

```sh
build/cpu/cpu_fp32_ir tests/fixtures/tiny_nonsymmetric.mtx 0.5
build/cpu/cpu_fp64_ir tests/fixtures/tiny_nonsymmetric.mtx 0.5
build/cuda/solver/gpu_fp32_ir tests/fixtures/tiny_nonsymmetric.mtx 0.5
build/cuda/solver/gpu_fp64_ir tests/fixtures/tiny_nonsymmetric.mtx 0.5
```

Append `.exe` on Windows and use the corresponding output directories above.
Exit codes are 0 for convergence, 1 for construction/solver failure, and 2 for
invalid input. FP32 input is parsed using the shared Matrix Market reader and
then rounded to float; overflow and nonzero entries that round to zero are rejected.

## Layout

| Directory | Contents |
| --- | --- |
| `src/`, `include/bspai/` | CPU/CUDA implementations and public interfaces |
| `cmake/`, `cuda/` | CUDA build definitions and standalone entry point |
| `tests/` | Component tests, numerical checkers, and small matrix fixture |
| `scripts/` | Windows build helpers |
| `docs/` | Method, validation, and references |

The GPU outer refinement loop runs on the CPU. The implementations use uniform
FP32 or FP64; bucketed SPAI and mixed-precision refinement are not implemented.
The methodology, validation details, and references follow below.


## Methodology

Given a sparse real square matrix A, the objective is to solve A*x=b. Separate
implementations use binary32 or binary64 arithmetic throughout the solver.

### Sparse approximate inverse

Scale rows by d[k]=1/max_j(abs(A[k,j])) and define D=diag(d), B=A^T*D.
For each column k, start with the identity pattern J={k} and collect the shadow
rows I touched by the selected columns. Solve

```text
min_m ||B(I,J)*m - e_k(I)||_2
```

using unpivoted Householder QR and a triangular solve. Normal equations are not
used. Accept a fit when its residual norm is at most epsilon. Otherwise, form
the restricted candidate set from the shadow support, excluding the current
pattern. For each candidate j, evaluate

```text
rho_j^2 = ||s||_2^2 - (s^T*B(I,j))^2 / ||B(I,j)||_2^2
```

Select at most beta candidates whose scores do not exceed the candidate mean,
ordered by score and then index. Refit after each growth. Alpha bounds completed
growth/refit events, allowing an initial fit plus at most alpha refits.

Assemble the fitted columns into N and form P=N^T*D. The CLI defaults are
epsilon=0.3, beta=8, and alpha=ceil(n/8). Zero diagonal/row, nonfinite values,
exact-zero computed QR pivots, invalid scores, and exhausted growth are reported
explicitly. Small negative score radicands may be clamped only within the
specified rounding bound 32*u*(||s||_2^2+abs(q)), with
q=(s^T*B(I,j))^2/||B(I,j)||_2^2 and precision-specific unit roundoff u.

### GMRES and iterative refinement

GMRES applies the left-preconditioned operator as P*(A*v), without forming P*A.
It uses unrestarted Arnoldi, one modified Gram-Schmidt pass, and Givens rotations.
Convergence requires a recomputed relative preconditioned residual, rather than
only the Hessenberg residual estimate. The default tolerance is 1e-8 in FP64
and 1e-4 in FP32; the iteration cap defaults to n.

Refinement starts with x0=P*b. Each outer step computes r=b-A*x, solves the
correction equation with zero initial correction, and updates x only after an
accepted inner solve. The stopping quantity is normwise backward error:

```text
eta = ||b-A*x||_inf / (||A||_inf*||x||_inf + ||b||_inf)
```

The target is 10*2^-53 in FP64 and 10*2^-24 in FP32, with at most 20 outer
corrections. Stagnation and failed corrections remain explicit failures.

### CUDA implementation

CUDA SpMV uses cuSPARSE. GPU SPAI uses sparse storage, compact per-fit workspaces,
cuSOLVER QR, and GPU residual/scoring and preconditioner assembly. Pattern
management and adaptive decisions remain host controlled. GMRES vectors and
Krylov workspaces reside on the GPU; the outer refinement loop is CPU staged.
The FP32 SPAI translation unit specializes the shared CUDA construction body,
keeping both precisions on the same sparse-storage and scheduling flow.

### Scope and limitations

The paper-based SPAI/GMRES/IR workflow is adapted to uniform working precision;
this is not a reproduction of the published mixed-precision experiments.
Bucketed SPAI is not implemented. CPU/GPU floating-point order can produce
different patterns near score ties and different failure statuses on singular
inputs. Successful SPAI construction does not certify nonsingularity of P.
FP32 duplicate summation retains its existing sort order, and GPU FP32 SPAI
exposes only the last fit's score records with coarser failure statuses.
Unrestarted GMRES history and dense pattern growth can require substantial
memory. Correctness results apply to the documented tested cases.


## Validation

The code is checked using component regressions, CPU/GPU comparisons, exact-bit
snapshots, and independent 80-digit Decimal reconstruction. The checkers are
external to the solver and never supply values back to it.

### Recorded checks

| Check | Result |
| --- | --- |
| GCC CPU regression suites | 5/5 passed |
| MSVC/CUDA regression suites | 8/8 passed |
| Exact-bit CPU snapshot checks, GCC and MSVC | 16 snapshots, 500 checks each; zero failures |
| GPU SPAI Decimal80 checks | 60 fits, 436 checks; zero failures |
| GPU GMRES Decimal80 checks | 48 solver snapshots, 383 checks, 125 norm snapshots; zero failures |
| GPU IR Decimal80 checks | 21 snapshots, 160 checks; zero failures |
| Four solver CLI checks | 32 checks; zero failures |
| CPU/CUDA builds with testing disabled | Passed, zero tests configured |

The small deterministic fixture is `tests/fixtures/tiny_nonsymmetric.mtx`.
With epsilon 0.5, independent final backward errors were approximately
4.35e-8 (CPU FP32), 5.40e-17 (CPU FP64), 1.45e-8 (GPU FP32), and 2.03e-17
(GPU FP64), below the corresponding refinement thresholds. These are
correctness checks, not performance measurements or universal accuracy bounds.

Recorded environment: Windows x64; GCC 6.3 (32-bit), MSVC 19.44.35228, CUDA
13.4.59, CMake 3.31, Ninja, Python 3.12, and RTX 4060 Laptop GPU, architecture 89.

### Reproduce

Run CTest using the commands in the root README. For an independent CPU check:

```sh
python tests/check_release_cpu_decimal.py build/cpu/cpu_release_snapshot
```

For a standalone CUDA build:

```sh
python tests/check_cuda_spai_decimal.py build/cuda/solver/cuda_spai_tests
python tests/check_cuda_gmres_decimal.py build/cuda/solver/cuda_gmres_tests
python tests/check_cuda_ir_decimal.py build/cuda/solver/cuda_ir_tests
python tests/check_solver_cli.py build/cpu/cpu_fp32_ir build/cpu/cpu_fp64_ir build/cuda/solver/gpu_fp32_ir build/cuda/solver/gpu_fp64_ir
```

Append `.exe` on Windows and adjust paths to the configured build directory.
The Windows helpers default to `build/cpu-Debug` and `build/cuda-Debug/solver`.

MSVC's `long double` has the same precision as `double`. The three original
FP64 CPU SPAI/GMRES/IR suites require a wider reference type; the Windows CPU
helper runs the two compatible suites plus Decimal80 checks. All five original
CPU suites were checked with GCC. This distinction must be retained when
reporting results.

Tests include nonfinite sparse-vector inputs, output overflow, dimension-range
checks, convergence/failure paths, and reference numerical reconstruction.
The frozen dense CUDA constructor under `tests/reference/` is used only for
regression comparison and is not a production fallback.


## References

The SPAI-preconditioned iterative-refinement workflow is based on the following
literature. The uniform FP32/FP64 configurations, explicit exceptional-case
rules, and CUDA implementation are project implementation choices.

1. E. Carson and N. Khan, "Mixed Precision Iterative Refinement with Sparse
   Approximate Inverse Preconditioning," 2023.
   [DOI: 10.1137/22M1487709](https://doi.org/10.1137/22M1487709).
2. N. Khan and E. Carson, "Mixed Precision Iterative Refinement with Adaptive
   Precision Sparse Approximate Inverse Preconditioning," 2025.
   [DOI: 10.1007/s00366-025-02187-z](https://doi.org/10.1007/s00366-025-02187-z).
   This provides related BSPAI context; bucketing is not implemented here.
3. M. J. Grote and T. Huckle, "Parallel Preconditioning with Sparse Approximate
   Inverses," 1997.
   [DOI: 10.1137/S1064827594276552](https://doi.org/10.1137/S1064827594276552).
4. Y. Saad and M. H. Schultz, "GMRES: A Generalized Minimal Residual Algorithm
   for Solving Nonsymmetric Linear Systems," 1986.
   [DOI: 10.1137/0907058](https://doi.org/10.1137/0907058).

Related reference code:
[SPAI-GMRES-IR](https://github.com/Noaman67khan/SPAI-GMRES-IR) and
[ADAP-SPAI-GMRES-IR](https://github.com/Noaman67khan/ADAP-SPAI-GMRES-IR).
