# Reference handling

The project index supplies DOI and URL candidates, but all entries remain marked
review-pending. A verified BibTeX file should be added here only after lawful
full-text/metadata verification in ChatGPT Work.
