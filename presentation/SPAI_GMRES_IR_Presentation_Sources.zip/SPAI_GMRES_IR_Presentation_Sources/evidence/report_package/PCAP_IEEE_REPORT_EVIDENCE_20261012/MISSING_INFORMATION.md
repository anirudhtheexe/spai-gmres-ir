# Missing information and uncertainty

- CPU model, physical host RAM, exact Windows build, and host thermals are not reliably recorded.
- No genuine terminal or Nsight screenshots are present.
- PAPER_INDEX metadata is indexed but all full-text review statuses are pending; verify metadata and references before publication.
- Pre/post profiles were not back-to-back controlled traces; API-time differences beyond call counts are supporting evidence only.
- Historical FP32 timing outliers were not causally attributed.
- Native CPU/GPU pipeline rows can construct different P and are not equal-work comparisons.
- FP64 CPU Release CTest retains the documented wider-oracle 1/4 limitation; timing remains exploratory.
- Results establish bounded tested cases, not universal scaling, memory, overlap, or GPU-superiority claims.
- BSPAI, mixed precision, additional GPU architecture optimization, and RTX 4080 evidence are absent by scope.
- Final IEEE formatting, publication bibliography verification, and manual screenshots remain ChatGPT Work tasks.
