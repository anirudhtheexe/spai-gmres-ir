# Verified algorithm pseudocode

## Scaling and preconditioner

```text
for each row k:
    d[k] = 1 / max(abs(A[k,j]))
B = transpose(A) * diag(d)
for each column k of N:
    J = {k}
    repeat:
        shadow = transpose-structure rows reached by J
        M = B[shadow,J]
        [Q,R] = HouseholderQR(M)
        if any computed R diagonal is exactly zero: return rank/breakdown status
        c = triangular_solve(R, Q^T * e_k[shadow])
        rho = restricted/full fitted residual diagnostics
        candidates = restricted frontier candidates
        scores = GPU residual/score evaluation
        host sorts and applies mean/filter/tie rules
        accept selected candidates or stop on epsilon/no-growth/alpha
    store c in sparse N column k
P = transpose(N) * diag(d)
```

## Left-preconditioned GMRES

```text
r0 = rhs - A*x0
z0 = P*r0; beta = norm(z0)
v0 = z0/beta
for k = 0 .. cap-1:
    w = P*(A*v[k])
    one-pass MGS: h[i,k] = dot(v[i],w); w -= h[i,k]*v[i]
    h[k+1,k] = norm(w); v[k+1] = w/h[k+1,k] unless breakdown
    apply prior Givens rotations; form new Givens rotation
    update projected RHS and residual estimate
    y = triangular/projected least-squares solution
    candidate = x0 + V[k]*y       # immutable x0
    recompute original and preconditioned residuals
    accept if preconditioned relative residual <= tolerance
```

The method is unrestarted and uses one-pass MGS, Givens rotations, exact-zero
breakdown semantics, and a cap no larger than the dimension.

## Outer refinement

```text
x = P*b
for outer = 0 .. 20:
    diagnostics = {r=b-A*x, normwise backward error, forward diagnostic}
    append diagnostics to outer history
    if BE <= 10*2^-24 (FP32) or 10*2^-53 (FP64): success
    delta = GMRES(A,P,r,zero initial correction)
    if delta fails: inner failure
    x = x + delta; append inner history
    if stagnates: stagnation
return iteration limit if cap exhausted
```

## CUDA scheduling pseudocode

```text
create bounded stream slots and slot-owned device/host buffers
for a batch of independent columns:
    enqueue pattern, shadow, candidate H2D copies on slot streams
    enqueue gather, QR, ormqr, and QR-info D2H
wait for QR-info before triangular solves
enqueue triangular solve, residual, scoring, and fit-result D2H
wait once for fit outputs; host accepts/rejects
if growth is needed:
    enqueue score/status/clamp D2H and wait once
    host selects ordered candidates and schedules next fit
assemble compact P and return telemetry
```

This scheduling is an implementation detail of the mathematical algorithm; it is
not BSPAI bucketing and does not change precision or stopping policy.
