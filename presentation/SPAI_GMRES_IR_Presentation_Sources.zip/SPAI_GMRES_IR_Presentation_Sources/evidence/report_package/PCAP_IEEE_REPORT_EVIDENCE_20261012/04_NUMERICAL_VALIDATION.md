# Numerical validation

## Acceptance contracts

FP32 uses uniform `float`, GMRES tolerance `1e-4`, and original-system backward
error `10*2^-24`. FP64 uses uniform `double`, fixed-P tolerance `1e-8` in the
timing harness, and original-system backward error `10*2^-53`. Decimal80
sidecars independently recompute stored snapshots; an executable exit code alone
is not treated as numerical acceptance.

## FP32 12k saved snapshots

| Matrix | CPU/GPU status | P nnz | fits/growths | outer corrections | inner iterations CPU/GPU | Decimal80 BE CPU/GPU | forward error CPU/GPU |
|---|---|---:|---:|---:|---|---|---|
| stencil_12000 | success/success | 59,205 | 23,881 / 11,881 | 2 | [7,9] / [7,8] | 6.0444139102e-8 / 6.0444141673e-8 | 6.7741461228e-8 / 5.5708031817e-8 |
| irregular_12000 | success/success | 17,379 | 13,386 / 1,386 | 2 | [8,9] / [8,9] | 6.9323122592e-8 / 6.8822746793e-8 | 6.7519680274e-8 / 6.6022270238e-8 |

Both matrices have zero CPU/GPU preconditioner pattern symmetric difference. The
rounded-system and original-input Decimal80 BEs coincide for these dyadic inputs
and are below `5.9604644775e-7`. Source artifacts:
`results/experiment2a_fp32_12000_stencil_20261012.jsonl`,
`results/experiment2a_fp32_12000_irregular_20261012.jsonl`, and the corresponding
records in `docs/EXPERIMENT2A_LIVE_HANDOFF.md`.

## FP32 4096 corrective snapshot

The persisted corrective snapshot is
`results/experiment2a_fp32_4096_corrective_20261012.jsonl`. CPU and GPU both
reported success, P nnz `20,037`, `8,129` fits, `4,033` growths, two outer
corrections, inner iterations `[7,9]`, and pattern difference zero. The
snapshot-only Decimal80 checker reported zero failures. CPU BE/forward error were
`6.0444141672525308e-8` / `9.2671429479373057e-8`; GPU values were
`5.2608789974234991e-8` / `6.4175498968438337e-8`. Rounded-system and original
input BEs coincide for this dyadic stencil. The historical pre-corrective
stdout-truncation paragraph in `docs/PHASE2B_VALIDATION_RECORD.md` is superseded
by the live/project handoff and this persisted snapshot; it should be reconciled
before publication. No standalone Decimal80 sidecar was retained for this 4096
snapshot, so the checker result and raw snapshot are the direct evidence.

## FP32/FP64 timing-campaign correctness

The complete four-matrix timing campaign retained 48 configurations and 288
records: three warm-ups and three measured trials each. All solver children and
all 48 snapshot-only Decimal80 sidecars returned zero; all configurations were
accepted. Construction counts were stable per matrix: stencil_8192 P nnz 40,197,
16,257 fits, 8,065 growths; irregular_8192 11,870 / 9,139 / 947;
stencil_12000 59,205 / 23,881 / 11,881; irregular_12000 17,379 / 13,386 / 1,386.
All native pipelines completed two outer corrections. Source report:
`EXPERIMENT2A_FP32_VS_FP64_TIMING.md`.

## Regression evidence

Focused post-optimization tests passed: FP32 SpMV, FP32 GMRES, FP32 SPAI, FP64
SPAI, and FP64 sparse SPAI (3,363,954 checks, zero failures). The complete
records and commands are in `docs/PHASE2B_VALIDATION_RECORD.md` and the live
handoff. No new tests were run for this package.

## Interpretation

These are saved-snapshot acceptance results on frozen matrices. They establish
the recorded implementation's correctness for these cases, not universal
scalability, arbitrary-fill memory bounds, or a mixed-precision algorithm.
