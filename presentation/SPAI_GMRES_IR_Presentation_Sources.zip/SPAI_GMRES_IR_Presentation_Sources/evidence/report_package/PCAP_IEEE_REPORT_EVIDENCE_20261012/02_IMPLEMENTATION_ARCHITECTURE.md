# Implementation architecture

## Components

| Component | Implementation | Responsibility |
|---|---|---|
| CSR/reference core | `include/bspai/spai.hpp`, `src/cpu.cpp`, `src/spai.cpp` | binary64 CSR, CPU SPAI and diagnostics |
| FP32 core | `include/bspai/fp32.hpp`, `src/fp32_cpu.cpp` | uniform-float CSR, SPAI, GMRES/IR reference |
| FP64 GPU SPAI | `include/bspai/cuda_spai.hpp`, `src/cuda_spai.cu` | CUDA QR/residual/scoring, sparse P assembly |
| FP32 GPU SPAI | `include/bspai/fp32_cuda_spai.hpp`, `src/fp32_cuda_spai.cu` | separate public float API over float-specialized constructor |
| FP64 GPU GMRES/IR | `include/bspai/cuda_gmres.hpp`, `src/cuda_gmres.cu`, `src/cuda_ir.cpp` | GPU inner solve and CPU-staged outer refinement |
| FP32 GPU GMRES/IR | `include/bspai/fp32_cuda_gmres.hpp`, `src/fp32_cuda_gmres.cu` | uniform-float GPU inner solve and outer history |
| Build/test topology | `cuda/CMakeLists.txt`, root `CMakeLists.txt`, `tests/` | isolated CUDA and CPU targets |

## GPU SPAI dataflow

The constructor creates bounded stream slots. Each slot owns reduced QR buffers,
workspace, candidate vectors, and host metadata. For each batch, host code builds
pattern/shadow/candidate metadata, queues H2D copies, launches gather and QR, and
collects the QR `info` before any triangular solve. Device work uses cuSOLVER
Householder QR (`cusolverDnD/Sgeqrf`, `cusolverDnD/Sormqr`) and cuBLAS
triangular solves (`cublasD/Strsv`); residual and scoring kernels stay on device.
Coefficients, diagnostics, and statuses return to host for acceptance and growth.
Final sparse `P` is assembled compactly and made available to the GMRES/IR layer.

The design is hybrid: independent column fits can be submitted across bounded
streams, but pattern discovery, sorting, means, tie ordering, adaptive choices,
and final scheduling remain host-controlled. GPU allocation telemetry is
source-owned and excludes vendor-internal allocator state.

## Synchronization batching

The adaptive-fit optimization queues the three metadata uploads and performs one
completion at their unchanged consumer boundary. It similarly groups fit-result
and score-result D2H copies. QR `info` collection remains a mandatory separate
boundary. Copy ordering, bytes, host lifetimes, candidate decisions, and floating
point operations are unchanged. The observed stencil_8192 traces reduced
`cudaStreamSynchronize` calls from 373,606 to 130,126 while retaining 276,008
async copies and 357,658 kernel launches.

## Error handling and diagnostics

Invalid dimensions, nonfinite arithmetic, zero diagonal/scaling failures, exact
zero QR pivots, empty candidates, no growth, iteration limits, breakdown, and
nonconvergence are explicit statuses. Results include construction counts,
residuals, histories, backward errors, forward diagnostics, pattern checks, and
telemetry. No CPU fallback is used by the FP32 GPU constructor path.
