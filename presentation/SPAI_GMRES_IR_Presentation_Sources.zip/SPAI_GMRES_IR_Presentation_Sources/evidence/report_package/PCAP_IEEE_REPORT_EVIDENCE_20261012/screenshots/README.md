# Screenshots

No genuine screenshots were available in the repository at packaging time. See
the package-root `SCREENSHOT_REQUIREMENTS.md`; do not add fabricated images.
