# Screenshot requirements

No genuine screenshots were found in the retained repository evidence. Do not
fabricate them. Capture manually later, if required:

| Screenshot | Source command/artifact | Required caption |
|---|---|---|
| focused FP32/FP64 regression terminal | commands recorded in `docs/PHASE2B_VALIDATION_RECORD.md` | Focused CUDA numerical regression gate |
| Decimal80 acceptance terminal | saved checker sidecars and checker command | Independent saved-snapshot verification |
| Nsight API summary | retained `stats_cuda_api_sum.csv` beside each profile | Pre/post CUDA API call counts |
| Nsight timeline | retained `.nsys-rep` profile | Two-construction adaptive-fit trace |
| repository architecture | `figures/architecture.svg` in this package | Implemented uniform-precision SPAI–GMRES–IR dataflow |
