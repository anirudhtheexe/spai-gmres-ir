# Performance analysis and limits

## Evidence

Nsight shows 276,008 asynchronous copies, 357,658 kernel launches, and 373,606
stream synchronizations in the pre-batching traces. FP32 kernels were not slower
than FP64 in the retained diagnostic profile; the dominant bounded cost is the
large number of tiny API operations and host synchronization boundaries. Batching
safe same-stream copy groups reduced synchronization calls to 130,126 without
changing copy/launch counts or numerical work.

## Interpretation

GPU SPAI is not consistently faster than CPU SPAI because the current constructor
keeps pattern discovery, sorting, tie rules, adaptive decisions, and much of
orchestration on the host while issuing many small transfers and launches. FP32
arithmetic alone therefore cannot guarantee lower wall time than FP64 or CPU.
The full pipeline also includes GMRES/IR work, so a constructor improvement need
not produce the same end-to-end change. This is visible in the mixed FP32 pipeline
results (stencil improvements, irregular regressions) despite uniformly improved
isolated FP32 constructors.

The before/after profiles were not captured back-to-back in one controlled
profiling session. Their robust conclusion is the exact call-count reduction and
unchanged numerical work; small API-time and kernel-time differences are not
claimed as causal speedups. The timing campaigns are machine-specific medians,
not a general parallel efficiency or scalability result. No CUDA-core-count
efficiency was calculated.

## What is not established

The evidence does not establish universal linear memory growth, hardware overlap,
GPU superiority, a published-method reproduction, BSPAI behavior, mixed
precision, or RTX 4080 performance. It also does not prove that packing every
remaining score/status/clamp transfer is safe; that is a future proposal requiring
new validation, not completed work.
