# Literature and references

`PAPER_INDEX.md` is the authoritative project index. It records metadata, links,
access labels, and the fact that every entry is **Not yet reviewed in Codex**.
The report must therefore describe these as indexed prior work, not as
independently verified full-text implementation facts.

| Reference | Year | Relevance | Metadata status |
|---|---:|---|---|
| Erin Carson, Noaman Khan, *Mixed Precision Iterative Refinement with Sparse Approximate Inverse Preconditioning* | 2023 | SPAI–GMRES–IR baseline | indexed; DOI/arXiv listed; full-text review pending |
| Noaman Khan, Erin Carson, *Mixed Precision Iterative Refinement with Adaptive Precision Sparse Approximate Inverse Preconditioning* | 2025 | BSPAI–GMRES–IR context | indexed; DOI/arXiv listed; full-text review pending |
| Youcef Saad, Martin H. Schultz, *GMRES: A Generalized Minimal Residual Algorithm for Solving Nonsymmetric Linear Systems* | 1986 | GMRES foundation | indexed; DOI listed; full-text review pending |
| Marcus J. Grote, Thomas Huckle, *Parallel Preconditioning with Sparse Approximate Inverses* | 1997 | SPAI/parallel foundation | indexed; DOI/public PDF listed; review pending |
| Jiaquan Gao et al., *A Thread-Adaptive Sparse Approximate Inverse Preconditioning Algorithm on Multi-GPUs* | 2021 | GPU SPAI prior art | indexed; access uncertain; review pending |
| Yizhou Wang et al., *A Parallel Sparse Approximate Inverse Preconditioning Algorithm Based on MPI and CUDA* | 2021 | MPI/CUDA SPAI prior art | indexed; open PDF listed; review pending |
| Erin Carson, Nicholas J. Higham, *Accelerating the Solution of Linear Systems by Iterative Refinement in Three Precisions* | 2018 | iterative refinement foundation | indexed; DOI listed; review pending |

Additional indexed GPU GMRES/SpMV and adaptive-precision papers are listed in
`PAPER_INDEX.md`; no claim about their algorithms or results is made here beyond
the relevance labels in that file. The implemented project contribution should be
described as a uniform-FP32/FP64 CUDA implementation, sparse GPU-SPAI integration,
validation, and measured synchronization batching—not as a novel BSPAI method.
