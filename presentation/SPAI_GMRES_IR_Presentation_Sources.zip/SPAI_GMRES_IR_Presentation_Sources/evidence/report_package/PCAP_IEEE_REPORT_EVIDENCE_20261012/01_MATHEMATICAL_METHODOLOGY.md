# Mathematical methodology

## Problem and scaling

The implementation solves a nonsymmetric sparse system `A x = b`. For each row
`k`, it computes `d[k] = 1 / max_j |A[k,j]|` (requiring a nonzero diagonal and
nonzero row maximum), forms `B = A^T D`, and constructs an approximate inverse
`N` for `B`. The returned preconditioner is `P = N^T D`. Thus scaling is part of
the preconditioner, not an external change to the original system. This contract
is specified in `docs/PHASE2A_ALGORITHM_SPEC.md`; FP64 source is
`src/spai.cpp`, GPU source `src/cuda_spai.cu`, and FP32 source
`src/fp32_cpu.cpp`/`src/fp32_cuda_spai.cu`.

## Adaptive SPAI construction

Each column `k` is an independent restricted least-squares problem. Its initial
pattern is `{k}`. The shadow row is the union of row indices reached through the
transpose structure for the current pattern. The restricted matrix is assembled
from `B` on that shadow and pattern. Householder QR factors the restricted matrix;
the triangular solve is rejected on an exactly-zero computed QR diagonal. The
fitted residual is evaluated on the restricted system and the full residual is
used for diagnostics.

Candidates are discovered from the current shadow/frontier. GPU residual and score
kernels evaluate candidates; host code performs sorting, mean/filter/tie ordering,
acceptance, and adaptive scheduling. A candidate is accepted only when its score
passes the frozen precision-specific guard and improves the documented criterion.
Growth stops on the epsilon criterion, no-growth/empty-candidate status, or the
alpha growth limit. `beta=8` bounds candidate growth. The final column coefficients
are packed into sparse `N`, then assembled as compact sparse `P=N^T D`.

Frozen Experiment 2A settings are epsilon `0.3`, beta `8`, and alpha `ceil(n/8)`
for FP32 correctness fixtures (alpha `512` at n=4096 and `1500` at n=12000);
the timing harness uses the frozen per-case options recorded in its manifests.
FP32 arithmetic, diagnostics, score guard, and storage use `float`; the FP32 guard
is `32*2^-24`. FP64 uses binary64 and the corresponding `2^-53` policy. Neither
implementation is mixed precision.

## Left-preconditioned GMRES

The GPU solver applies the operator `P(A v)` without forming `P A`. The initial
guess is supplied by the caller (or zero for a correction solve), and the initial
residual is formed and preconditioned. Arnoldi uses one-pass modified
Gram–Schmidt, followed by Givens rotations and a projected least-squares solve.
The implementation is unrestarted; the iteration cap is at most `n` under the
frozen contract. The FP32 GMRES acceptance tolerance is `1e-4`; FP64 fixed-P
timing uses `1e-8`. Every projected candidate is formed from immutable `x0` plus
the current Krylov combination (`src/fp32_cuda_gmres.cu`, candidate block around
the `dinitial` copy), preventing accumulated-correction error.

## Iterative refinement

The outer method starts with `x0=P b`, computes `r=b-Ax`, and evaluates the
normwise backward error against the original system. If the frozen threshold is
not met, GPU GMRES solves the correction equation with the same `P`, the solution
is updated, and diagnostics are recomputed. FP32 accepts at `10*2^-24 =
5.9604644775390625e-7`; FP64 accepts at `10*2^-53`. The outer cap is 20 and the
pipeline records histories, inner statuses, residuals, and forward diagnostics
when a manufactured reference is available. CUDA SpMV/GMRES is GPU-executed;
outer residual evaluation, acceptance, update bookkeeping, and adaptive SPAI
decisions are host-controlled in the current design.

Supporting specifications: `docs/PHASE2A_ALGORITHM_SPEC.md`,
`docs/EXPERIMENT2A_FP32_SPEC.md`; implementation entry points include
`fp32_construct_spai`, `fp32_cuda_construct_spai`,
`fp32_cuda_left_preconditioned_gmres`, `fp32_cuda_refine_with_preconditioner`,
`cuda_construct_spai`, `cuda_refine_with_preconditioner`, and
`cuda_gpu_spai_gmres_ir`.
