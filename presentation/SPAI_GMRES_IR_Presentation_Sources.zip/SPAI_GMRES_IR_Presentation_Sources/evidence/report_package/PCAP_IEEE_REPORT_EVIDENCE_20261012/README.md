# PCAP IEEE report evidence package

This package is a compact, source-traceable evidence set for the final report.
It describes only the completed uniform-FP32 and uniform-FP64 SPAI–GMRES–IR
implementation and retained RTX 4060 experiments. BSPAI, mixed precision, new
architecture proposals, and RTX 4080 results are explicitly out of scope.

Use the numbered Markdown files as report-source material, the CSV files under
`tables/` as machine-readable values, and the SVGs under `figures/` as
publication-ready derived figures. `EVIDENCE_REGISTER.csv` maps claims to source
paths/functions/JSON records. Raw JSONL, Decimal80 sidecars, `.nsys-rep`, SQLite,
build directories, and full result trees remain in the repository and are not
duplicated here.

## Verification summary

- No solver, CUDA test, benchmark, profiler, or experiment was run to create this package.
- All numerical values were transcribed from existing reports or saved artifacts.
- Performance tables distinguish the original timing campaign from adaptive-batching results.
- Speedups in `tables/gpu_spai_medians.csv` and `tables/baseline_cpu_gpu.csv` are arithmetic derivations from the cited medians.
- The package contains no genuine execution screenshots; see `SCREENSHOT_REQUIREMENTS.md`.
- Literature metadata and full-text review status are inherited from `PAPER_INDEX.md`; all entries remain marked not yet reviewed in Codex.
- Unsupported claims, missing hardware data, and timing limitations are listed in `MISSING_INFORMATION.md`.

## Suggested report use

Read `01`–`03` for the implemented method, `04` for correctness, `05`–`06`
for measured performance and its interpretation, `07`–`08` for literature and
contributions, and `09` for reproducibility. Do not convert exploratory timings
into universal speedup claims.
