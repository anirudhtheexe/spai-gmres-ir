# Experimental setup

## Recorded environment

The handoff records an NVIDIA RTX 4060 Laptop GPU, compute capability 8.9, 8,188
MiB; NVIDIA driver 616.92; CUDA Toolkit/nvcc 13.4.59; cuSPARSE 12.8.6; cuBLAS
13.7.0; cuSOLVER 12.3.2; MSVC 19.44.35228; CMake 3.31.6-msvc6; Ninja 1.12.1;
Python 3.12; Windows x64; CUDA architecture 89. CPU model, host RAM, and OS
build number are not reliably recorded and must not be invented.

## Inputs and procedure

Frozen matrices are deterministic stencil and irregular cases at 8192 and 12000,
with SHA-256 hashes and provenance under `data/`. The timing campaign used three
warm-ups and three measured trials, serialized under a shared root lock with one
blocking child at a time. Decimal80 checking consumed saved JSONL snapshots after
solver exit. The adaptive-batching profile used one warm-up and one traced sample
per two-construction trace; pre/post traces are comparable but not back-to-back.

FP32 correctness uses epsilon `.3`, beta `8`, alpha `ceil(n/8)` for the dedicated
validation fixtures, GMRES `1e-4`, and outer cap 20. FP64 uses the precision
contract in `docs/PHASE2A_ALGORITHM_SPEC.md`; timing fixed-P records use the
documented `1e-8` criterion. Builds use strict host floating-point settings and
CUDA architecture 89; no fast-math claim is made.

## Reproducibility boundaries

Raw manifests retain commands, paths, hashes, telemetry, and trial lifecycle
records. The root lock is absent after completed campaigns. The full build trees
and raw results are intentionally excluded from this compact package.
