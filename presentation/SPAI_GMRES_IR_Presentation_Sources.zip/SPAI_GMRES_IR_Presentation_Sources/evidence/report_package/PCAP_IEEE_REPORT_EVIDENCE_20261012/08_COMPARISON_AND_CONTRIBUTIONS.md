# Comparison and contributions

| Technique | Precision | Construction | GPU execution | Verification | Status |
|---|---|---|---|---|---|
| Classical SPAI + GMRES/IR baseline | FP64 | CPU sparse approximate inverse | CPU or GPU GMRES/IR paths | established project Gate 3 records | implemented |
| Uniform FP64 GPU SPAI | FP64 | host-controlled adaptive fits, CUDA QR/residual/scoring | bounded streams, compact P, GPU GMRES | independent Decimal80 and sparse checks | implemented |
| Uniform FP32 GPU SPAI | FP32 | same adaptive structure, float QR/residual/scoring | FP32 CUDA SPAI + FP32 GPU GMRES/CPU-staged IR | FP32 snapshots and Decimal80 checks | implemented in Experiment 2A |
| Adaptive-fit wait batching | FP32/FP64 | same mathematics and candidate decisions | grouped safe transfer completion waits | focused regressions and 16 accepted campaign configurations | implemented optimization |
| BSPAI bucketing/adaptive mixed precision | mixed | not present | not present | none | proposed/future only |

The project does not claim novelty merely from reimplementing SPAI, GMRES, or
iterative refinement in CUDA. Its completed extension is the separately exposed
uniform FP32 path, saved-snapshot numerical validation, and a measured API-level
synchronization batching correction. Literature-driven GPU architecture review
and BSPAI implementation remain future work.
