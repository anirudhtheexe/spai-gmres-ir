# Performance results

All values below are existing medians in milliseconds from three measured trials.
The original timing campaign is exploratory host-wall-clock data; adaptive-batch
values are a separate post-optimization campaign. Speedup means baseline/after.

## Original CPU/GPU and precision comparison

The complete baseline table is in `tables/baseline_cpu_gpu.csv`. Representative
rows include stencil_8192 FP32 CPU/GPU SPAI `3286.5540/4749.0386`, FP64
`5363.0660/2330.4080`; native GPU pipelines are `5319.8848` FP32 and `4623.7047`
FP64. GPU is not consistently faster than CPU, and these are not equal-work
claims for native pipelines because each constructs its own P.

## Adaptive-batching GPU-SPAI medians

The retained before/after values and deltas are in `tables/gpu_spai_medians.csv`.
All eight isolated GPU-SPAI constructor medians improved: FP32 by 3.46–9.15%
and FP64 by 9.51–15.36%. FP32 full pipelines were mixed; FP64 full pipelines
improved on all four matrices. This package reports regressions rather than
selecting only favorable cases.

## Nsight API comparison

| Metric | FP32 before | FP32 after | FP64 before | FP64 after |
|---|---:|---:|---:|---:|
| cudaMemcpyAsync calls | 276008 | 276008 | 276008 | 276008 |
| Kernel launches | 357658 | 357658 | 357658 | 357658 |
| cudaStreamSynchronize calls | 373606 | 130126 | 373606 | 130126 |
| Stream sync time (ms) | 945.376 | 368.855 | 862.106 | 392.766 |
| summed GPU kernel time (ms) | 1834.141 | 1811.773 | 2719.131 | 2689.515 |

The call reduction is 65.17%; sync API time fell 60.98% FP32 and 54.44% FP64.
Copy and launch counts were unchanged. Source-owned post-change FP32 stencil
telemetry recorded 48,776 uploads / 4,603,052 bytes and 89,228 downloads /
2,181,400 bytes; nearly all transfers were <=256 bytes. See
`tables/adaptive_profile.csv` and `EXPERIMENT2A_GPU_SPAI_ADAPTIVE_OVERHEAD.md`.

## Scaling rows

The 8192-to-12000 medians are included in `tables/scaling_comparison.csv` for
stencil and irregular GPU-SPAI and pipeline modes. They are descriptive cases,
not asymptotic scaling claims; matrix construction counts and work differ.
