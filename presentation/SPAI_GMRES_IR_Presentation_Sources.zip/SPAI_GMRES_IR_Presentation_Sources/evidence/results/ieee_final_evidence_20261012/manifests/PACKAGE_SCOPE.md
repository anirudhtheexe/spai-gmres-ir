# IEEE final evidence package scope

This directory contains derived, non-destructive evidence for the final report.
Historical raw results remain in their original directories. New campaign
artifacts must use their own unique result directories and be referenced here.

At package creation, no benchmark is active and
`results/STAGE45B_EXPERIMENT_LOCK.json` is absent. The repository is on
`stage4-scalable-spai` at `8eac10eec719bf24d55e219884d7a35bcd25aaaa` with
valuable existing uncommitted/untracked work; no cleanup, reset, stash, commit,
or reorganization is authorized.
