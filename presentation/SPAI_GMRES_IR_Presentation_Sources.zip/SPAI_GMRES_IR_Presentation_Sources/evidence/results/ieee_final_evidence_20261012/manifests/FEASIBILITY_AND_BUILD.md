# Fresh-scaling feasibility and build record

## Admitted input plan

The fresh FP64-first campaign uses the existing deterministic controlled inputs:
stencil and irregular families at n=1024, 2048, 4096, 8192, and 12000. The
first four dimensions are immutable v1 files under
`data/stage45b_fp64_scalability_v1`; 12000 uses the retained v2 files under
`data/stage45b_fp64_12000_v1`. No input is regenerated or renamed.

Historical clean 12000 execution completed all six CPU/GPU modes on both
families, establishing that the current machine has previously completed this
workload. Historic conservative n>1024 preflight aborts are not treated as
current infeasibility: their source-informed host estimate was not an observed
peak and later clean 12k execution succeeded. The new runner retains a 300 s
per-child watchdog and has no retry loop; any timeout or failed verification is
preserved and classified rather than repeated.

The campaign uses 3 warm-ups and 3 measured trials, matching the existing
accepted Experiment 2A protocol. Five trials were not selected because the
ten-input, six-mode, two-backend FP64 series already contains 60 timed
configurations plus preparation and snapshot checks; all individual timings are
retained.

## Current-source build and focused regression gate

The build preflight rebuilt/current-checked only established targets:

- CPU: `cpu_core_tests`, `spai_tests`, `gmres_tests`, `ir_tests`, `fp32_cpu_tests`.
- FP32 CUDA: SpMV, GMRES, SPAI tests and `experiment2a_fp32_benchmark`.
- FP64 CUDA: SpMV, GMRES, SPAI, sparse-SPAI tests and `stage45b_benchmark`.

All executed focused tests passed. CPU totals were 37 core, 190 SPAI, 280
GMRES, and 439 IR checks. FP32 CUDA SpMV/GMRES/SPAI passed. FP64 CUDA SpMV
reported 323 checks with zero failures; sparse GPU SPAI reported 3,363,954
checks with zero failures. The current benchmark executables are
`build/fp32-cuda-ninja/experiment2a_fp32_benchmark.exe` and
`build/cuda-memory-ninja/stage45b_benchmark.exe`, freshly linked after Stage A.

The benchmark-only runner is `scripts/run_ieee_final_scalability.py`. It holds
the root lock, runs one child at a time, writes each raw solver JSONL before
launching `tests/check_experiment2a_timing_decimal.py` as a separate
snapshot-only checker, and refuses to overwrite output evidence.
