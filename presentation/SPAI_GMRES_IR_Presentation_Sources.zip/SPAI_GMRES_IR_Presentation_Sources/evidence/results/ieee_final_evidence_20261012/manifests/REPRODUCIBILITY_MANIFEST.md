# Fresh IEEE scaling campaign manifest

## Immutable campaign identity

- Date: 12 October 2026 (Asia/Kolkata).
- Source branch/revision: `stage4-scalable-spai` / `8eac10eec719bf24d55e219884d7a35bcd25aaaa` with the recorded, preserved dirty Stage-A worktree.
- Hardware: NVIDIA RTX 4060 Laptop GPU (compute capability 8.9, 8,188 MiB), driver 616.92.
- Toolchain: CUDA/nvcc 13.4.59, MSVC 19.44.35228, CMake 3.31.6-msvc6, Ninja 1.12.1, Python 3.12; CUDA architecture 89.
- Numerical configurations: uniform FP64 uses GMRES `1e-8` and outer BE `10*2^-53`; uniform FP32 uses GMRES `1e-4` and outer BE `10*2^-24`; both use epsilon `0.3`, beta `8`, alpha `ceil(n/8)`, inner cap `n`, outer cap `20`.
- Timing protocol: three warm-ups and three retained host-wall-clock trials per configuration. Warm-ups are excluded from medians.
- Acceptance protocol: solver exits first and saves JSONL; `tests/check_experiment2a_timing_decimal.py` then independently checks that immutable saved snapshot. The checker never reruns a solver.

## Commands

FP64:

```powershell
& 'C:\Users\Anirudh\AppData\Local\Programs\Python\Python312\python.exe' scripts\run_ieee_final_scalability.py --root . --runner build\cuda-memory-ninja\stage45b_benchmark.exe --precision fp64 --checker tests\check_experiment2a_timing_decimal.py --output-dir results\ieee_final_scalability_fp64_stage_a_20261012 --timeout-seconds 300 --warmups 3 --trials 3
```

FP32:

```powershell
& 'C:\Users\Anirudh\AppData\Local\Programs\Python\Python312\python.exe' scripts\run_ieee_final_scalability.py --root . --runner build\fp32-cuda-ninja\experiment2a_fp32_benchmark.exe --precision fp32 --checker tests\check_experiment2a_timing_decimal.py --output-dir results\ieee_final_scalability_fp32_stage_a_20261012 --timeout-seconds 300 --warmups 3 --trials 3
```

The runner owns `results/STAGE45B_EXPERIMENT_LOCK.json` and invokes exactly one child at a time. It was absent after both campaigns. The complete per-configuration command/input/hash mapping is in [fresh_command_matrix.csv](fresh_command_matrix.csv); source records remain in the two campaign directories named above.

## Inputs and scopes

Both precisions used the existing immutable stencil and irregular inputs at `n=1024, 2048, 4096, 8192, 12000`: v1 files under `data/stage45b_fp64_scalability_v1` for 1k--8k and v2 under `data/stage45b_fp64_12000_v1` for 12k. SHA-256 identities are in `fresh_command_matrix.csv` and each raw artifact manifest.

For every family/dimension/precision, the six isolated scopes are CPU/GPU SPAI construction, CPU/GPU fixed-preconditioner GMRES using the same serialized CPU-built `P`, and CPU/GPU public native pipeline. The fixed-P preparation artifacts are retained alongside raw records. CPU/GPU pipeline calls can make different internal adaptive/iterative decisions, so their timings are compared as public-call performance rather than an equal-work claim.

## Acceptance and exclusions

All 120 configurations and all 360 measured trials were accepted; the 120 Decimal80 sidecars each accepted their three measured records (360 accepted assessments, zero failures). No timeout, retry, overlap, generated replacement input, or failed configuration is included. The historic inventory distinguishes earlier exploratory, superseded, incomplete, and preflight-aborted results; this fresh series is the controlled current Stage-A evidence.

