# Historical benchmark inventory for final IEEE evidence

## Classification convention

An **accepted** record is a serial timing collection with retained trials and
an independent numerical assessment. **Exploratory** means accepted only within
the recorded machine/toolchain limitations. **Excluded** records remain
preserved but are not eligible for timing statistics. A preflight
`resource_abort` is neither a solve failure nor a timing observation.

## Collections

| Collection | Scope | Status | Evidence / limitation |
|---|---|---|---|
| `results/stage45a_validation` | correctness snapshots | preserve, untimed | 32 processes; 788,034 Decimal80 checks; no timing claim |
| `results/stage45a_extension` | correctness snapshots | preserve, untimed | 22 accepted native snapshots; 1,068,784 Decimal80 checks |
| `results/stage45b_selected_aggregation_20261011` | selected exploratory timing | accepted exploratory | 78 configurations; original overlapping add32/synthetic artifacts excluded in favor of continuation |
| `results/stage45b_fp64_scalability_20261011` | controlled FP64 n=1024 | accepted exploratory | two complete families, six modes each, 3 warm-ups + 5 measured, independent sidecars |
| `results/stage45b_fp64_scalability_stretch_preflight_20261011` | n=16384 feasibility | excluded from timing | conservative resource preflight only |
| `results/stage45b_fp64_large_matrix_20261011` | later stencil n=2048/4096/8192/16384 | exploratory, needs sidecar/lifecycle reassessment | raw successful records; n=16384 lacks pipeline |
| `results/stage45b_fp64_large_matrix_irregular_20261011` | later irregular n=2048/4096/8192 | exploratory, needs sidecar/lifecycle reassessment | raw successful records, no separate sidecars |
| `results/stage45b_fp64_large_matrix_irregular16k_20261011` | irregular n=16384 | exploratory, incomplete | SPAI/fixed-GMRES only, no pipeline |
| `results/stage45b_fp64_12000_20261011` and `_persistent_...` | initial 12k attempts | excluded | overlapping/incomplete; retain raw evidence |
| `results/stage45b_fp64_12000_retry_20261011` | retry | excluded | empty launcher logs |
| `results/stage45b_fp64_12000_clean_20261011` | controlled 12k FP64 | accepted exploratory | serial, 12 configurations, 3 warm-ups + 3 measured, independent sidecars |
| `results/experiment2a_fp32_vs_fp64_*_20261012` | four-matrix 8k/12k timing | accepted exploratory | 48 configurations, 288 records, snapshot Decimal80 sidecars |
| `results/experiment2a_gpu_spai_memory_*_20261012` | memory-workflow timing | accepted for its reported scope | preserve separately from fresh Stage-A source |
| `results/experiment2a_adaptive_batch_*_20261012` | synchronization batching | accepted for profiler/campaign scope | preserve, do not merge as a fresh baseline |
| `results/experiment2a_stage_a_*_20261012` | transfer consolidation | accepted for profiler/campaign scope | current validated source; preserve |

All retained campaigns used the machine-specific RTX 4060 Laptop / CUDA 13.4 /
MSVC 19.44 environment described in `PROJECT_HANDOFF.md`. The historical FP64
MSVC CPU Release CTest 1/4 wider-oracle limitation remains; timing claims are
therefore exploratory regardless of sidecar acceptance.

## Controlled FP64 historical scaling points

The following are CPU/GPU medians in milliseconds. Ratios are CPU/GPU, so a
value above one means GPU faster. These points come from distinct historical
campaigns and are not a single controlled fresh series.

| Family / n / nnz | SPAI CPU/GPU (ratio) | fixed-P GMRES CPU/GPU (ratio) | native pipeline CPU/GPU (ratio) | classification |
|---|---:|---:|---:|---|
| stencil 1024 / 4,992 | 95.309 / 624.691 (0.153) | 18.813 / 65.392 (0.288) | 148.097 / 993.033 (0.149) | accepted exploratory, 5 trials |
| irregular 1024 / 4,951 | 45.814 / 365.986 (0.125) | 17.275 / 84.962 (0.203) | 93.895 / 609.998 (0.154) | accepted exploratory, 5 trials |
| stencil 2048 / 10,048 | 347.044 / 1227.521 (0.283) | 60.778 / 130.734 (0.465) | 591.003 / 1630.716 (0.362) | exploratory raw; reassessment pending |
| irregular 2048 / 9,910 | 143.951 / 692.000 (0.208) | 61.173 / 141.984 (0.431) | 384.547 / 1102.735 (0.349) | exploratory raw; reassessment pending |
| stencil 4096 / 20,224 | 1320.854 / 2478.054 (0.533) | 215.617 / 303.740 (0.710) | 2206.837 / 3693.852 (0.597) | exploratory raw; reassessment pending |
| irregular 4096 / 19,826 | 551.134 / 1384.611 (0.398) | 222.174 / 323.180 (0.687) | 1467.563 / 2557.156 (0.574) | exploratory raw; reassessment pending |
| stencil 8192 / 40,576 | 5120.156 / 5113.614 (1.001) | 795.827 / 980.985 (0.811) | 9527.431 / 9970.690 (0.956) | exploratory raw; reassessment pending |
| irregular 8192 / 39,657 | 2268.377 / 2636.780 (0.860) | 829.167 / 1006.563 (0.824) | 6639.220 / 8031.012 (0.827) | exploratory raw; reassessment pending |
| stencil 12000 / 59,560 | 10903.591 / 6784.659 (1.607) | 1503.633 / 1778.684 (0.845) | 17852.872 / 15007.385 (1.190) | accepted exploratory, 3 trials |
| irregular 12000 / 58,095 | 4520.330 / 3564.283 (1.268) | 1495.278 / 2042.521 (0.732) | 11129.183 / 11574.336 (0.962) | accepted exploratory, 3 trials |
| stencil 16384 / 81,408 | 20757.196 / 9975.774 (2.080) | 3744.516 / 5418.992 (0.691) | missing | incomplete exploratory raw |
| irregular 16384 / 79,319 | 13788.521 / 7216.492 (1.910) | 5195.774 / 8473.062 (0.613) | missing | incomplete exploratory raw |

## Crossover finding and limits

The retained controlled-family evidence supports a **SPAI-construction trend**:
GPU is slower at n=1024 and n=2048/4096, approximately tied for stencil at
8192, and faster for SPAI at clean n=12000. It does **not** establish a unique
crossover dimension: no accepted, directly comparable 8192-to-12000 series
exists under the current Stage A executable, and irregular 8192 is still GPU
slower while clean irregular 12000 is GPU faster.

Fixed-P GMRES is slower on the GPU at every listed historical controlled point.
Native-pipeline behavior differs by family: clean 12000 stencil is GPU faster,
while clean 12000 irregular remains slightly CPU faster. Thus the old
observation was a changing CPU/GPU scaling trend and, for SPAI, an observed
sign change between retained sizes—not a universal full-pipeline crossover.

The n=2048/4096/8192 entries in the original n=1024 scalability collection are
resource preflight aborts. They are not valid substitutes for the later
large-matrix raw runs and must never be plotted as zero or failed timings.

## Inputs and gaps

Deterministic controlled inputs exist for all requested n=1024, 2048, 4096,
8192 in `data/stage45b_fp64_scalability_v1`, and n=12000 in
`data/stage45b_fp64_12000_v1`. Retained hashes include:

- stencil_8192: `90d25d6332cc3729030c13e89deb74169b13aef8c1fe89b1ffa4af6709f09b1f`
- irregular_8192: `232c6639f922657753dacdf305fcff180b6090f72b47e4cd92eb29c9bbb497be`
- stencil_12000: `67bd44621dd175b1d498013f0fff38f652a5f442853c9586ae5af9d2c971f1c3`
- irregular_12000: `01355bc6d400890f023c9fa7ed6a99a46050dbb2b2a59036568075bfb0449f12`

Missing from accepted historical timing is one serial, snapshot-checked,
Stage-A-linked FP64 series over all five dimensions and both families. That is
the new campaign's purpose. FP32 has accepted 8k/12k coverage but lacks an
equivalent all-five-size current-source series.
