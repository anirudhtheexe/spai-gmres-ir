# Presentation source pack: SPAI-GMRES-IR

This is source material for preparing a presentation, not a finished deck. It
contains implementation, methods, results, editable figures, references and
supporting validation. Large profiles, Git history and solver snapshots are
excluded. No benchmark or solver was rerun to create this pack.

## Start here

1. Read `implementation/README.md` for the implemented method, build/run
   instructions, current correctness results, and limitations.
2. Read `context/CODEBASE_GUIDE.md` and
   `evidence/CODE_OVERVIEW.md` for the CPU/GPU operation split.
3. Use `evidence/IEEE_FINAL_BENCHMARK_EVIDENCE.md` for the main performance story.
4. Use `evidence/results/ieee_final_evidence_20261012/` for final CSVs and SVGs.
5. Consult `evidence/STAGE45B_EXPLORATORY_BENCHMARK.md` for historical application
   matrices and `evidence/results/ieee_final_evidence_20261012/inventory/` for
   which historical runs were accepted, excluded or incomplete.
6. Use `evidence/EXPERIMENT2A_GPU_SPAI_ADAPTIVE_OVERHEAD.md` and
   `evidence/EXPERIMENT2A_GPU_SPAI_STAGE_A.md` for optimization evidence.

The final controlled campaign is the preferred series for the main scaling
graphs. Do not splice its points together with earlier runs as if they were
one unchanged experiment. Older numbered report-package chapters and graphs
are background sources; later final-evidence reports take precedence.

## Material for the presentation story

| Topic | Sources |
| --- | --- |
| Title, objective, problem and scope | implementation/README.md; contracts/PHASE2A_ALGORITHM_SPEC.md |
| SPAI, GMRES and iterative refinement | contracts/; numbered methodology/algorithm chapters in evidence/report_package/ |
| CPU implementation | implementation/src/{cpu,spai,gmres,ir,fp32_cpu}.cpp; CPU milestone reports |
| CUDA implementation and transfers | evidence/CODE_OVERVIEW.md; CUDA stage reports; implementation/src/ |
| Actual CPU/GPU boundary | figures/architecture_verified.mmd; evidence/CUDA_SPAI_DIAGRAM_AUDIT.md |
| Correctness and precision | implementation/README.md; contracts/; current_validation/; saved Decimal80 sidecars |
| Experimental setup | final reproducibility manifest, command matrix, source harnesses, matrix specifications |
| Historical CPU/GPU benchmarks | historical report, selected aggregation JSON/figures, historical inventory |
| Final FP32/FP64 scaling | final raw-sample CSV, medians, speedup CSV, final SVGs |
| Synchronization and transfer optimizations | optimization reports, profiler CSV summaries, campaign summaries |
| Interpretation, limitations and future work | final evidence report, contracts, missing-information notes |
| References | references/REFERENCES.md; bibliography in evidence/report_package/ |

## Primary graph/table locations

Under `evidence/results/ieee_final_evidence_20261012/`:

- `raw/fresh_all_samples.csv`: all exported timing samples, including warm-ups.
- `summaries/fresh_median_results.csv`: all 120 configurations with measured
  trials, medians, statuses and diagnostics.
- `summaries/fresh_cpu_gpu_speedups.csv`: CPU/GPU ratios.
- `validation/decimal80_snapshot_validation.csv`: numerical acceptance summary.
- `figures/fp64_cpu_gpu_time.svg` and `figures/fp64_speedup.svg`.
- `figures/fp32_fp64_pipeline.svg`.
- `figures/cuda_api_counts.svg` and `figures/stage_a_walltime.svg`.

Historical selected JSON and SVGs are under
`evidence/results/stage45b_selected_aggregation_20261011/`.
Profiler CSVs retain their original campaign directories under `evidence/results/`.
SVGs are editable vector graphics; the CSVs can be used to redraw charts.
For Stage A, only the `stage_a_profile_*_retry_20261012` directories are valid
after-change profiles: the earlier non-retry traces used pre-edit executables
and are excluded here. Profile manifests accompany included CSVs. For batching,
use the before/after classification in its report rather than directory age.

## Interpretation rules

- Implemented: uniform FP32 and FP64 SPAI-GMRES-IR on CPU and CUDA.
  BSPAI bucketing and mixed precision are future work, not completed features.
- GPU SPAI performs scaling, QR fits, residual/scoring and packed numerical P
  assembly on the device. CPU handles adaptive metadata/decisions, packs N data,
  canonicalizes downloaded P, and uploads canonical P into GMRES.
- GPU GMRES has device vector arithmetic and sparse products with host scalar
  control. FP64 Givens rotations and projected back-substitution run on CPU.
  The outer IR residual, backward error, update and stopping decision are CPU staged.
- Two older workflow SVGs were deliberately omitted: the architecture labels
  were misleading and the adaptive-fit graphic predates Stage A transfer packing.
  Use the verified Mermaid dataflow and the diagram audit when drawing slides.
- Ratios are CPU time / GPU time: greater than one means the GPU is faster.
  Keep SPAI construction, same-P GMRES, and native pipeline scopes separate.
- Final campaign: two matrix families, five sizes (1024 through 12000), both
  precisions, six modes, three warm-ups and three retained trials/configuration.
  All 120 configurations and 360 measured assessments were accepted.
- Final FP64 SPAI is faster on stencil at 8192 and both families at 12000;
  this is family-dependent. Fixed-P GPU GMRES remains slower at tested sizes.
  FP32 GPU does not cross CPU through 12000. No universal GPU speedup claim.
- Batching reduced synchronization call counts by 65.17%. Stage A reduced async
  copy calls by 11.688%. These are API-count reductions; wall times were mixed.
- Native CPU/GPU pipelines may construct different P or take different numbers
  of iterations. Their timings are not guaranteed equal-work comparisons.
- Historical MSVC CPU Release tests had a wider-long-double oracle limitation;
  keep historical timings exploratory. Later correctness checks do not
  retroactively turn old timings into newly controlled experiments.
- Cite the input family, precision, size, scope and campaign beside any number.
  Do not use resource preflight aborts as zero timings or failed solver samples.

## Known gaps and conflicting historical descriptions

There is no supplied presentation rubric, duration, slide limit, team/title
information or required design template. Those must come from the presenter.
Personal motivations and undocumented decisions should not be invented.

The references contain links and metadata, not full-text paper PDFs or local
MATLAB reference repositories. Check source papers before adding new literature
claims. No genuine terminal/Nsight screenshots are included. If screenshots are
required, capture real views of retained evidence rather than fabricate them.

An older benchmark report names an AMD Ryzen 7 7745HX and a Windows build; a
later evidence report says CPU/RAM/OS details were not reliably recorded. Keep
that discrepancy explicit and verify campaign-specific manifests before using
those host details as a common setup. The documented GPU is RTX 4060 Laptop;
there is no RTX 4080 experiment in this pack.

Historical reports contain original paths/line numbers and sometimes obsolete
authorization/status text. Treat those as dated provenance, not instructions.
Names of local files in old reports can be located using PACKAGE_MANIFEST.json.
Evidence paths are preserved below `evidence/`; current source is below
`implementation/`. Source line numbers changed during formatting; search by
function name. Links to omitted raw snapshots/large matrices point to the full
research archive and are intentionally not a complete reproduction environment.

## Package integrity

PACKAGE_MANIFEST.json records each file's SHA-256, size and original source.
Archived material was checked against the archive's per-file SHA-256 manifest.
Implementation files are the exact tested submission payload, without changes.
The package includes small benchmark source/validation scripts for explanation;
it does not contain all datasets or binaries needed to rerun historical campaigns.
No PowerPoint file is included.
