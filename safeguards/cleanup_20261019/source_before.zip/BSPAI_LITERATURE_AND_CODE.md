# BSPAI literature and implementation inventory

13 October 2026; research only. This record supersedes access assumptions,
not frozen source or historical numerical evidence. Definitions and equations
are in [BSPAI_ALGORITHM_SPECIFICATION.md](BSPAI_ALGORITHM_SPECIFICATION.md).

## Primary literature and access

| Source | Verified access/review | Reproduction |
|---|---|---|
| Noaman Khan, Erin Carson, *Mixed precision iterative refinement with adaptive precision sparse approximate inverse preconditioning*, Engineering with Computers 41:3833–3846 (2025), [DOI](https://doi.org/10.1007/s00366-025-02187-z) | Publisher full HTML prose/equations and PDF extracted text read; algorithm images not visually recovered. [Publisher PDF](https://link.springer.com/content/pdf/10.1007/s00366-025-02187-z.pdf) | None |
| Same authors, [arXiv:2307.03914v1](https://arxiv.org/html/2307.03914v1) | Full HTML and algorithm lines read; version-date inconsistency in rendering recorded in specification | None |
| Erin Carson, Noaman Khan, *Mixed Precision Iterative Refinement with Sparse Approximate Inverse Preconditioning*, SIAM J. Sci. Comput. (2023), [DOI](https://doi.org/10.1137/22M1487709), [arXiv v2](https://arxiv.org/html/2202.10204v2) | Full HTML available; construction/analysis, Algorithm 3 and experiments inspected | Existing local uniform baselines are project variants, not mixed-precision table reproduction |
| Stef Graillat, Fabienne Jézéquel, Theo Mary, Roméo Molina, *Adaptive Precision Sparse Matrix–Vector Product and Its Application to Krylov Solvers*, SIAM J. Sci. Comput. 46:C30–C56 (2024), [DOI](https://doi.org/10.1137/22M1522619) | [Author full manuscript](https://perso.lip6.fr/Theo.Mary/doc/adaptSpMV.pdf), dated 12 May 2023, inspected for arithmetic, error analysis, dropping and parallel SpMV; publisher route exposed metadata/abstract | None; final-version equivalence unverified |
| Yizhou Wang, Wenhao Li, Jiaquan Gao, *A parallel sparse approximate inverse preconditioning algorithm based on MPI and CUDA*, BenchCouncil Transactions 1:100007 (2021), [DOI](https://doi.org/10.1016/j.tbench.2021.100007) | [Open full PDF](https://www.tbench.org/single/1-9.pdf), construction and MPI/CUDA framework inspected | None |
| Jiaquan Gao, Q. Chen, G. He, *A Thread-Adaptive Sparse Approximate Inverse Preconditioning Algorithm on Multi-GPUs*, Parallel Computing (2021), [DOI](https://doi.org/10.1016/j.parco.2020.102724) | Full text not acquired in this assignment; indexed prior work only | None |

The central contribution already established by Khan–Carson is bucketed
SPAI within mixed-precision GMRES refinement and its conditional error
analysis. GPU SPAI construction and mixed-precision SpMV are prior work.
Candidate local CUDA choices are engineering proposals until validated;
the literature does not establish their speed or novelty.

## Official code and related artifacts

1. [Noaman67khan/SPAI-GMRES-IR](https://github.com/Noaman67khan/SPAI-GMRES-IR/tree/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1).
   Author-associated repository cited by C23; current main commit independently
   verified as `b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1` through GitHub API.
   Read [README](https://github.com/Noaman67khan/SPAI-GMRES-IR/blob/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1/README.md),
   [spai_dd.m](https://github.com/Noaman67khan/SPAI-GMRES-IR/blob/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1/spai_dd.m),
   [gmres_spai_dd.m](https://github.com/Noaman67khan/SPAI-GMRES-IR/blob/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1/gmres_spai_dd.m),
   [sgmresir3_spai_scaling.m](https://github.com/Noaman67khan/SPAI-GMRES-IR/blob/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1/sgmresir3_spai_scaling.m),
   and [license.txt](https://github.com/Noaman67khan/SPAI-GMRES-IR/blob/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1/license.txt).
   It contains MATLAB SPAI constructors for half/single/double, LU and SPAI
   GMRES variants, IR, scaling and plotting. Inspected constructor/solver loops
   are serial; the tree has MATLAB files and one MAT input, with no native
   CUDA/MPI/OpenMP implementation. Requirements are MATLAB, Advanpix,
   Higham chop and Multi_precision_NLA_kernels. License is BSD-2-Clause;
   copyright names Erin Carson and Nicholas J. Higham (2017), which must be
   retained if reused. This license is not evidence for adaptive-source rights.

2. [Noaman67khan/ADAP-SPAI-GMRES-IR](https://github.com/Noaman67khan/ADAP-SPAI-GMRES-IR).
   K25 Data Availability and footnote 2 explicitly cite this exact URL.
   On 13 October 2026 the public GitHub REST repository endpoint and
   commits/main returned HTTP 404 after approved network access. Prior
   local research also recorded 404. Thus publication documents code
   availability, but source is currently inaccessible. No adaptive files,
   license, source completeness, platform, or immutable revision were
   verified. The publication's experiments are MATLAB; that does not prove
   what files an unavailable repository currently contains. Private,
   removed, renamed and temporarily unavailable remain possible explanations.

3. [higham/chop](https://github.com/higham/chop), explicitly cited by K25:
   MATLAB low-precision simulation dependency. This is not a native binary16
   GPU backend. Its precise version/options used for K25 are unavailable.
   [SrikaraPranesh/Multi_precision_NLA_kernels](https://github.com/SrikaraPranesh/Multi_precision_NLA_kernels)
   is a dependency documented by M23; its exact version used is unpinned here.

4. [nbz406/SPAI](https://github.com/nbz406/SPAI/tree/350c67622288c3168b4d3b8332c3ee9d4dfa8f29)
   is a previously inspected CUDA candidate in
   [PHASE1_REPORT.md](docs/PHASE1_REPORT.md), not official Khan–Carson BSPAI.
   Prior record describes C++/CUDA, batched double QR/triangular solves and
   Python experiment tooling, with no verified license or BSPAI/GMRES-IR.
   It was not re-audited in this assignment; retain that provenance distinction.

No working, official native CUDA BSPAI–GMRES–IR source was established.
No supplementary adaptive source archive was found in inspected publication
links. These are bounded search outcomes, not proof that none exists.

## Which components were parallelized

| Work | Construction | Sparse application | GMRES/IR | Multi-GPU/MPI |
|---|---|---|---|---|
| Khan–Carson BSPAI publication | Independent columns described mathematically; MATLAB experiments, no measured construction parallelism established | Multiple precisions per row; highest-format combining | MGS-GMRES and outer precision roles analyzed | No implementation or experiment established |
| G23 adaptive SpMV manuscript | Not SPAI construction | CPU multicore adaptive SpMV; §4.5 studies thread scaling | Adaptive SpMV plugged into Krylov/refinement methods; do not infer a fully parallel GMRES/IR implementation | CPU shared-memory study, not a verified multi-GPU implementation |
| Wang–Li–Gao HybridSPAI §3 | GPU index discovery, local extraction, QR, triangular solve and assembly for an a-priori pattern | Preconditioner used in GPU solver evaluation | Evaluated with BiCGSTAB, not BSPAI–GMRES–IR | MPI distributes construction work across GPUs and gathers results |
| Current project | CUDA QR/residual/scoring/assembly with host adaptive decisions | Uniform FP64/FP32 cuSPARSE paths | Device vectors in GMRES; CPU-staged outer IR | No multi-GPU/MPI baseline established |

The last row is backed by [CODEBASE_GUIDE.md](CODEBASE_GUIDE.md),
`src/cuda_spai.cu`, `src/cuda_gmres.cu`, `src/cuda_ir.cpp` and the existing
[validation record](docs/PHASE2B_VALIDATION_RECORD.md), not by publication.
HybridSPAI's static pattern and uniform double workspace do not reproduce
the adaptive-pattern, mixed-format Khan–Carson baseline. Its wording about
MPI threads should not be adopted as a precise MPI threading contract.

## Published experiments: facts and limits

K25 §4: MATLAB R2021a; binary16 simulated with chop; single/double MATLAB
types; quadruple using Advanpix. Equal-component unit-2-norm RHS, identity
initial sparsity, nonzero diagonals, transpose column scaling, beta 8,
unrestarted GMRES and `u_g=u_p=u`. The detailed table configurations are
double/double/quad (Table 3) and single/single/double (Table 4). §4's
introductory list instead includes single/double/quad and half/single/double;
these must not be claimed table-verified BSPAI configurations.

| Published Table 1 name | n | nnz(A) |
|---|---:|---:|
| pores_3 | 532 | 3,474 |
| bfw782a | 782 | 7,514 |
| cage5 | 37 | 233 |
| gre_115 | 115 | 421 |
| hor_131 | 434 | 4,182 |
| sherman4 | 1,104 | 3,786 |
| steam1 | 240 | 2,248 |
| steam3 | 80 | 314 |

Table 3/4 also contain `saylr1`, absent from Table 1; C23 lists n=238,
nnz=1128. The `bfw782a`/`bfwa782` spelling discrepancy must be resolved by
SuiteSparse group/name/ID before acquisition. Do not identify matrices by
approximate spelling alone. No hardware configuration or wall-clock timing
series was established from the inspected BSPAI paper; its storage/iteration
results are not RTX 4060 speedups.

Selected published rows, **not reproduced results**:

| Configuration | Storage cost vs uniform values | Total GMRES iterations vs SPAI |
|---|---:|---:|
| steam1, double; varepsilon=.1, epsilon_b=2^-53 | 74.9% | 21 vs 14 |
| steam1, double; epsilon_b=2^-37 | 42.6% | 21 vs 14 |
| steam3, double; epsilon_b=2^-37 | 59.0% | 80 vs 11 |
| cage5, single; varepsilon=.1, epsilon_b=2^-18 | 76.5% | 8 vs 8 |
| gre_115, single; varepsilon=.4, epsilon_b=2^-18 | 66.7% | 50 vs 32 |
| steam1, single; varepsilon=.1, epsilon_b=2^-24 | 45.6% | 244 vs 8 |

K25 Table 3 reports steam1 bucket counts `(556,537,12,0)` over 1105
constructed entries. Independently recomputing value-only bytes gives
`(8*556+4*537+2*12)/(8*1105)=0.748868...`, agreeing with 74.9%.
This calculation does not include CSR row offsets, column indices, vector
conversion/workspace, metadata or launches. Actual CUDA resident storage
must be reported separately. K25 notes worse iteration behavior and modest
or no storage benefit for several matrices; high-performance large-scale
evaluation is future work. Working-accuracy forward/backward convergence
is reported, but no numeric per-step backward-error history was recovered
from adaptive source. Do not substitute local frozen backward-error success
for the authors' exact experimental stopping condition.

## Unverified / Needs Full-Text / Needs Reproduction

- Adaptive source and its supplement/license/commit; exact driver settings,
  threshold norm implementation, ordering, range handling, caps and stopping.
- Direct visual published-algorithm comparison and stable arXiv source bytes.
- Published Graillat final text vs inspected author manuscript; Gao multi-GPU
  full text and exact public implementation provenance.
- Table 1 omission, inconsistent precision list, matrix spelling, and
  additive/multiplicative error-constant discrepancy documented in specification.
- Independent reproduction of all storage, iteration and accuracy rows;
  runtime or hardware claims for native CUDA. No such claims are verified here.
