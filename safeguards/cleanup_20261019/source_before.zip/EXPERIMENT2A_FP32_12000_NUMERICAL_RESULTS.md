# Experiment 2A FP32 12,000 numerical results

Two immutable inputs were each executed once in CPU-then-GPU order, with uniform binary32 production arithmetic and no timing collection.  The saved snapshots were independently assessed with Decimal80 without rerunning a solver.  Frozen parameters were epsilon `.3`, beta 8, alpha 1500, GMRES tolerance `1e-4`/cap 12000, outer cap 20, and backward-error target `10*2^-24`.

| Matrix/backend | Status | P nnz | Fits/growths | Inner iterations | Outer corrections | Decimal80 BE | Forward error | Accepted |
|---|---|---:|---:|---|---:|---:|---:|---|
| stencil CPU | success | 59205 | 23881 / 11881 | 7, 9 | 2 | 6.0444139101547974e-08 | 6.7741461228420147e-08 | yes |
| stencil GPU | success | 59205 | 23881 / 11881 | 7, 8 | 2 | 6.0444141672525308e-08 | 5.5708031816528181e-08 | yes |
| irregular CPU | success | 17379 | 13386 / 1386 | 8, 9 | 2 | 6.9323122592195195e-08 | 6.75196802742033e-08 | yes |
| irregular GPU | success | 17379 | 13386 / 1386 | 8, 9 | 2 | 6.882274679262352e-08 | 6.602227023778841e-08 | yes |

The stencil and irregular CPU/GPU preconditioner-pattern symmetric differences are both zero.  The original-input and rounded-FP32-system backward errors coincide because both immutable matrices have dyadic coefficients.  Each reported BE is below the frozen `10*2^-24` target.  These are numerical-correctness executions only, not performance measurements.

Raw snapshots: `results/experiment2a_fp32_12000_stencil_20261012.jsonl` and `results/experiment2a_fp32_12000_irregular_20261012.jsonl`.
