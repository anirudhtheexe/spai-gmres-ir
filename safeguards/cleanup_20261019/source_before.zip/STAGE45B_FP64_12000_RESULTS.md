# Experiment 1 — FP64 Scalability at n=12,000

**Date:** 11 October 2026  
**Status:** incomplete; no valid n=12,000 CPU/GPU scalability comparison was produced.

## Frozen configuration and inputs

No production numerical source, tolerance, precision policy, or solver setting was changed. Both controlled inputs use `periodic7` manufactured data and the existing binary64 rules: `epsilon=0.3`, `beta=8`, `alpha=1500`, `tau=1e-8`, unrestarted GMRES cap `12000`, outer cap `20`, and backward-error target `10*2^-53`.

| Input | Construction | n | nnz | SHA-256 |
|---|---|---:|---:|---|
| `stencil_12000` | 100-by-120 row-major four-neighbour grid; directional weights `-1/4,-1/8,-1/2,-1/16`; strictly row diagonally dominant | 12,000 | 59,560 | `67bd44621dd175b1d498013f0fff38f652a5f442853c9586ae5af9d2c971f1c3` |
| `irregular_12000` | Existing 3/5/8/13 uneven-block, directed-shift and cross-edge construction; strictly row diagonally dominant | 12,000 | 58,095 | `01355bc6d400890f023c9fa7ed6a99a46050dbb2b2a59036568075bfb0449f12` |

The immutable Matrix Market files, individual provenance files, and generator manifest are in `data/stage45b_fp64_12000_v1/`. The generator is `stage45b-fp64-scalability-v2`, SHA-256 `fbc66265e95b2e0d28ea8f0359327ed3303c07f332d9bbc96d254691d9372cdd`.

## Execution outcome

The prescribed 3 warm-ups and 3 measured trials were configured with the existing 300-second per-configuration watchdog, sequential-runner lock, host-wall-clock boundary, and no Windows host-memory probe, estimate, monitor, or admission gate.

The retained original directory is `results/stage45b_fp64_12000_20261011/`; the persistent-session attempt is `results/stage45b_fp64_12000_persistent_20261011/`; and `results/stage45b_fp64_12000_retry_20261011/` contains only empty launcher logs. All are retained unchanged.

`stencil_12000` fixed-P preparation succeeded: `P` has 59,205 nonzeros, 23,881 fit events, 11,881 growth events, maximum full construction residual `0.2921743548953888`, maximum pattern columns 5, and maximum reduced shape 13-by-5. The stored P hash is `9d9ac19be8875a6e5325be77d466840e719ba1a84e05d7c83c92104791e4c502`.

Both directories contain successful 3+3 stencil SPAI and fixed-P GMRES records, but the two runners overlapped. Validation found the original CPU-SPAI execution still active when the persistent runner began; later SPAI modes overlapped as well. Consequently, **no SPAI timing from either directory is eligible for benchmark statistics or speedup claims**. Neither directory has native CPU/GPU pipeline artifacts, an experiment `SUMMARY.json`, or an assessment sidecar. `irregular_12000` has no execution artifacts.

The isolated persistent fixed-P GMRES pair occurred after the first runner's retained records ended. Its raw medians are CPU `1661.6329 ms` and GPU `2069.5990 ms` (a diagnostic ratio of `0.803x`). It is recorded for traceability only, not presented as a completed campaign, scalability result, or full-pipeline comparison.

## Numerical and resource evidence

The completed stencil fixed-P GMRES records use the identical stored P hash for CPU and GPU, converge in 14 inner iterations, and retain embedded Decimal80 preconditioned relative residuals:

| Mode | Decimal80 `||P(b-Ax)||_2 / ||Pb||_2` | Frozen acceptance |
|---|---:|---|
| CPU fixed-P GMRES | `5.3674720623e-9` | pass (`<= 1e-8`) |
| GPU fixed-P GMRES | `5.3674720575e-9` | pass (`<= 1e-8`) |

There is no native pipeline solution, so there is no n=12,000 original-residual/backward-error acceptance result, outer-iteration count, or pipeline speedup.

The recorded GPU preflight was accepted with zero safety margin and did not use host memory:

| GPU mode | Available dedicated VRAM | Known source allocation requirement | Outcome |
|---|---:|---:|---|
| SPAI | 7,519,338,496 bytes | 1,669,736 bytes | accepted; not a total-footprint measurement |
| Fixed-P GMRES | 7,510,949,888 bytes | 2,307,052,268 bytes | accepted; excludes queried cuSPARSE workspace |

No retained CUDA allocation failure, watchdog timeout, solver nonconvergence, or OS/process diagnostic identifies why the campaigns stopped. They are therefore classified as **incomplete, termination cause unclassified**, not as out-of-memory, timeout, or numerical failure.

## Comparison and conclusion

The valid 8,192-dimensional observations remain separate: stencil SPAI was effectively tied (1.001x) while stencil full pipeline was 0.956x; irregular SPAI and pipeline were 0.860x and 0.827x. The existing `add32` n=4,960 exploratory record is from a different application-matrix family and must not be treated as a controlled scaling point.

No n=12,000 SPAI or full-pipeline CPU/GPU speedup is reported, so this experiment does not establish a GPU crossover. No plots are produced: a plot would imply comparable complete samples that do not exist. The CPU Release CTest wider-oracle limitation (1/4) also remains unchanged; this work remains exploratory and not publication-ready.

## Independent review

The Validation agent independently audited the raw artifacts, provenance, frozen settings, fixed-P identity, timing boundaries, Decimal80 fields, and overlap. It accepted the completed fixed-P numerical records, rejected overlapping timing records as benchmark evidence, and confirmed that no cause for the interrupted campaigns can be inferred from retained evidence.

## Superseding clean execution — 11 October 2026

### Orchestration repair and diagnosis

The invalidated attempts used different output directories, each with its own `RUN_LOCK.json`. Those independent locks were not a shared exclusion mechanism: the first runner began at Unix `1791737511.684`, the persistent runner at `1791737591.761`, and their CPU-SPAI intervals overlapped. The failure was orchestration, not a solver, CUDA-memory, or numerical failure. The prior per-output locks and raw records remain preserved and excluded from the results below.

`scripts/benchmark_experiment_lock.py` now provides one atomic experiment lock at `results/STAGE45B_EXPERIMENT_LOCK.json`, acquired with `O_CREAT|O_EXCL` by both scalability and exploratory launchers. It records owner PID, token, liveness data, active case/mode, child PID, start/end timestamps, exit status, watchdog status, and the last successful configuration. A pre-existing lock is never automatically removed; its owner must first be inspected and confirmed dead. Per-configuration wrappers now record their child lifecycle and emit `process_termination_unclassified` if a child returns no usable JSON.

The clean run is `results/stage45b_fp64_12000_clean_20261011/`. Its root lock was held continuously and released normally after completion. Validation verified all 12 wrapper child intervals are strictly serial: the first began at Unix `1791738811.419` and the final child ended at `1791739390.239`. Every wrapper has `returncode=0`, `watchdog_timeout=false`, and a completed lifecycle.

### Clean timing results

Each mode has three warm-ups and three measured observations. Values are host-wall-clock milliseconds; standard deviations are sample standard deviations over the three retained measured trials. `CPU/GPU` is the CPU median divided by GPU median; values above one indicate that the GPU was faster. Fixed-P GMRES uses an identical stored P; native pipelines are separate native constructions and therefore not equal-work comparisons.

| Case | Comparison | CPU median ± SD (ms) | GPU median ± SD (ms) | CPU/GPU |
|---|---|---:|---:|---:|
| Stencil 12k | SPAI construction | 10,903.591 ± 25.194 | 6,784.659 ± 20.541 | **1.607×** |
| Stencil 12k | fixed-P GMRES | 1,503.633 ± 38.975 | 1,778.684 ± 28.144 | 0.845× |
| Stencil 12k | native full pipeline | 17,852.872 ± 725.556 | 15,007.385 ± 497.901 | **1.190×** |
| Irregular 12k | SPAI construction | 4,520.330 ± 103.409 | 3,564.283 ± 1.578 | **1.268×** |
| Irregular 12k | fixed-P GMRES | 1,495.278 ± 107.315 | 2,042.521 ± 59.989 | 0.732× |
| Irregular 12k | native full pipeline | 11,129.183 ± 294.215 | 11,574.336 ± 288.159 | 0.962× |

GPU SPAI overtook CPU SPAI for both controlled families. The GPU native full pipeline overtook CPU only for the stencil case; it did not for the irregular case. GPU fixed-P GMRES was slower for both. This is an exploratory three-trial result and does not establish a general crossover threshold.

### Numerical and resource acceptance

All 12 fixed-P GMRES measured trials converged, used matching CPU/GPU P hashes, passed binary64 serialize/round-trip checks, and independently passed the unchanged Decimal80 `||P(b-Ax)||_2 / ||Pb||_2 <= 1e-8` requirement. All 12 native-pipeline measured trials converged, passed binary64 round trips, and independently passed the original-system Decimal80 backward-error requirement `<=10*2^-53`.

| Case | P nnz | fit / growth events | inner iterations | outer steps | CPU / GPU backward error | GPU SPAI source peak |
|---|---:|---:|---:|---:|---:|---:|
| Stencil 12k | 59,205 | 23,881 / 11,881 | 31 | 2 | `1.33435e-16` / `1.33435e-16` | 3,437,664 bytes |
| Irregular 12k | 17,379 | 13,386 / 1,386 | 34 | 2 | `1.37303e-16` / `1.37303e-16` | 2,654,616 bytes |

All six GPU preflights were accepted with zero safety margin, based only on source-known dedicated-VRAM allocations. GPU SPAI peaks above are application-issued allocation telemetry, not total GPU consumption; vendor workspaces, runtime context/cache allocations, and host memory are excluded. No CUDA allocation failure, timeout, nonconvergence, or process termination occurred in the clean campaign.

### Raw records and plots

Raw JSONL, binary64 audits, fixed P files, Decimal80 assessment sidecars, lifecycle outcomes, and `SUMMARY_REASSESSED.json` are retained in `results/stage45b_fp64_12000_clean_20261011/`. Additive plots and `SCALABILITY_SUMMARY.json` are in `results/stage45b_fp64_12000_clean_aggregation_20261011/`:

- `spai_construction_vs_dimension.svg`
- `fixed_p_gmres_vs_dimension.svg`
- `full_pipeline_vs_dimension.svg`
- `pipeline_speedup_vs_dimension.svg`
- `gpu_spai_memory_vs_dimension.svg`

The original MSVC CPU Release CTest limitation remains 1/4 due to the unchanged wider-`long double` availability requirements. Existing independent Decimal80 evidence supplements it, but these timings remain exploratory rather than publication-ready.
