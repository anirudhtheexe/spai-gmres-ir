# BSPAI Stage 1 integration plan

**Scope:** source-level preparation only. This document does not authorize a BSPAI implementation, numerical-policy change, test run, benchmark, profiler, or build.

## Status and preservation boundary

The original working tree remains the validated uniform-SPAI baseline. A separate BSPAI workspace has not been created because a complete external rollback copy is still pending storage capacity. This plan is intentionally recorded in the current repository at the user's direction; it does not change production code or evidence.

## Existing preconditioner path

| Stage | Binary64 CPU | Binary64 CUDA | Separate Experiment 2A FP32 path |
|---|---|---|---|
| SPAI construction | `construct_spai` in `src/spai.cpp` returns `SpaiResult`, including `preconditioner` | `cuda_construct_spai` in `src/cuda_spai.cu` returns `CudaSpaiResult::construction.preconditioner` | `fp32_construct_spai` in `src/fp32_cpu.cpp`; `fp32_cuda_construct_spai` in `src/fp32_cuda_spai.cu` |
| Sparse representation | `CsrMatrix` in `include/bspai/cpu.hpp`: canonical sorted CSR with `double` values | The same host CSR is uploaded to device CSR descriptors | `Fp32CsrMatrix` in `include/bspai/fp32.hpp`, independently typed `float` CSR |
| P application | `apply_left_preconditioned` in `src/gmres.cpp` evaluates `P*(A*v)` | `CudaGmresContext` in `src/cuda_gmres.cu` uploads immutable A/P and executes two cuSPARSE CSR SpMVs | `fp32_left_preconditioned_gmres` / `fp32_cuda_left_preconditioned_gmres` use the analogous FP32 CSR path |
| GMRES integration | `left_preconditioned_gmres` takes `const CsrMatrix& p` | `CudaGmresContext(a,p,options,device)` takes uniform CSR P | Separate APIs; do not silently merge with FP64 |
| IR integration | `refine_with_preconditioner` starts with `P*b`, then calls GMRES for correction RHS | `cuda_refine_with_preconditioner` keeps outer refinement CPU-staged and reuses one GPU context | FP32 equivalents retain the same staged design |
| Fixed-P serialization | Stage 4.5 runners write/read Matrix Market P and record SHA-256 | Same serialized P used by CPU/GPU fixed-P modes | Same arrangement in `tests/experiment2a_fp32_benchmark.cpp` |

The frozen left-preconditioned contract is: do not materialize `P*A`; apply P after each A-vector product, recompute the true preconditioned residual before convergence acceptance, and use P for the initial IR iterate `x0=P*b`.

## Proposed integration boundary

Do not change Arnoldi, Givens rotations, Krylov basis storage, IR stopping criteria, or SPAI construction to introduce BSPAI. The smallest viable future change is an immutable **preconditioner-application operation** at the two existing application sites:

1. CPU: replace direct use of `p.multiply(...)` inside `apply_left_preconditioned` and the initial `P*b` operation with a narrow uniform-or-bucketed application object.
2. CUDA: retain the existing uniform `CudaGmresContext` as the baseline. Add a distinct future bucketed context/application path only after standalone CUDA bucket application matches the CPU reference; it must expose the same operator semantics to GMRES.
3. IR: accept that same application object for initial P application and inner GMRES, keeping the outer residual and update behavior unchanged.

Initially, a runtime interface with a uniform-CSR adapter is preferable to template-wide GMRES specialization: only P application varies, while every validated GMRES operation remains common. The precise interface must wait for the published bucketing representation/rounding specification in `BSPAI_ALGORITHM_SPECIFICATION.md`; no generic abstraction should be added preemptively.

## Future BSPAI data boundary

The published method buckets the **completed, scaled left preconditioner P**, not the input A or intermediate SPAI fit matrix. A future representation must retain:

- the source canonical P and a content hash for validation;
- bucket-policy metadata, including paper-defined `epsilon_b`, norm identity/value, precision role, interval endpoints, conversion policy, and drop count;
- sparse structure/value arrays for each retained bucket; and
- an explicit accumulator type and deterministic bucket order.

Separate CSR matrices per bucket are the simplest CPU reference and CUDA-validation representation. They may create one SpMV/kernel per bucket; a packed/custom representation is a later engineering decision, not part of the initial correctness milestone. The current cuSPARSE path is uniform `CUDA_R_64F` or `CUDA_R_32F`; it cannot directly express a multi-storage-format P without separate descriptors or custom kernels.

## Precision and CUDA constraints

The recorded stack is RTX 4060 Laptop (CC 8.9), CUDA 13.4.59, cuSPARSE 12.8.6, cuBLAS 13.7.0, and cuSOLVER 12.3.2. Existing FP64 and FP32 paths use uniform CSR values and cuSPARSE SpMV. CUDA conversion, FP16 subnormal behavior, overflow, FMA, product rounding, and high-precision accumulation cannot be selected from hardware intuition; they must implement the source-backed policy in `BSPAI_ALGORITHM_SPECIFICATION.md`.

The leading numerical risk is changing P at a bucket boundary or through low-precision conversion in a way the publication does not permit. The leading performance risk is that multiple small bucket applications increase launch and synchronization overhead enough to outweigh storage reduction. The existing CUDA SPAI evidence already makes host/device coordination and small-work overhead material.

## Standalone test architecture

Before GMRES, build a BSPAI-only test harness that accepts a serialized canonical P and vector v, then records uniform `P*v`, bucketed `P*v`, a high-precision reference, per-bucket structure/value data, policy metadata, storage bytes, and optional application-only timing (never construction or solver time).

Required gates, in order:

1. Exact bucket assignment and serialization checks: open/closed endpoints, zeros/drops, signs, empty buckets, deterministic ordering, and round trip.
2. CPU application checks: known small matrices, extreme values, subnormals, underflow/overflow classification, and source-backed error bounds.
3. CUDA application checks against CPU reference: bucket memberships, converted stored values, output error bounds, and device-memory lifetime checks.
4. Regression check: unchanged uniform CPU/CUDA SPAI, GMRES, and IR behavior.
5. Fixed-P BSPAI GMRES convergence and recomputed-residual checks.
6. Full BSPAI-GMRES-IR backward-error checks with independent higher-precision assessment.
7. Only then: separately manifested benchmarks for construction, bucketing, storage, P application, iterations, transfers, launches, and end-to-end IR.

## Implementation sequence after explicit authorization

1. Freeze the research specification and test oracle values.
2. Add a CPU-only bucket-representation builder from an existing P; do not alter SPAI construction.
3. Add CPU bucketed application and standalone tests.
4. Validate a CUDA representation/application against the CPU oracle.
5. Add the narrow GMRES/IR integration while retaining uniform mode unchanged.
6. Run independent numerical validation before any performance study.

## Explicit non-goals for Stage 1

No bucket threshold is chosen here. No FP16/FP32/FP64 assignment is selected here. No custom CUDA kernel, mixed-precision SpMV, GMRES rewrite, IR change, source modification, test run, benchmark, or profiling action is authorized by this plan.
