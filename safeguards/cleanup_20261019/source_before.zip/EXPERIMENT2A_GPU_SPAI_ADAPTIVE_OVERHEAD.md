# Experiment 2A -- GPU SPAI adaptive-fit overhead batching

## Result

The focused shared FP32/FP64 change batches completion waits for three already ordered copies at each safe adaptive-fit host dependency boundary. It preserves the numerical algorithm and lowers observed `cudaStreamSynchronize` API calls in the comparable `stencil_8192` Nsight traces from 373,606 to 130,126 (65.17%). All focused regressions and all 16 serial GPU configurations (two precisions, four frozen matrices, GPU-SPAI and GPU-pipeline modes) passed their saved-snapshot Decimal80 checks.

This is an API-overhead optimization, not a CUDA arithmetic or numerical-policy change. It does not reduce the number of copies or kernel launches.

## Change and dependency preservation

`src/cuda_spai.cu` remains the shared compact constructor body used by FP64 and the macro-specialized FP32 implementation. The change queues uploads/downloads and completes each same-stream copy group once at the pre-existing host observation boundary.

| Adaptive-fit stage | Copies | Host dependency | Treatment |
| --- | ---: | --- | --- |
| Fit metadata upload | pattern, shadow, candidates | gather/QR needs all inputs | queue three H2D copies, one completion |
| QR guard | QR `info` | triangular solve legality | required separate completion; unchanged |
| Fit result return | coefficients, diagnostics, fit status | host accepts/rejects fit | queue three D2H copies, one completion |
| Score result return | scores, statuses, clamps | host chooses adaptive growth | queue three D2H copies, one completion |

The copy order, streams, host lifetimes, QR breakdown behavior, score guard, candidate ordering, and host adaptive decisions are unchanged. Terminal completions were deliberately retained. Thus the QR guard and every fit/growth decision retain their required synchronization; only independent copies within a group no longer force independent waits.

## Focused correctness evidence

The following were rebuilt and run serially after the source change:

| Precision | Regression | Result |
| --- | --- | --- |
| FP32 | `fp32_cuda_spmv_tests` | passed |
| FP32 | `fp32_cuda_gmres_tests` | passed |
| FP32 | `fp32_cuda_spai_tests` | passed |
| FP64 | `cuda_spai_tests` | passed |
| FP64 | `cuda_spai_sparse_tests` | passed; 3,363,954 checks, 0 failures |

The campaign launcher then executed one child at a time, with three warm-ups and three retained measurements per configuration. It ran the independent Decimal80 checker only against each durable JSONL snapshot after its solver child exited. Both result directories contain eight accepted configurations:

- `results/experiment2a_adaptive_batch_fp32_20261012`
- `results/experiment2a_adaptive_batch_fp64_20261012`

Every one of the 16 solver return codes and 16 checker return codes is zero. The final FP64 progress event is the accepted `irregular_12000` GPU-pipeline configuration. No root experiment lock or benchmark process remained when this record was finalized.

## Nsight API and GPU-execution comparison

Each profile traces two `stencil_8192` constructor runs using the retained pre-batching and post-batching profiling workflows. Counts below are exact Nsight CSV values; GPU kernel time is the sum of the CUDA GPU kernel summary.

| Metric | FP32 before | FP32 after | FP64 before | FP64 after |
| --- | ---: | ---: | ---: | ---: |
| `cudaMemcpyAsync` calls | 276,008 | 276,008 | 276,008 | 276,008 |
| Kernel launches | 357,658 | 357,658 | 357,658 | 357,658 |
| `cudaStreamSynchronize` calls | 373,606 | 130,126 | 373,606 | 130,126 |
| Stream-sync API time (ms) | 945.376 | 368.855 | 862.106 | 392.766 |
| Summed GPU kernel time (ms) | 1,834.141 | 1,811.773 | 2,719.131 | 2,689.515 |

The synchronization-call reduction is 65.17% for both precisions. Stream-sync API time fell 60.98% in the FP32 trace and 54.44% in the FP64 trace. Copy and launch counts are intentionally unchanged, as are copy bytes under source-owned telemetry. The small GPU-kernel-time differences are not claimed as a kernel optimization: the changed code only affects host API waiting.

The pre/post traces were retained from comparable runner/matrix/warm-up settings, but were not captured back-to-back in one controlled profiling session. CUDA API timing is therefore supporting evidence, not a causal claim about the small copy/launch timing shifts. The call-count reduction and unchanged numerical work are the robust profiling result.

## Constructor and end-to-end timing

Values are median wall times in milliseconds across the three retained measured trials. Delta is after minus before; a negative value is faster. The before campaign is the completed memory-investigation campaign, so these comparisons should be interpreted with its documented run-to-run/environment limitation.

| Precision | Mode | Matrix | Before | After | Delta |
| --- | --- | --- | ---: | ---: | ---: |
| FP32 | GPU SPAI | stencil_8192 | 2304.1 | 2177.9 | -126.2 (-5.48%) |
| FP32 | GPU SPAI | irregular_8192 | 1193.3 | 1100.0 | -93.3 (-7.82%) |
| FP32 | GPU SPAI | stencil_12000 | 3394.9 | 3277.4 | -117.5 (-3.46%) |
| FP32 | GPU SPAI | irregular_12000 | 1815.8 | 1649.6 | -166.2 (-9.15%) |
| FP64 | GPU SPAI | stencil_8192 | 2516.0 | 2142.1 | -373.9 (-14.86%) |
| FP64 | GPU SPAI | irregular_8192 | 1283.3 | 1161.3 | -122.0 (-9.51%) |
| FP64 | GPU SPAI | stencil_12000 | 3777.1 | 3197.0 | -580.1 (-15.36%) |
| FP64 | GPU SPAI | irregular_12000 | 1869.5 | 1650.2 | -219.4 (-11.73%) |
| FP32 | Pipeline | stencil_8192 | 2541.3 | 2410.5 | -130.8 (-5.15%) |
| FP32 | Pipeline | irregular_8192 | 1401.9 | 1494.7 | +92.8 (+6.62%) |
| FP32 | Pipeline | stencil_12000 | 3901.2 | 3736.8 | -164.4 (-4.21%) |
| FP32 | Pipeline | irregular_12000 | 2136.2 | 2150.8 | +14.6 (+0.68%) |
| FP64 | Pipeline | stencil_8192 | 5272.5 | 4797.7 | -474.8 (-9.00%) |
| FP64 | Pipeline | irregular_8192 | 3785.2 | 3415.1 | -370.0 (-9.78%) |
| FP64 | Pipeline | stencil_12000 | 9847.9 | 7893.9 | -1954.0 (-19.84%) |
| FP64 | Pipeline | irregular_12000 | 7637.8 | 6272.0 | -1365.8 (-17.88%) |

Constructor medians improved in every retained FP32 and FP64 case. The complete FP64 pipeline also improved in all four cases. FP32 full-pipeline timing is mixed (two improvements and two small/medium regressions), which is expected to be more sensitive because it includes existing GMRES/IR work beyond the constructor. No numerical acceptance regression accompanied either result.

## Allocation and transfer telemetry

The representative post-change FP32 `stencil_8192` constructor recorded 512 allocations/frees, 399 reallocations, 2,099,640 bytes cumulatively allocated and freed, and a 1,600,024-byte peak. It performed 48,776 uploads (4,603,052 bytes) and 89,228 downloads (2,181,400 bytes); nearly all transfers were at most 256 bytes. This batching change leaves those allocation and transfer volumes alone. It specifically addresses repeated host waits around already-required tiny-copy sets.

## Conclusion and next direction

The evidence supports accepting this limited batching correction: it preserves all focused and Decimal80 numerical checks, removes roughly two-thirds of observed stream-synchronization API calls, and shows consistently lower isolated constructor medians. There is no evidence of an FP32 or FP64 numerical regression. Full-pipeline performance is not uniformly improved for FP32, so no broader speedup claim is warranted.

If optimization is later authorized, the evidence points to reducing the remaining very-small transfer count rather than changing the numerical method: pack the score/status/clamp outputs into a lifetime-safe per-candidate result layout (or otherwise consolidate their D2H traffic), then repeat the same numerical and profiling gates. That is a future proposal only; it was not implemented in this experiment.
