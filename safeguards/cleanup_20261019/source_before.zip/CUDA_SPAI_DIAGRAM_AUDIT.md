# CUDA SPAI Diagram Verification

## Verdict

The diagram is **partly correct** for the native CUDA binary64 path. Its
adaptive-fit and CPU-outer-refinement portions are substantially correct, but
the preprocessing location and final preconditioner-assembly/handoff path need
revision.

## Box-by-box verification

| Diagram element | Verdict | Source-backed correction |
|---|---|---|
| CPU preprocessing: `D_ii = 1/max_j |A_ij|`, `B=A^T D` | Incorrect | The GPU `scale_matrix` kernel computes `D` and sparse `B`; host code receives copies afterward for adaptive metadata. See `src/cuda_spai.cu`, lines 185-196. |
| CPU adaptive control: patterns, candidates, growth | Correct | Host code controls patterns/candidates and the growth decisions. |
| Bounded GPU streams / restricted-matrix assembly | Correct | GPU gathers reduced matrices through bounded stream slots. See `src/cuda_spai.cu`, lines 200-244. |
| cuSOLVER QR / cuBLAS triangular solve | Correct | GPU QR, `Q^T` application, and triangular solution produce the fitted coefficients. See lines 241-264. |
| GPU residual / candidate scoring | Correct | Device kernels compute residuals and scores; score data returns to the CPU for adaptive decisions. See lines 252-271. |
| CPU assembles `N`; forms `P=N^T D` | Incorrect | CPU packs final `N` metadata and coefficients, but the GPU computes the packed numerical `P` values. See lines 290-303. |
| Upload directly to GPU GMRES | Incomplete | Packed GPU `P` values first return to CPU; CPU canonicalizes CSR `N` and `P`; then canonical CSR `P` is uploaded to GPU GMRES. |
| GPU GMRES applies `P(A v)` | Correct | The GPU Arnoldi operator applies `A`, then `P`. See `src/cuda_gmres.cu`, lines 190-192. |
| CPU outer refinement: `r=b-Ax`, backward error | Correct | CPU creates `x0=P*b`, calculates original-system diagnostics, calls GPU GMRES, and applies the returned correction. See `src/cuda_ir.cpp`, lines 33-57. |

## Required diagram changes

Replace the initial CPU-preprocessing box with:

> **GPU scaling / sparse B construction**  
> Upload CSR A; compute `D_ii = 1/max_j |A_ij|` and `B=A^T D`; download host copies needed for adaptive metadata.

Replace the final CPU-assembly box and its single upload arrow with this path:

```text
CPU packs final sparse-N metadata and fitted coefficients
        │ H2D: packed row indices + N coefficients
        ▼
GPU packed-P assembly: P[k,j] = N[j,k] d[j]
        │ D2H: packed P values
        ▼
CPU canonicalizes CSR N and P
        │ H2D once: canonical CSR A and P
        ▼
Persistent GPU GMRES: apply P(A v)
```

The relevant source is `src/cuda_spai.cu`, lines 290-303; the persistent
binary64 GMRES context uploads canonical CSR matrices in `src/cuda_gmres.cu`,
lines 121-146 and 218-231.

Add an explicit arrow from CPU outer refinement to GPU GMRES labeled:

> residual `r` and zero correction initial guess (H2D)

The existing GPU-to-CPU correction arrow is correct. CPU outer refinement
applies that correction and evaluates original residual/backward error. The
GPU GMRES implementation independently verifies its preconditioned residual.

## Corrected end-to-end meaning

The CUDA construction path uses GPU kernels for scaling, least-squares fits,
residual/scoring work, and the final packed numerical `P=N^T D` operation. CPU
logic handles adaptive metadata and sparse CSR canonicalization. Before the
first binary64 GMRES iteration, the GPU-produced packed `P` is downloaded,
canonicalized as host CSR, and uploaded with canonical `A` into one persistent
GPU GMRES context. The outer iterative-refinement loop remains CPU-staged.
