# PCAP repository cleanup and organization audit

**Audit date:** 12 October 2026 (Asia/Kolkata)  
**Scope:** read-only organization audit. No files were moved, renamed, deleted,
reset, cleaned, built, tested, benchmarked, or numerically executed.

## Pre-audit protection checkpoint

The repository was captured before this audit at branch `stage4-scalable-spai`,
HEAD `8eac10eec719bf24d55e219884d7a35bcd25aaaa`, with dirty description
`stage45a-validated-baseline-dirty`. A complete pre-audit inventory is preserved
under `safeguards/checkpoints/20261012T044330/`, including raw Git status,
tracked/modified/untracked inventories, directory sizes, a state manifest, and a
recovery checklist.

A separate non-destructive backup was verified at
`C:\Users\Anirudh\Desktop\pcapproj_checkpoint_20261012T041000`. It contains
2,097 files / 1,316,551,917 bytes, including `.git`, dirty/untracked source,
documentation, scripts, data, and all raw results. Only the independently
regenerable `build/` tree was excluded. No relevant benchmark, Python, or Nsight
process was found. A `RUN_LOCK.json` under the historical 12k persistent output
is retained as evidence; it is not a current root experiment lock.

The current research direction is a separate ChatGPT conversation's
literature-driven GPU-SPAI architecture review. BSPAI implementation has not
started.

## Current layout and purpose

| Location | Purpose | Classification |
| --- | --- | --- |
| `.git/` | local history, index, tags, dirty-worktree basis | PRESERVE |
| `.codex/agents/` | project-specific specialist definitions | PRESERVE |
| `src/`, `include/` | FP64 baseline and uncommitted FP32/CUDA implementation | PRESERVE |
| `tests/` | unit, CUDA, Decimal80, validation-only, and benchmark harness sources | PRESERVE |
| `cuda/`, root `CMakeLists.txt`, `cuda/CMakeLists.txt` | CPU/CUDA build topology | PRESERVE in place |
| `scripts/` | build, locking, matrix generation, profiling, and campaign runners | PRESERVE in place |
| `data/` | immutable matrices, manifests, provenance | PRESERVE as sets |
| `benchmarks/` | benchmark case declarations | PRESERVE |
| `results/` | raw snapshots, Decimal80 sidecars, manifests, logs, matrices, profiles, plots | PRESERVE; organize only by approved migration |
| `build/` | CMake/Ninja/CUDA generated trees | SAFE to regenerate; no action now |
| `docs/` | specifications, milestone reports, validation record, live handoff | PRESERVE |
| root `*.md` reports | handoff, index, Experiment 2A and Stage 4.5 reports | PRESERVE pending coordinated documentation migration |
| `manuscript/` | unmodified IEEE template and assets | PRESERVE |
| `papers/` | currently empty local research-material placeholder | PRESERVE directory |
| `safeguards/checkpoints/` | this checkpoint's recovery material | PRESERVE |

Bootstrap files must remain at their current paths: `AGENTS.md`,
`PROJECT_HANDOFF.md`, `CODEBASE_GUIDE.md`, `PAPER_INDEX.md`, root and CUDA CMake
files, `.codex/agents/`, and the source/include/tests/scripts/data/results
topology. `docs/EXPERIMENT2A_LIVE_HANDOFF.md` and
`docs/EXPERIMENT2A_FP32_SPEC.md` should also remain until all bootstrap and
cross-document references are migrated together.

## Space inventory

The live repository is approximately 1.66 GiB including `.git`.

| Category | Size | Notes |
| --- | ---: | --- |
| `results/` | 1,127.18 MiB | primary experimental evidence; 915 files |
| `build/` | 398.87 MiB | generated CMake/Ninja/CUDA output |
| `.git/` | 116.63 MiB | recovery/history; do not prune in this task |
| `data/` | 9.33 MiB | immutable inputs/provenance |
| source/tests/scripts/docs/manuscript | about 2.1 MiB | source and documentation |

Large evidence classes in `results/` are 450.98 MiB of four Nsight SQLite
exports, 373.32 MiB of JSONL, 277.34 MiB of six `.nsys-rep` traces, and 24.10 MiB
of generated fixed-P Matrix Market files. The latter three are raw provenance or
trace evidence and are not deletion candidates.

Potential later space recovery, subject to approval and a new verification:

| Candidate | Estimated saving | Action class | Reason |
| --- | ---: | --- | --- |
| whole `build/` tree | 398.87 MiB | SAFE | all observed contents are generated build output |
| `validation_fp32_cuda_probe.obj` | 0.09 MiB | SAFE | generated root object file |
| `__pycache__/` | small | SAFE | generated Python bytecode |
| four Nsight `.sqlite` exports | 450.98 MiB | REVIEW | likely re-exportable from preserved `.nsys-rep`, but retain through final report review |

Archiving results changes organization but does **not** reclaim meaningful space.
No raw JSONL, Decimal80 sidecar, matrix, manifest, progress log, profile trace,
CSV, plot, or report is safe to delete from the current evidence set.

## Significant evidence and historical outputs

### Preserve as validated/current evidence

- `results/experiment2a_fp32_vs_fp64_stencil8192_20261012/` and
  `results/experiment2a_fp32_vs_fp64_remaining_20261012/`: complete precision
  timing campaign, fixed-P artifacts, 288 retained records, and Decimal80
  sidecars.
- `results/experiment2a_gpu_spai_memory_fp32_20261012/` and `_fp64_.../`:
  memory/synchronization optimization evidence.
- `results/experiment2a_adaptive_batch_fp32_20261012/` and `_fp64_.../`:
  completed batching campaigns.
- `results/experiment2a_fp32_spai_profile_fp32_retry_20261012/`,
  `...profile_fp64_.../`, `experiment2a_adaptive_batch_profile_fp32_.../`, and
  `_fp64_.../`: retained before/after profiling evidence. Preserve each
  `.nsys-rep`, SQLite, CSV, and manifest together.
- `results/stage45a_validation/`, `results/stage45a_extension/`, all
  `results/stage45b_*` completed collections, their aggregations, and all input
  datasets/manifests/provenance. These support existing Stage 4.5 reports and
  should remain available for final documentation.
- One-off saved FP32 validation snapshots in `results/experiment2a_fp32_*.jsonl`.

### Archive, do not delete, after approval

These are historical but useful for methodology, exclusions, or reproduction:

- `results/experiment2a_fp32_spai_phase_fp32_20261012/` and `_fp64_.../`:
  earlier diagnostic traces.
- `results/experiment2a_fp32_spai_direct_phase_fp32_20261012/` and `_fp64_.../`:
  manifest-only direct observations.
- `results/experiment2a_fp32_spai_profile_fp32_20261012/`: failed profiler
  attempt with manifest only; retain the failure reason.
- `results/stage45b_fp64_12000_retry_20261011/`: empty/near-empty retry record.
- overlapping 12k historical folders (`stage45b_fp64_12000_20261011/` and
  `stage45b_fp64_12000_persistent_20261011/`): retain as non-timing evidence,
  exactly as documented in the handoff and Stage 4.5B reports.

None are proven duplicates. The profile directories in particular are distinct
pre/post or failed-attempt evidence, not replaceable copies.

## Documentation assessment

The repository has a sound division between binding specs/validation under
`docs/`, active bootstrap/handoff files at root, and accumulated root-level Stage
4.5 / Experiment 2A reports. The primary organization problem is location and
chronology, not duplicate content.

Suggested future documentation destination, after a reference migration:

```text
docs/
  handoff/                 # historical handoffs; keep active handoff stub/path
  specs/                   # algorithm, validation, FP32 frozen requirements
  validation/              # Phase 2B and independent validation records
  milestones/              # CPU/CUDA milestone and Stage 1--4 reports
  reports/
    experiment2a/          # FP32, timing, memory, adaptive-overhead reports
    stage45a/
    stage45b/
  plans/                   # experiment plans and release-admission planning
```

Proposed moves are REVIEW, not commands to execute:

- Root `EXPERIMENT2A_*.md` -> `docs/reports/experiment2a/`.
- Root `STAGE45A_*.md` -> `docs/reports/stage45a/`; root `STAGE45B_*.md` ->
  `docs/reports/stage45b/`.
- Existing `docs/CPU_MILESTONE*.md`, `CUDA_MILESTONE*.md`, and
  `CUDA_STAGE*.md` -> `docs/milestones/`.
- Existing `docs/PHASE*_ALGORITHM_SPEC.md`, `PHASE*_VALIDATION_PLAN.md`, and
  `EXPERIMENT2A_FP32_SPEC.md` -> `docs/specs/`; the authoritative Phase 2B
  validation record -> `docs/validation/`.

Keep `AGENTS.md`, `PROJECT_HANDOFF.md`, `CODEBASE_GUIDE.md`, `PAPER_INDEX.md`,
and the active Experiment 2A handoff in their current locations. If historic
handoffs are later split out, leave a concise current-path redirect/index rather
than breaking bootstrap instructions.

## Move and dependency risks

1. `cuda/CMakeLists.txt` compiles `../src/*`, exposes `../include`, and wires
   `../tests/*`; `tests/cuda_spai_allocation_audit.cu` directly includes
   `../src/cuda_spai.cu`. Moving source/include/tests independently will break
   configuration and validation references.
2. Experiment scripts hard-code the two immutable data locations,
   `results/STAGE45B_EXPERIMENT_LOCK.json`, and root-relative layout. Several
   calculate the project root using `Path(__file__).resolve().parents[1]`; moving
   scripts deeper silently changes that meaning.
3. `scripts/build_cuda_msvc.cmd`, validation scripts, reports, and live handoffs
   contain build paths and some machine-specific CUDA/Visual Studio/Python paths.
   These should be refactored only as a separate portability change, never as an
   incidental file move.
4. Data manifests use relative matrix/provenance paths. Result manifests and
   progress records contain absolute source/build/data/checker paths. Move an
   evidence directory only as an intact tree and preserve either its original
   path or a documented immutable migration map.
5. Root reports, handoffs, and docs contain many relative Markdown links to
   reports and exact result paths. Moving any report requires a repository-wide
   Markdown-link audit plus updates to `PROJECT_HANDOFF.md`, `CODEBASE_GUIDE.md`,
   `AGENTS.md`, the live handoff, and affected reports.

## Proposed target structure for results

Do not create this structure yet. After a migration plan is approved, retain
each campaign directory as an atomic unit under a stable category:

```text
results/
  validated/
    experiment2a/{fp32-validation,precision-timing,memory-optimization,adaptive-batching}/
    stage45a/{validation,extension}/
    stage45b/{clean-12000,scalability,exploratory,aggregations}/
  profiles/
    experiment2a/{pre-batching,post-batching,historical-diagnostics,failed-attempts}/
  archive/
    experiment2a/{manifest-only,failed-profile-attempt}/
    stage45b/{overlapped-or-superseded-attempts}/
```

`data/` should remain at its current root-level path initially. A future
`data/immutable/<dataset>/` hierarchy is possible only after every launcher,
manifest, provenance entry, report, and checker reference is migrated and tested.

## Precise phased cleanup plan -- for approval only

### Phase 0: protection and evidence freeze -- completed

- **PRESERVE:** checkpoint inventories and verified sibling backup.
- **PRESERVE:** all dirty/untracked source and raw evidence.
- **PRESERVE:** current file paths; no cleanup was performed.

### Phase 1: approve classifications and freeze a migration manifest

1. Review this report and explicitly approve or reject the proposed target
   hierarchy.
2. Generate a file-to-destination migration manifest with SHA-256 hashes for
   every `results/` tree, data set, and report before any move.
3. **PRESERVE:** leave all evidence in place until both the manifest and a second
   recovery copy are verified.

### Phase 2: generated-artifact cleanup, separately approved

1. **SAFE:** remove the entire `build/` tree only after confirming no active
   compiler/benchmark process and retaining the documented configure commands.
2. **SAFE:** remove `validation_fp32_cuda_probe.obj` and ignored Python caches.
3. **REVIEW:** do not remove Nsight SQLite exports until a final-report reviewer
   confirms the retained `.nsys-rep` files and CSV exports are sufficient, and
   records the Nsight re-export command/tool version.

### Phase 3: documentation migration

1. Move reports/specifications in small coherent groups to the proposed `docs/`
   hierarchy; retain root bootstrap files in place.
2. Update all Markdown links and bootstrap references in the same change.
3. Run a non-executing link/path audit and inspect Git diff; do not run numerical
   work merely to organize files.
4. Add a `docs/README.md` index that distinguishes current contracts, validated
   records, historical reports, and future-work material.

### Phase 4: results/data archive migration

1. Move one completed campaign tree at a time, never individual JSONL/sidecar/
   manifest files.
2. Update known script/report links and create `results/MIGRATION_MAP.md` with
   old path, new path, purpose, status, and hash.
3. Leave the active `results/STAGE45B_EXPERIMENT_LOCK.json` location unchanged;
   historical lock files remain inside their archived campaign directories.
4. Validate only paths/hashes/manifests after each move. Do not rerun benchmarks
   to compensate for a migration.

### Phase 5: final verification and documentation-ready state

1. Compare post-migration hashes and file counts with the frozen migration
   manifest and backup.
2. Check every CMake/source/script path and Markdown link.
3. Update handoffs with the new stable layout and a restoration procedure.
4. Create a new backup before any BSPAI implementation or final-report writing.

## Approval boundary

This audit recommends only one large SAFE space-recovery target (`build/`, about
399 MiB) and two tiny generated categories. Everything else is PRESERVE or
REVIEW. No cleanup has been executed. Any deletion, move, rename, archive, or
reference update requires a separate explicit approval and a hash-verified,
reversible transaction plan.
