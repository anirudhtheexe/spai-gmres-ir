# Experiment 2A — Stage A: Persistent GPU Fit State and Transfer Consolidation

## Outcome

Stage A is complete. The shared CUDA SPAI constructor now transfers each candidate-scoring result as one exact-layout record rather than three separate arrays. This bounded data-movement change does not alter the adaptive algorithm, host-side decisions, QR/triangular solve sequence, stream ordering, numerical thresholds, FP32 contract, or FP64 arithmetic.

The post-change profiler establishes a reduction of `32,260` CUDA asynchronous copy calls per two-construction stencil-8192 trace (`11.688%`) in both precisions. Focused regressions, CUDA memcheck, and all saved-snapshot Decimal80 campaign checks passed. The four-matrix wall-clock evidence is mixed, so this report makes no uniform runtime-speedup claim.

## Scope and implementation

The shared implementation is [src/cuda_spai.cu](src/cuda_spai.cu); FP32 is macro-specialized through [src/fp32_cuda_spai.cu](src/fp32_cuda_spai.cu). The constructor already retained bounded stream slots, cuSOLVER/cuBLAS handles, and capacity-reused device buffers through the adaptive phase. Stage A replaces the three same-boundary D2H arrays—score scalar, candidate status, and clamp flag—with one `ScoreWire { scalar score; int status; int clamped; }` array.

`ScoreWire` is compile-time checked to occupy exactly one scalar plus two `int`s. The score kernel writes that record directly; the host downloads one record array only after the fitted residual and its required acceptance checks. Score ordering, clamp accounting, mean/filtering, stable ties, and pattern growth retain their prior host-controlled ordering. No packing kernel was added and transfer bytes are unchanged.

For a successful construction the targeted tests assert:

```
downloads = 5 + 4 * fits + growths
```

Before Stage A the final term was `3 * growths`. For the frozen stencil-8192 case (`fits=16,257`, `growths=8,065`), downloads change from `89,228` to `73,098`: exactly `16,130` fewer D2H copies per construction.

## Lifecycle audit

| Data/state | Lifetime and required boundary | Stage A disposition |
|---|---|---|
| Matrix CSR, scaling, sparse scaled transpose | setup / entire construction | persistent buffers retained |
| Slot stream, library handles, QR/residual workspaces | one of up to eight slots / adaptive phase | already persistent; retained |
| pattern, shadow, candidate metadata | rebuilt per adaptive fit | retained |
| QR status | before triangular solve | retained |
| coefficients, diagnostics, fit status | before fit acceptance/failure | retained |
| candidate score/status/clamp outputs | before host growth decision | consolidated into one exact record |
| host histories and `slot.fit` vectors | adaptive scheduling and selection | retained on host |

No host-controlled adaptive decision moved to the GPU. No added device-to-device transfer, synchronization, or numerical policy was introduced.

## Focused correctness and safety gates

Both CUDA build trees were rebuilt from the shared-source change. The following serial gates passed:

| Gate | Result |
|---|---|
| FP32 CUDA SpMV, GMRES, and SPAI tests | pass |
| FP32 GPU-SPAI-to-IR focused case | one accepted correction; final BE `1.98682145e-07` |
| FP64 CUDA SPAI test | pass |
| FP64 independent sparse CUDA SPAI test | `3,363,954` checks, `0` failures |
| Compute Sanitizer memcheck of focused shared constructor | `ERROR SUMMARY: 0 errors`; `1,539` checks, `0` failures |

The added FP32/FP64 SPAI test assertion checks the new transfer accounting. The FP32 fixed-`P` gate retained CPU/GPU GMRES iteration counts `3/3`.

## Profiling evidence

Nsight Systems used immutable stencil-8192, one warm-up and one sample per trace (two constructions per trace). The valid after traces are `results/experiment2a_stage_a_profile_fp32_retry_20261012` and `results/experiment2a_stage_a_profile_fp64_retry_20261012`. They were collected only after relinking the benchmark drivers against the modified source. Earlier same-day Stage A trace directories are preserved, but their manifests identify pre-edit executable timestamps and they are not used as after evidence.

| Metric (two constructions) | Post-batching baseline | Stage A FP32 | Stage A FP64 |
|---|---:|---:|---:|
| `cudaMemcpyAsync` calls | 276,008 | 243,748 | 243,748 |
| reduction | — | 32,260 (11.688%) | 32,260 (11.688%) |
| kernel launches | 357,658 | 357,658 | 357,658 |
| stream synchronizations | 130,126 | 130,126 | 130,126 |
| `cudaMalloc` / `cudaFree` calls | 1,136 / 1,184 | 924 / 972 | 924 / 972 |

The copy-call reduction exactly equals `2 * 8,065 growths * 2 constructions`. Copy API elapsed time varied across separate traces (baseline/after: FP32 `2747/2306` ms, FP64 `2602/2291` ms), so it is supporting diagnostic evidence, not controlled timing proof.

## Serial four-matrix campaign

The existing root-locked runner processed one child at a time: solver first, durable JSONL second, then a snapshot-only Decimal80 checker. Each configuration has three warm-ups and three retained measured trials. Raw records, manifests, progress logs, summaries, and Decimal80 sidecars are retained under `results/experiment2a_stage_a_fp32_20261012` and `results/experiment2a_stage_a_fp64_20261012`.

All 16 configurations returned solver/checker code zero. Every Decimal80 sidecar reports three accepted measured snapshots and no failures: 48 accepted measured assessments in total. The root lock is absent after completion.

### Numerical preservation

| Matrix | P nnz | fits / growths | FP32 inner iters | FP32 BE | FP64 BE |
|---|---:|---:|---:|---:|---:|
| stencil_8192 | 40,197 | 16,257 / 8,065 | 15 | `7.407e-08` | `1.380e-16` |
| irregular_8192 | 11,870 | 9,139 / 947 | 17 | `7.371e-08` | `1.373e-16` |
| stencil_12000 | 59,205 | 23,881 / 11,881 | 15 | `7.164e-08` | `1.334e-16` |
| irregular_12000 | 17,379 | 13,386 / 1,386 | 17 | `7.371e-08` | `1.373e-16` |

All native pipelines used two accepted outer corrections. FP32 values are below `10*2^-24 = 5.96046448e-07`; FP64 values are below `10*2^-53 = 1.11022302e-15`. Construction counts and compact `P` output are identical by precision on each frozen input.

### Median wall-clock comparison

These are three-trial medians of the public API timing bracket, compared with the retained post-batching campaign. They are exploratory host-wall-clock measurements on one machine, not a general speedup or scalability claim.

| Precision | Matrix | GPU SPAI before → after (ms) | change | GPU pipeline before → after (ms) | change |
|---|---|---:|---:|---:|---:|
| FP32 | stencil_8192 | 2222.4 → 1980.3 | -10.89% | 2542.8 → 2203.6 | -13.34% |
| FP32 | irregular_8192 | 1167.9 → 1084.4 | -7.15% | 1548.4 → 1421.4 | -8.20% |
| FP32 | stencil_12000 | 3305.6 → 3060.0 | -7.43% | 3815.9 → 3434.6 | -9.99% |
| FP32 | irregular_12000 | 1675.1 → 1771.4 | +5.75% | 2252.0 → 2061.2 | -8.47% |
| FP64 | stencil_8192 | 2160.4 → 2011.6 | -6.89% | 4862.5 → 4911.1 | +1.00% |
| FP64 | irregular_8192 | 1163.6 → 1127.2 | -3.12% | 3492.1 → 3557.5 | +1.87% |
| FP64 | stencil_12000 | 3475.1 → 3157.4 | -9.14% | 8326.1 → 11559.2 | +38.83% |
| FP64 | irregular_12000 | 1653.1 → 1694.9 | +2.53% | 6585.1 → 7551.7 | +14.68% |

The copied-score call reduction is real and deterministic. Construction medians generally improve except both irregular-12000 cases, while end-to-end pipeline changes are mixed—particularly FP64. Stage A must therefore not be credited with a uniform end-to-end speedup.

## Conclusion and next direction

Stage A is accepted as an overhead reduction with preserved numerical behavior: one required score-decision transfer replaces three, no asynchronous memory error was observed, and all saved numerical acceptance checks passed. It does not justify further source optimization within this task. A possible future direction is a separately authorized investigation of the still-dominant tiny launch/copy protocol; it must begin with a new lifecycle/decision-boundary audit and must not be conflated with BSPAI or mixed precision.
