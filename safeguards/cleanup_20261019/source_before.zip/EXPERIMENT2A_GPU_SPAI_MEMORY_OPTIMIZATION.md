# Experiment 2A — GPU SPAI memory movement, allocation, and synchronization investigation

Date: 12 October 2026 (Asia/Kolkata)

## Outcome

The smallest source change removed only redundant explicit stream-completion calls immediately following `download()`, whose helper has already synchronized.  FP32 and FP64 constructors share this source.  No precision contract, tolerance, adaptive rule, CUDA library call, arithmetic order, or FP64 numerical policy changed.

Focused regressions passed serially: `fp32_cuda_spai_tests`, `cuda_spai_tests`, and `cuda_spai_sparse_tests` (the latter reports 3,363,954 checks and zero failures).  The post-change FP32 and FP64 campaigns each completed all four immutable matrices, GPU SPAI and GPU pipeline modes, three warm-ups plus three measured trials, one child at a time.  All 16 solver configurations and all 16 snapshot-only Decimal80 checks returned zero and were accepted.

## Persisted evidence

- FP32: `results/experiment2a_gpu_spai_memory_fp32_20261012`
- FP64: `results/experiment2a_gpu_spai_memory_fp64_20261012`
- Pre-change timing baseline: `EXPERIMENT2A_FP32_VS_FP64_TIMING.md`
- API/kernel timeline evidence: `results/experiment2a_fp32_spai_profile_fp32_retry_20261012` and `results/experiment2a_fp32_spai_profile_fp64_20261012`

Each campaign owns the shared root lock and retains raw JSONL, progress, manifest, and Decimal80 sidecars.  No solver/profile overlap occurred.

## Measured wall-clock medians (ms)

| Matrix | FP32 SPAI before | FP32 SPAI after | FP64 SPAI before | FP64 SPAI after | FP32 pipeline before/after | FP64 pipeline before/after |
|---|---:|---:|---:|---:|---:|---:|
| stencil_8192 | 4749.039 | 2304.056 | 2330.408 | 2516.041 | 5319.885 / 2541.265 | 4623.705 / 5272.478 |
| irregular_8192 | 1205.311 | 1193.276 | 1196.168 | 1283.290 | 1399.321 / 1401.880 | 3443.308 / 3785.154 |
| stencil_12000 | 3443.374 | 3394.901 | 3366.789 | 3777.116 | 3881.610 / 3901.195 | 7265.036 / 9847.862 |
| irregular_12000 | 1720.603 | 1815.801 | 1781.563 | 1869.513 | 2204.227 / 2136.243 | 5396.701 / 7637.787 |

The new FP32 stencil_8192 result is 51.49% lower than its historical timing.  This is **not** evidence that the redundant-sync removal caused that reduction: before the change, the retained direct diagnostic already measured 2292.869 ms FP32 and 2326.814 ms FP64 on the same matrix.  The defensible finding is that the historical FP32 outlier did not reproduce; run-to-run/environmental variation remains unresolved.  No speedup claim is made for the source change.  The new FP64 pipeline medians are higher than the earlier baseline and reinforce that limitation.

## Allocation and transfer evidence

The new constructor telemetry measures source-issued allocations only: it excludes CUDA context, cuBLAS/cuSOLVER internal allocations, CUDA allocator caching, and OS Task Manager categories.  In every measured construction, source-owned current bytes and outstanding allocations were zero at return.

| Matrix | FP32 peak / cumulative allocation B | FP64 peak / cumulative allocation B | FP32 H2D / D2H calls | FP64 H2D / D2H calls |
|---|---:|---:|---:|---:|
| stencil_8192 | 1,600,024 / 2,099,640 | 2,449,696 / 3,436,792 | 48,776 / 89,228 | 48,776 / 89,228 |
| irregular_8192 | 1,260,696 / 2,054,156 | 2,003,728 / 3,622,728 | 27,422 / 39,402 | 27,422 / 39,402 |
| stencil_12000 | 2,268,824 / 2,768,440 | 3,437,664 / 4,424,760 | 71,648 / 131,172 | 71,648 / 131,172 |
| irregular_12000 | 1,704,776 / 2,504,716 | 2,654,616 / 4,286,528 | 40,163 / 57,707 | 40,163 / 57,707 |

FP32 detailed telemetry is decisive about granularity: only five H2D transfers per construction exceed 4096 bytes, while 48,771 of 48,776 stencil_8192 H2D transfers are at most 256 bytes; 89,224 of 89,228 D2H transfers are at most 256 bytes.  The same pattern holds on the other matrices.  Allocation/free wall time is approximately 1–4.5 ms and cannot explain multi-second construction time.  Adaptive fits account for almost all FP32 constructor wall time (2284.001, 1193.581, 3377.933, and 1804.825 ms in matrix order).

The earlier Nsight trace independently reported, for two stencil_8192 constructions per precision, 276,008 `cudaMemcpyAsync`, 357,658 kernel launches, and 373,606 `cudaStreamSynchronize` calls.  FP32 kernel time was lower than FP64.  Together, these results support host/API granularity and forced copy-lifetime synchronization as the dominant bounded hypothesis; they do not establish a Task Manager VRAM or shared-memory measurement.

## Task Manager interpretation

`cudaMemGetInfo` is CUDA-context free/total availability.  It must not be equated with Task Manager Dedicated GPU Memory, Shared GPU Memory, process working set, committed memory, or source-owned allocations.  This experiment did not collect DXGI/WDDM/NVML per-process Task Manager counters, so no claim about those categories is made.

## Decision

The focused correction is numerically accepted and fully documented.  Stop here: no batching/reordering of copies, allocator redesign, additional optimization, BSPAI, mixed precision, or benchmark repetition was performed or is implied by these data.
