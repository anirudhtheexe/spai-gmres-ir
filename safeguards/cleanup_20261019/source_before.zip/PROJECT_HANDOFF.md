# BSPAI–GMRES–IR Project Handoff

## BSPAI Stage 0 preservation and feasibility audit (13 October 2026)

**Superseding preservation update:** the complete rollback snapshot now exists
at `C:\Users\Anirudh\Desktop\pcapproj_pre_bspai_20261013T012111`. It contains
3,285 regular files / 2,504,039,817 bytes, matching the active source inventory
and byte total after the Stage 1 planning documents were added. A post-copy
comparison required no updates; `.git` is present and resolves to
`8eac10eec719bf24d55e219884d7a35bcd25aaaa`. Use this snapshot to restore the
pre-BSPAI project; do not modify it during future BSPAI work.

The requested pre-BSPAI full preservation attempt found the active repository on
`stage4-scalable-spai` at `8eac10eec719bf24d55e219884d7a35bcd25aaaa` with
deliberate tracked modifications and material untracked Stage 4.5/Experiment 2A
work. No active experiment lock, writer, solver, test, build, or profiler was
observed. The full 3,274-file / 2,503,416,551-byte copy failed because the
destination disk exhausted; its incomplete directory was removed. Therefore
**no verified full current recovery snapshot exists**. The source-side SHA-256
inventory is `safeguards/bspai_stage0_20261013/PCAP_PRE_BSPAI_FILE_MANIFEST.csv`
(manifest hash `8E1098C48C74F3DFFA2EAEA2E760D55C97D761CE708CE13C68DE527516482387`).
Do not begin BSPAI work until storage permits complete destination-hash
verification. See `PCAP_PRE_BSPAI_BASELINE.md`.

`BSPAI_STAGE0_FEASIBILITY_AUDIT.md` and `BSPAI_RESEARCH_AGENT_HANDOFF.md`
record the read-only source/literature audit. Published Khan--Carson full text
confirms bucketed (not block) SPAI and post-construction bucketing of P; the
threshold norm, conversion, and GPU-representation details still require a
source-backed specification. No numerical source, tolerance, benchmark,
profiler, or solver execution changed.

## IEEE final benchmark evidence completion (12 October 2026)

The user-authorized evidence-only campaign is complete. Fresh current-Stage-A FP64 and FP32 serial CPU/GPU scaling each covered stencil and irregular inputs at `n=1024, 2048, 4096, 8192, 12000`, with CPU/GPU SPAI construction, same-serialized-`P` fixed GMRES, and native pipeline scopes. Each precision has 60 configurations, three warm-ups plus three retained trials per configuration, and a post-solver saved-snapshot Decimal80 sidecar. All 120 configurations and 360 measured trials were accepted; no root lock, solver, benchmark, or profiler remains active. Independent validation found no missing artifacts or numerical anomaly.

The report entry point is `IEEE_FINAL_BENCHMARK_EVIDENCE.md`; the complete package is `results/ieee_final_evidence_20261012/`. It distinguishes historic exploratory observations from the fresh controlled series. The bounded result is a family-dependent FP64 GPU-SPAI scaling crossover/change (stencil at 8k, both families at 12k), not a universal pipeline crossover; fixed-P GPU GMRES remains slower on every tested size, and FP32 GPU does not cross CPU through 12k under its frozen uniform policy. Valid batching/Stage-A API-count evidence and mixed Stage-A wall-clock results are incorporated without a uniform speedup claim. Do not rerun the completed campaign, start another optimization, profiling run, BSPAI, or mixed precision without new authorization.

## Repository-organization checkpoint (12 October 2026)

Before documentation/repository organization, a recoverable state checkpoint was
created at `safeguards/checkpoints/20261012T044330` and a separate full backup
(excluding only `build/`) was verified at
`C:\Users\Anirudh\Desktop\pcapproj_checkpoint_20261012T041000`. The checkpoint
records HEAD, branch, complete changed/untracked inventories, evidence locations,
and recovery instructions. No cleanup, move, rename, deletion, build, solver, or
test is authorized by this audit. A separate ChatGPT conversation is conducting a
literature-driven GPU-SPAI architecture review; BSPAI implementation has not
started. The current organization task must stop after its proposed cleanup plan.

## Experiment 2A adaptive-fit batching completion (12 October 2026)

The focused shared FP32/FP64 CUDA-SPAI batching correction is complete and
validated. It queues the three independent metadata/result copies in each
adaptive-fit group and waits once at the unchanged required host-dependency
boundary; it changes neither CUDA arithmetic nor numerical policy. Focused FP32
and FP64 regressions passed, and the two serial four-matrix FP32/FP64 campaigns
completed all 16 GPU-SPAI/GPU-pipeline configurations with saved-snapshot Decimal80
acceptance. The finished evidence, including the 65.17% reduction in profiled
`cudaStreamSynchronize` calls and the qualified timing comparison, is in
`EXPERIMENT2A_GPU_SPAI_ADAPTIVE_OVERHEAD.md`. No further optimization is
authorized by this checkpoint; the next proposed direction, only if explicitly
authorized, is reducing the remaining tiny score-result transfers.

## Experiment 2A memory-investigation completion (12 October 2026)

The focused shared FP32/FP64 CUDA-SPAI correction removed only redundant explicit completion calls after already-synchronous downloads. Focused FP32 and FP64 SPAI regressions passed. Persisted post-change FP32 and FP64 GPU-SPAI/GPU-pipeline campaigns each completed four frozen matrices with three warm-ups and three measured trials per configuration, strictly serially; all 16 solver and 16 saved-snapshot Decimal80 checks accepted. The final evidence and limitations are in `EXPERIMENT2A_GPU_SPAI_MEMORY_OPTIMIZATION.md`; raw artifacts are under `results/experiment2a_gpu_spai_memory_fp32_20261012` and `results/experiment2a_gpu_spai_memory_fp64_20261012`. The historical FP32 stencil_8192 slowdown did not reproduce before the source change, so no speedup is attributed causally to it. No further GPU-SPAI optimization, BSPAI, mixed precision, or timing run is authorized by this milestone.

**Handoff date:** 11 October 2026  
**Authoritative status:** Stage 4 sparse-storage GPU SPAI is complete and independently validated. Stop here; do not begin Stage 5 BSPAI/mixed precision without explicit user authorization. Current Git branch: `stage4-scalable-spai`; preserved baseline tag: `gate3-working-baseline`.

## Start here

1. Read [AGENTS.md](AGENTS.md), this handoff, [PAPER_INDEX.md](PAPER_INDEX.md), and the specifications in `docs/` before changing numerical code.
2. Read [CODEBASE_GUIDE.md](CODEBASE_GUIDE.md), then inspect the current source and validation records, especially [CUDA_STAGE3_GPU_SPAI.md](docs/CUDA_STAGE3_GPU_SPAI.md) and [PHASE2B_VALIDATION_RECORD.md](docs/PHASE2B_VALIDATION_RECORD.md).
3. Verify the four project-local specialist definitions in `.codex/agents/`. Their exact model identifiers must be supported by the new account before use; do not substitute silently.
4. Rebuild and rerun the documented tests on the target machine before extending the code. Preserve any discrepancy rather than changing tolerances or stopping criteria to make it disappear.

## Project purpose

This research project establishes a reproducible numerical baseline for SPAI–GMRES–IR, develops a CUDA implementation, and is intended to lead to an IEEE conference paper. The central research baseline is Carson–Khan’s SPAI/BSPAI–GMRES–IR work. Work completed here is uniform binary64 correctness work, **not** a reproduction of the published mixed-precision BSPAI results and not a performance study.

`PAPER_INDEX.md` is the literature entry point. Its priority items are the original SPAI–GMRES–IR paper and the BSPAI–GMRES–IR paper, followed by GPU/MPI SPAI and GPU GMRES/SpMV literature. It also lists the original SPAI–GMRES–IR and ADAP-SPAI–GMRES–IR GitHub repositories. Its access/review labels must be respected: do not treat a listed link as proof that a full text or repository has been independently verified.

## Mathematical contract

The binding executable contract is [PHASE2A_ALGORITHM_SPEC.md](docs/PHASE2A_ALGORITHM_SPEC.md), with independent requirements in [PHASE2A_VALIDATION_PLAN.md](docs/PHASE2A_VALIDATION_PLAN.md).

- Fixed SPAI scaling/orientation: `B = A^T D`, where `d[k] = 1 / max_j |A[k,j]|`; construct `N` and assemble `P = N^T D`.
- SPAI starts from identity patterns; uses adaptive sparse-pattern growth, restricted candidate scoring, documented ascending tie/order rules, and the stated epsilon/growth limits.
- Least-squares fits use QR, never normal equations. The frozen rank guard is an exactly-zero **computed** QR diagonal, not an arbitrary near-rank threshold.
- GMRES is double-precision, unrestarted, left preconditioned, one-pass modified Gram–Schmidt with Givens rotations. Apply `P*(A*v)` without constructing `P*A`; recompute the true preconditioned residual before accepting convergence.
- Iterative refinement starts `x0=P*b`, uses a zero initial correction, evaluates `r=b-A*x`, and uses the specified normwise backward-error criterion (`10*2^-53`) with the documented outer limit.

Do not alter this policy, precision semantics, tolerance, scaling orientation, rank handling, or benchmark methodology without a written plan and independent validation.

## Development history and current architecture

### Phase 1 — investigation

[PHASE1_REPORT.md](docs/PHASE1_REPORT.md) records the literature/repository investigation, verified findings, gaps, and recommendations. The project deliberately distinguishes verified source-backed claims from proposals.

### Phase 2A — CPU uniform-double baseline

- Milestone 1: CSR/reference core — [CPU_MILESTONE1.md](docs/CPU_MILESTONE1.md)
- Milestone 2: CPU SPAI construction — [CPU_MILESTONE2.md](docs/CPU_MILESTONE2.md)
- Milestone 3: CPU GMRES — [CPU_MILESTONE3.md](docs/CPU_MILESTONE3.md)
- Milestone 4: end-to-end CPU SPAI–GMRES–IR — [CPU_MILESTONE4.md](docs/CPU_MILESTONE4.md)

CPU sources are `src/cpu.cpp`, `src/spai.cpp`, `src/gmres.cpp`, and `src/ir.cpp`, with public interfaces in `include/bspai/`. The CPU regression baseline is 946 checks: 37 CSR/core, 190 SPAI, 280 GMRES, and 439 IR; CPU CTest is 4/4.

### Phase 2B — CUDA uniform-double baseline

- CUDA Milestone 5A: cuSPARSE binary64 CSR SpMV — [CUDA_MILESTONE5A.md](docs/CUDA_MILESTONE5A.md)
- Gate 1: GPU-resident left-preconditioned GMRES — [CUDA_STAGE1_GMRES.md](docs/CUDA_STAGE1_GMRES.md)
- Gate 2: CPU SPAI / GPU GMRES hybrid IR — [CUDA_STAGE2_HYBRID_IR.md](docs/CUDA_STAGE2_HYBRID_IR.md)
- Gate 3: GPU SPAI construction and end-to-end solver — [CUDA_STAGE3_GPU_SPAI.md](docs/CUDA_STAGE3_GPU_SPAI.md)
- Stage 4: sparse B/compact GPU SPAI workspace and output — [CUDA_STAGE4_SCALABLE_SPAI.md](docs/CUDA_STAGE4_SCALABLE_SPAI.md)

CUDA source components are:

- `src/cuda_spmv.cu`, `include/bspai/cuda_spmv.hpp`: cuSPARSE binary64 CSR SpMV.
- `src/cuda_gmres.cu`, `include/bspai/cuda_gmres.hpp`: GPU-resident vector GMRES. It uses a project safe-scaled device norm because the tested cuBLAS 13.7.0 norm path mishandled local subnormal fixtures.
- `src/cuda_ir.cpp`, `include/bspai/cuda_ir.hpp`: CPU-staged outer IR with persistent GPU GMRES context, plus GPU-SPAI integration.
- `src/cuda_spai.cu`, `include/bspai/cuda_spai.hpp`: GPU numerical SPAI construction using independent bounded stream slots, cuSOLVER QR, GPU residual/scoring and GPU `P` assembly.
- `src/cuda_hybrid_main.cpp`: shared Matrix Market CLI. `cuda_hybrid_ir` uses CPU SPAI; `cuda_gpu_spai_ir` enables GPU SPAI.

`cuda/CMakeLists.txt` defines the separate x64 CUDA build. The CPU root `CMakeLists.txt` remains the independent reference build.

### Historical Gate 3 result

The final independent Gate 3 evidence is in [PHASE2B_VALIDATION_RECORD.md](docs/PHASE2B_VALIDATION_RECORD.md): 1,534 GPU-SPAI C++ checks, 436 independent 80-digit SPAI checks over 60 fits, 43 independent 80-digit IR checks, and 15 CLI checks passed. CUDA memcheck reported zero errors/leaks and initcheck zero errors. Previously validated suites also passed: CPU 946 checks, SpMV 323, GPU GMRES 871, and hybrid IR 665; CUDA CTest 4/4 and CPU CTest 4/4.

These are deterministic, small-matrix, uniform-double correctness results. They are not performance numbers, scalable-GPU claims, general high-dimensional robustness proof, or a published mixed-precision reproduction.

### Current Stage 4 result

The authoritative independent record passes 3,363,954 new sparse C++ checks (mostly exact outside-shadow zero assertions), 395 new80-digit SPAI checks over48fits and208 new80-digit IR checks over3states. Full new-suite memcheck0errors/0leaks and initcheck0errors. All prior suites pass; CPU CTest4/4, CUDA CTest5/5. Independent cudaMalloc/cudaFree pointer-ledger measurements exactly match source allocation telemetry, including zero outstanding allocations on tested normal/failure returns; vendor internal allocations are excluded.

For the adaptive deterministic tridiagonal family n16/64/256/1024, source-owned peak bytes are173808/181680/213168/339120, max reduced shape5x3 and queried QRworkspace20992bytes. This establishes sparse storage on tested local-pattern families, not timing, general asymptotic performance or arbitrary-fill bounds. See the Stage4 report for commands/hashes, validation-only frozen Gate3 library isolation, host staging and all limitations.

## Known limitations and unresolved discrepancies

1. **Stage 4 is implemented and validated on bounded sparse families through n1024.** B uses sparse CSC; QR buffers use actual reduced shapes; N/P are compactly packed. Actual patterns can still grow dense. Retained host histories and unrestarted GMRES Krylov/history buffers can dominate memory; this is not a universal linear-memory solver claim.
2. GPU SPAI remains hybrid host controlled: sorted patterns, candidate metadata, mean/filter/tie decisions, and adaptive scheduling remain on CPU. Stream telemetry proves independent work was submitted before collection, not actual hardware overlap or speedup.
3. The outer iterative-refinement loop is CPU staged. The final GPU P is downloaded/canonicalized and uploaded into the persistent GMRES context once; no direct device-to-device ownership transfer is claimed.
4. On literal singular `[[1,2],[1,2]]`, CPU reports `rank_deficient` while GPU reports `empty_candidates` because GPU Householder QR produces a tiny finite pivot. Both fail; no partial P is supplied to GMRES. Do not add a threshold, structural fallback, or CPU fallback to conceal this documented difference.
5. The tested cuBLAS 13.7.0 `Dnrm2` path gave incorrect local subnormal-norm results. The intentionally serial safe-scaled device norm is a correctness baseline, not a performance optimization.
6. BSPAI bucketing, mixed precision, benchmark methodology, speedups, and publication-quality experiments remain unimplemented.
7. `PAPER_INDEX.md` has links and citations but the project `papers/` directory has no locally available PDFs at this handoff. Full texts must be lawfully reacquired and review status updated before relying on new literature claims.
8. Git was subsequently initialized with authorization: current branch `stage4-scalable-spai`, baseline commit `581e75e`, tag `gate3-working-baseline`; no remote is configured. Stage4 source/report changes are currently uncommitted at this handoff update. Preserve the tag; do not reset or overwrite user changes.

## Environment and dependencies

Latest validated CUDA environment (machine specific):

- NVIDIA RTX 4060 Laptop GPU, compute capability 8.9, 8,188 MiB; driver 616.92.
- CUDA Toolkit/nvcc 13.4.59; runtime/driver API 13.4.
- cuSPARSE 12.8.6, cuBLAS 13.7.0, cuSOLVER 12.3.2.
- 64-bit MSVC 19.44.35228, CMake 3.31.6-msvc6, Ninja 1.12.1, Python 3.12.
- CUDA architecture `89`; Windows x64. The CUDA build requires CMake, Ninja, Visual Studio Build Tools, NVIDIA driver/runtime, cuBLAS, cuSPARSE, and cuSOLVER.

The supplied script contains absolute paths for this particular Windows installation. On a new machine, edit/copy it only after verifying installed tool locations, CUDA architecture, and compiler compatibility. Set `CUBLAS_EMULATE_DOUBLE_PRECISION=0`; the implementation also sets/queries documented cuBLAS and cuSOLVER modes. The old environment encountered sandbox DLL-relocation failures; verified CUDA execution occurred outside that sandbox. A new account/session must independently establish its own execution permissions.

## Build, execution, and test commands

From the project root, the existing CUDA script configures `cuda/` into `build/cuda-ninja`, builds, and runs CUDA CTest:

```powershell
cmd /c scripts\build_cuda_msvc.cmd
$env:PATH='C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v13.4\bin\x64;'+$env:PATH
$env:CUBLAS_EMULATE_DOUBLE_PRECISION='0'
& 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\ctest.exe' --test-dir build\cuda-ninja --output-on-failure
```

GPU SPAI CLI smoke test (explicitly uses a small validation fixture and is not a benchmark):

```powershell
build\cuda-ninja\cuda_gpu_spai_ir.exe tests\fixtures\tiny_nonsymmetric.mtx 0.5
```

The default epsilon `0.3` is expected to transparently fail construction for that tiny fixture because `alpha=1`; use the explicit `0.5` smoke configuration only as documented.

For independent CUDA numerical checks, use the exact commands in the Stage4 report and updated validation record, including the new `cuda_spai_sparse_tests` allocator audit plus `tests/check_cuda_spai_decimal.py`, `tests/check_cuda_spai_cli.py`, Compute Sanitizer memcheck/initcheck, and `build/validation-cuda`. These records include pinned artifact hashes and full command lines.

For the CPU baseline, configure root `CMakeLists.txt` with a compiler supporting C++11 and no fast-math, then run CTest and the four executables: `cpu_core_tests`, `spai_tests`, `gmres_tests`, `ir_tests`. Existing historical CPU validation used `build/ninja`; build directories are machine-generated and should be regenerated on the target system.

## Project-local specialist agents

The following supported Codex definitions are present under `.codex/agents/`:

| Role | File | Exact configured model | Reasoning |
|---|---|---|---|
| Research | `bspai_gmres_ir_researcher.toml` | `gpt-6.1-sol` | medium |
| Implementation | `bspai_gmres_ir_implementer.toml` | `gpt-5.6-terra` | medium |
| Validation | `bspai_gmres_ir_validator.toml` | `gpt-5.6-terra` | medium |
| Manuscript | `bspai_gmres_ir_manuscript.toml` | `gpt-6-luna` | medium |

These definitions contain the full responsibilities and should be invoked by a new main session as appropriate. Model availability and any account-level model entitlement are account specific; if a target account cannot select one of these identifiers, report that fact and ask the user how to proceed rather than silently substituting another model.

## Manuscript and research materials

The unmodified IEEE template is in `manuscript/IEEE_Conference_Template/` and includes `conference_101719.tex`, `conference_101719.pdf`, `IEEEtran.cls`, and `IEEEtran_HOWTO.pdf`. There is no `references.bib` and no project-authored manuscript draft at handoff. The manuscript agent must preserve the template, create citations only from verified publications, and never invent results.

Research index and reports are local. Paper full texts are externally referenced in `PAPER_INDEX.md`; none are present under `papers/` at handoff. Repository URLs are external and need their own network access/authorization.

## Immediate next milestone — do not start without authorization

**Stage 5: BSPAI bucketing and mixed precision is future work, not authorized or implemented.** First obtain explicit approval and a source-backed precision/bucketing/validation specification; do not infer that Stage4 storage validation authorizes changed precision, preconditioner application, convergence rules or benchmarking.

Stage4 is complete: sparse B CSC, compact actual reduced QR buffers, packed GPU P assembly, unchanged frozen SPAI numerics and independent allocation/numerical/sanitizer evidence. Preserve the CPU reference and the validation-only Gate3 dense reference. Review [CUDA_STAGE4_SCALABLE_SPAI.md](docs/CUDA_STAGE4_SCALABLE_SPAI.md) and the authoritative validation record before any extension.

After explicit future approval: Stage5 BSPAI bucketing/mixed precision; Stage6 performance optimization and benchmarking; Stage7 IEEE manuscript finalization. None has started.

## Transfer audit

Transfer the entire project directory, including hidden `.codex/agents/`, source, headers, `cuda/`, `scripts/`, tests, fixtures, docs, `manuscript/`, `PAPER_INDEX.md`, and this handoff. Build outputs in `build/` are machine-specific and nonessential; regenerate them. Do not transfer credentials, tokens, user profile data, or the prior conversation.

Git is now initialized on `stage4-scalable-spai` with the preserved Gate3 tag and no configured remote; include .git when transferring recoverable history, and preserve current uncommitted Stage4 files. Verify repository/worktree state after copying. Check the new account can access the configured models, a suitable CUDA-capable host, toolkit/compiler paths, official source links, and any Codex-specific agent support. Those account/machine services do not transfer with files.

### Final handoff audit — 11 October 2026

- The project-local `.codex/config.toml` preserves the coordinator/default setting `gpt-5.6-terra`, medium reasoning; the four full role definitions are present in `.codex/agents/` with the exact requested model identifiers and responsibilities.
- All source/header files, both CMake configurations, CUDA script, CPU/CUDA test suites, decimal/CLI validation scripts, tiny Matrix Market fixture, reports/specifications, Gate 3 validation evidence, and the IEEE template assets are present in the project folder.
- The current machine reran `cmd /d /c scripts\build_cuda_msvc.cmd`: configure/build succeeded and CUDA CTest passed 4/4. CPU CTest on `build/ninja` also passed 4/4. These commands refresh generated test logs only; no numerical source or tolerance was changed during handoff.
- `papers/` is empty. No locally cached reference repositories, MATLAB reference implementation, source archive, dependency lockfile, README/LICENSE, unified all-check runner, or project manuscript/bibliography is available. The IEEE directory is the generic template only, with its placeholder/example bibliography.
- Build directories, binaries, CMake caches, Debug runtimes, and saved test logs are machine-generated. A stale historical `LastTestsFailed.log` may exist under `build/`; the fresh CTest runs above are the current result. Regenerate build artifacts after transfer rather than using them as portable evidence.
- No active build/test processes were found during the audit. Live agent conversations, Codex account entitlements, custom-agent loading behavior, access to external papers/repositories, MATLAB/Advanpix licenses, CUDA driver/toolkit/MSVC/Python installations, and the prior conversation do not transfer with this folder.

## Append-only Stage 4 completion update — 11 October 2026

Stage 4 is implemented and independently validated on `stage4-scalable-spai`. Production GPU SPAI now uses sparse CSC storage for `B=A^T D`, compact reduced-problem QR workspaces, compact fitted-column packing, and GPU assembly of `P=N^T D`. The prior dense Gate 3 constructor remains under `tests/reference/` as a validation-only comparison target and is never a production fallback.

Final evidence includes 3,363,954 new sparse C++ checks, 395 independent 80-digit SPAI checks over 48 fits, 208 independent 80-digit end-to-end IR checks, CPU CTest 4/4, CUDA CTest 5/5, zero memcheck errors/leaks, zero initcheck errors, and exact agreement between allocator instrumentation and reported telemetry. Deterministic sparse families were tested through `n=1024`; measured source-owned adaptive peak allocation ranged from 173,808 bytes at `n=16` to 339,120 bytes at `n=1024`.

These are bounded sparse-family correctness results. Vendor-internal allocations, dense pattern growth, host histories, compact QR worst cases, unrestarted GMRES histories, and CPU-staged packaging remain possible memory costs. No universal linear-memory, high-dimensional robustness, overlap, speedup, or performance claim is made. Stage 5 BSPAI bucketing/mixed precision remains unauthorized and unimplemented.

## Append-only Stage 4.5A validation update — 11 October 2026

Stage 4.5A completed untimed acquisition, independent numerical validation and resource-feasibility screening. See `STAGE45A_NUMERICAL_VALIDATION.md`, `docs/STAGE4_5A_INDEPENDENT_VALIDATION.md`, the provenance manifest under `data/stage45a_provenance_20261011/`, and raw retained results under `results/stage45a_validation/`. Ten CC-BY 4.0 SuiteSparse matrices were acquired unchanged with raw/archive hashes; six pilots, `sherman4` (n=1,104), and the first conditional larger matrix `orsreg_1` (n=2,205) were screened. The conditional n=3,312/n=4,960 matrices were acquired but not run.

There were 32 retained processes: 28 solver successes and four intentionally constrained solver nonconvergences. The final Decimal80 assessment performed 788,034 checks with zero discrepancies. CPU CTest 4/4 and CUDA CTest 5/5 passed. `gre_115` has a documented CPU/GPU native-P pattern discrepancy induced by computed-score ordering near exact ties; it was not hidden by a tolerance or rank-policy change. `steam3` demonstrates that a successful backward error need not imply small forward error. No timing, warm-up, repeated trials, profiling, speedup claim, optimization, BSPAI, or mixed precision occurred. Stage 4.5B baseline benchmarking requires separate explicit approval.

## Append-only Stage 4.5A extension completion — 11 October 2026

The approved extension is complete; see [STAGE45A_EXTENSION.md](STAGE45A_EXTENSION.md). It adds nine deterministic controlled matrices at `n=64,256,1024` and the retained SuiteSparse `sherman5` (`n=3312`) and `add32` (`n=4960`) runs. `results/stage45a_extension/ASSESSMENT_EXTENSION_WITH_APPLICATION.json` reconciles 22 raw CPU/GPU records: all are `solver_success`, all independently pass, with 1,068,784 Decimal80 checks and zero discrepancies. The 18 controlled records carry manufactured diagnostics; application records use `equal_unit2` and do not claim forward-truth validation.

Native construction differs across some CPU/GPU runs: `sherman5` differs at one final pattern column with equal `P` nnz; `add32` differs in 92 columns with `P` nnz 24554/24595. Application QR checks are sampled, not exhaustive. The original `gre_115` and `steam3` qualifications remain unchanged. Explicit CTest reruns now pass CPU 4/4 and CUDA 5/5; CPU required host execution after a sandbox `BAD_COMMAND`. No new algorithm or benchmark work occurred. Stage 4.5B remains unstarted and requires approval.

## Append-only Stage 4.5B preparation checkpoint — 11 October 2026

Stage 4.5A is preserved by commit `8eac10eec719bf24d55e219884d7a35bcd25aaaa` and annotated tag `stage45a-validated-baseline`; the original Gate 3 tag remains intact. Fresh Release build preparation is recorded in [STAGE45B_PREPARATION.md](STAGE45B_PREPARATION.md). CUDA Release built and passed CTest 5/5. CPU MSVC Release built, but its CTest admission is blocked: three numerical suites require a wider built-in reference mantissa unavailable in that toolchain. No benchmark or profile sample was collected. Do not begin Stage 4.5B timing until a CPU Release toolchain/oracle passes the defined independent numerical gate.

## Append-only Stage 4.5B Release-admission update

See `STAGE45B_RELEASE_ADMISSION.md`. Original MSVC CPU Release CTest remains 1/4 because the three intentional wider-oracle assertions are unchanged. The validation-only schema-2 snapshot/Decimal80 path passes 16 snapshots and 500 checks, but CPU Release is not yet benchmark-admitted because some historical wider-oracle branches remain unsnapshotted. CUDA Release CTest passes 5/5 and its applicable Decimal checks pass. No timing, profile, production-source, tolerance, precision, BSPAI, or mixed-precision change occurred.

## Append-only Stage 4.5B exploratory benchmark update — 11 October 2026

The first exploratory CPU/GPU timing campaign is complete; see [STAGE45B_EXPLORATORY_BENCHMARK.md](STAGE45B_EXPLORATORY_BENCHMARK.md). It retains 78 independently assessed timing-mode records for 13 matrices, raw JSONL, sidecar hashes, full descriptive statistics, and four SVG figures under `results/stage45b_selected_aggregation_20261011/`. The selected timing data shows the GPU slower at every reported median comparison; this result is retained rather than hidden.

The original raw directory `results/stage45b_exploratory_20261011/` contains an early overlapping-resume incident. Its complete six-mode sets for `cage5`, `gre_115`, `pores_3`, `steam1`, `saylr1`, `sherman4`, `orsreg_1`, and `sherman5` remain usable. All original `add32` pipeline and original synthetic timing artifacts are retained but excluded. A single-run locked continuation at `results/stage45b_add32_synthetic_continuation_20261011/` supplies the clean complete `add32` and four synthetic sets. No timing artifact was overwritten or selectively removed.

Every selected fixed-P GMRES sample uses an identical stored P per CPU/GPU pair and independently passes the exact Decimal80 preconditioned-residual tolerance. Every selected native pipeline sample independently passes the frozen Decimal80 backward-error criterion. The CPU MSVC Release CTest limitation remains 1/4, so this report is exploratory and not publication-ready. No profiling, optimization, BSPAI, mixed precision, tolerance, precision-policy, or production algorithm change occurred.

## Append-only Experiment 1 FP64 scalability update — 11 October 2026

See `STAGE45B_FP64_SCALABILITY.md`. Immutable deterministic 1024--16384 synthetic inputs, a sequential locked resource-screened harness, raw JSONL, Decimal80 sidecars, binary64 audits, preflight files, and five SVG plots are present. At the recorded machine state (~1.5--2.2 GB host free), the 30% safety margin admitted only n=1024; both 2048--8192 families and conditional 16384 were retained as `resource_abort/host_memory_margin` before execution. The two n=1024 families pass applicable independent checks but GPU is slower in all measured medians. No crossover, real-matrix execution, profiling, or optimization is claimed.

## Append-only Experiment 1 n=12,000 attempt — 11 October 2026

See [STAGE45B_FP64_12000_RESULTS.md](STAGE45B_FP64_12000_RESULTS.md). New immutable deterministic `stencil_12000` (100x120, 59,560 nnz) and `irregular_12000` (58,095 nnz) inputs are stored under `data/stage45b_fp64_12000_v1/`, with hashes/provenance and unchanged FP64 settings (`epsilon=.3`, `beta=8`, `alpha=1500`, `tau=1e-8`, inner cap 12000, outer cap 20, BE `10*2^-53`).

The execution is incomplete. Both retained stencil attempts prepared a successful P and retain successful 3+3 SPAI/fixed-P GMRES records, but their timing windows overlap; all SPAI timing is excluded from statistics. No native pipeline artifacts or irregular-12000 run exists. Fixed-P GMRES numerically converged with identical P hashes and Decimal80 residuals below `1e-8`, but the isolated post-overlap pair is traceability evidence only, not a completed benchmark. No record establishes OOM, watchdog timeout, CUDA allocation failure, or solver nonconvergence; classify the stopping event as `incomplete / termination cause unclassified`. No n=12000 GPU crossover or speedup is claimed.

### Superseding clean n=12,000 execution — 11 October 2026

The prior invalidation was an orchestration defect: output-directory-local locks permitted two runners to overlap. `scripts/benchmark_experiment_lock.py` now provides an atomic root-level shared lock for both benchmark launchers, with PID/liveness, active child, lifecycle, watchdog, and last-successful-configuration evidence. Pre-existing locks are not automatically removed. The clean, serial, independently accepted campaign is `results/stage45b_fp64_12000_clean_20261011/`; Decimal80 sidecars are additive and plots/aggregation are under `results/stage45b_fp64_12000_clean_aggregation_20261011/`. See the superseding section in [STAGE45B_FP64_12000_RESULTS.md](STAGE45B_FP64_12000_RESULTS.md).

All 12 modes (two matrices times six) completed with three warm-ups, three measurements, exit code zero, no watchdog, matching fixed-P hashes, and appropriate Decimal80 acceptance. CPU/GPU median ratios for stencil are SPAI 1.607x, fixed-P GMRES 0.845x, and native pipeline 1.190x; for irregular they are 1.268x, 0.732x, and 0.962x. Thus GPU SPAI is faster on both 12k families and the native pipeline is faster only on the stencil case. These are exploratory host-wall-clock observations; the MSVC CPU Release CTest 1/4 limitation and native-pipeline unequal-work qualification remain.

## Append-only Experiment 2A FP32 implementation status — 12 October 2026

Experiment 2A is a separate, unadmitted uniform-binary32 extension. Its contract is [EXPERIMENT2A_FP32_SPEC.md](docs/EXPERIMENT2A_FP32_SPEC.md); it does not amend any validated binary64 source, tolerance, or timing result. The isolated CPU path (`include/bspai/fp32.hpp`, `src/fp32_cpu.cpp`) implements float Householder SPAI fits, `B=A^T D`/`P=N^T D`, restricted scoring, GMRES, and outer refinement. Its bounded `fp32_cpu_tests` smoke executable passed. That is not an independent Decimal80 admission.

The isolated CUDA path (`include/bspai/fp32_cuda_gmres.hpp`, `src/fp32_cuda_spmv.cu`, `src/fp32_cuda_gmres.cu`) uses `CUDA_R_32F`/single-precision cuBLAS and has a CPU-staged outer wrapper with explicit P. A fresh MSVC 19.44/CUDA 13.4 build at `build/fp32-cuda-msvc-clean` compiled `fp32_cuda_gmres_tests`; its only sequential execution failed at `FP32 CUDA GMRES convergence`. This is an active correctness blocker, not an OOM, timeout, or performance result. GPU FP32 SPAI, Decimal80 FP32 admission, profiling, and all FP32 benchmarks remain unimplemented.

Next action: diagnose the CUDA GMRES failure, then independently validate the FP32 path before starting any FP32 timing. The shared root benchmark lock remains mandatory; no concurrent benchmark runners were launched for this work.

## Append-only Experiment 2A FP32 CUDA-GMRES correction — 12 October 2026

The CUDA FP32 GMRES blocker was a candidate-assembly defect, not a justified change in FP32 convergence policy. In `src/fp32_cuda_gmres.cu`, the prior loop stored the latest candidate in `dx` and incorrectly used that mutable vector as the base of the next projected candidate. Production code now uploads and retains an immutable device `x0`; each candidate is formed exactly as `x0 + V_k y_k`. `dx` remains the returned latest candidate only. No FP64 source, tolerance, preconditioning, MGS, Givens, breakdown, or recomputed-residual policy changed.

The focused CUDA test was rebuilt in `build/fp32-cuda-msvc-clean` and passes. It retains the originally failing strict `2e-5`, cap-3 identity-P smoke fixture and adds a nonzero-`x0`, multi-iteration regression at the frozen Experiment 2A `1e-4` tolerance. The latter compares CPU/GPU success and iteration count, requires a GPU recomputed residual within tolerance, and checks the final solution against CPU. The test is source-derived to reject the former accumulation: under the old implementation, the second candidate used the first candidate rather than `x0` and double-counted prior Krylov contributions; the old production source was not restored to execute a destructive A/B run.

Independent validation rebuilt and reran the focused CUDA test successfully. On the fixed 3x3 identity-P nonzero-`x0` probe, CPU and GPU both returned `success` in 3 iterations. CPU returned float bits `[3e7fffff,bf000000,3f400000]`; GPU returned `[3e7ffffd,bf000000,3f3fffff]`, with reported original residual `3.37174782e-7` and reported relative preconditioned residual `6.90054520e-8`. Exact-rational reconstruction from the returned GPU binary32 values gives `P(b-Ax)=[3/2^24,-10/2^26,3/2^24]`, norm `sqrt(97)/2^25` (about `2.935e-7`), relative residual about `6.007e-8`, and relative forward error about `7.965e-8`; all are below the unchanged `1e-4` GMRES target. The small reported/reconstructed difference is retained as FP32 operation-order/norm variation, not suppressed.

`fp32_cpu_tests`, `fp32_cuda_spmv_tests`, the frozen CPU FP64 `gmres_tests` (280 checks), and the existing CUDA FP64 `cuda_gmres_tests` executable passed. The FP64 CUDA build tree could not be freshly rebuilt because `build/cuda-ninja/CMakeFiles/rules.ninja` is missing, so that FP64 CUDA result is execution-only, not a fresh-build regression. `tests/validation_fp32_cuda_probe.cpp` is a validation-only, non-CMake-linked bit-pattern probe retained for this evidence.

This resolves the focused FP32 CUDA GMRES candidate-base blocker only. Experiment 2A remains unadmitted: a complete Decimal80 FP32 assessment, CUDA FP32 IR outer-history assessment, pedantic-library/subnormal-norm investigation, GPU FP32 SPAI, and all timing work remain outside this result.

### FP32 CUDA GMRES diagnostic-history follow-up

The existing result histories are now populated without changing acceptance or arithmetic: absolute Hessenberg estimates after each Givens update, plus original and recomputed preconditioned residuals after each formed candidate. On the same nonzero-`x0` fixture, the final absolute estimate is `3.16252368e-7`, or relative estimate about `6.47235e-8` after division by `||Pb||_2=sqrt(23.875)`; the recomputed relative residual is `6.90054520e-8`. These remain deliberately distinct and both pass `1e-4`. Independent validation found all three histories finite and length 3, matching the iteration count.

## Append-only Experiment 2A FP32 CUDA-SPAI focused checkpoint — 12 October 2026

The separate FP32 CUDA-SPAI constructor is now present at `include/bspai/fp32_cuda_spai.hpp` and `src/fp32_cuda_spai.cu`, with CMake target `bspai_fp32_cuda_spai` and focused target `fp32_cuda_spai_tests`. It specializes the compact CUDA constructor to float with `cusolverDnSgeqrf`, `cusolverDnSormqr`, `cublasStrsv`, FP32 `32*2^-24` score guarding, compact output, and stream telemetry. The retained FP64 source receives only default-preserving macro hooks for score unit roundoff and accumulator seed; its selected defaults remain binary64 values.

Under MSVC BuildTools/CUDA 13.4, a clean focused rebuild recompiled the FP32 CUDA SpMV, GMRES, and SPAI units, linked `fp32_cuda_spai_tests`, and passed. On its manufactured 3x3 fixed-P gate, CPU/GPU GMRES both converged in 3 iterations; GPU reported residual was `8.05948659e-08`, independent long-double reconstruction was `1.08344968e-07`, and GPU forward relative error was `1.10366356e-07`. The adjacent CUDA GMRES regression rebuilt and passed; the CPU FP32 smoke passed. CUDA outer refinement now appends diagnostics to `outer_history`, matching CPU API behavior.

This is not admission: the public FP32 column mapping exposes candidate-score data only for the latest adaptive fit, GPU-SPAI-to-public-FP32-IR integration and its outer-history test are absent, and Decimal80 independent validation remains pending. No benchmarks, mixed precision, BSPAI, or FP64 numerical policy change is authorized.

## Append-only Experiment 2A FP32 end-to-end integration and 4096 execution — 12 October 2026

The FP32 API now includes `fp32_cuda_spai_gmres_ir`: it constructs P with `fp32_cuda_construct_spai`, returns `construction_failure` without invoking GMRES if that construction fails, otherwise passes that exact GPU-built host-canonicalized P to the existing GPU-inner/CPU-staged FP32 refinement. The focused small integration test requires a real accepted correction under frozen settings; CPU and GPU each took one outer correction. GPU outer history records BE `0.0185238384` initially and `1.98682145e-07` after correction, below the frozen `10*2^-24` target.

## Append-only Experiment 2A FP32 12k numerical correctness completion — 12 October 2026

Exactly one persisted CPU-then-GPU FP32 execution was completed for each immutable 12k input and assessed by a snapshot-only Decimal80 checker. Stencil: CPU/GPU success, P nnz 59205, fits/growths 23881/11881, two outer corrections, CPU inner [7,9], GPU [7,8], Decimal80 BE `6.0444139101547974e-08`/`6.0444141672525308e-08`. Irregular: CPU/GPU success, P nnz 17379, fits/growths 13386/1386, two outer corrections, inner [8,9], Decimal80 BE `6.9323122592195195e-08`/`6.882274679262352e-08`. All results are below frozen `10*2^-24`; no performance claim follows.

The validation-only `validation_fp32_4096` executable read the immutable `data/stage45b_fp64_scalability_v1/stencil_4096.mtx` directly to FP32, formed its periodic7 RHS from the FP32-rounded matrix, and used epsilon `.3`, beta 8, alpha 512, GMRES cap 4096/tolerance `1e-4`, and outer cap 20. It completed exactly one sequential CPU then GPU full-pipeline execution with exit code zero. Its ~100 kB bit-level JSONL record was truncated by the tool transport and was not persisted. Retained tail evidence is P-pattern symmetric difference 0 and GPU free VRAM `7451181056 -> 7449083904` bytes (total `8585216000`). The Decimal80 checker deliberately was not run because its current interface reruns the executable; doing so would violate the authorized one-run-per-solver constraint. Therefore the required Decimal80 final-solution acceptance, full 4k status/nnz/iteration/BE report, and stop condition are **blocked by missing persisted output**, not established by the exit code. A corrective rerun that persists the JSONL snapshot needs explicit user authorization.

## Append-only Experiment 2A complete FP32/FP64 timing record — 12 October 2026

The authorized serial four-matrix timing campaign is complete. It retained 48 configurations (four matrices, FP32/FP64, and CPU/GPU SPAI, fixed-P GMRES, and native pipeline) with three warm-ups and three measured trials each: 288 successful/converged records. All solver children and all 48 saved Decimal80 sidecars returned zero; every sidecar assessed the three measured trials, reported zero failures, and accepted its configuration. Fixed-P preparations succeeded and every CPU/GPU pair used the same serialized P hash. Lifecycle records show 48 non-overlapping intervals; the shared root lock was released.

The full timing, construction, numerical-acceptance, input-hash, and limitation record is [EXPERIMENT2A_FP32_VS_FP64_TIMING.md](EXPERIMENT2A_FP32_VS_FP64_TIMING.md). Raw records are retained in `results/experiment2a_fp32_vs_fp64_stencil8192_20261012/` and `results/experiment2a_fp32_vs_fp64_remaining_20261012/`. These remain exploratory host-wall-clock observations; native pipelines are not assumed equal work, and the existing FP64 MSVC CPU Release CTest 1/4 caveat remains.

## Append-only Experiment 2A Stage A completion — 12 October 2026

The bounded Stage A shared CUDA SPAI transfer consolidation is complete. It replaces the three candidate score/status/clamp D2H arrays with one exact-layout `ScoreWire` record, without changing arithmetic, adaptive decisions, precision policy, QR, or required host dependency boundaries. Valid relinked Nsight stencil-8192 traces show `cudaMemcpyAsync` calls reduced from 276,008 to 243,748 per two constructions (`-11.688%`) in both FP32 and FP64, with unchanged kernel-launch and stream-synchronization counts. Focused FP32/FP64 regression, FP64 shared-constructor memcheck, and root-locked four-matrix campaigns passed. All 16 GPU-SPAI/GPU-pipeline configurations and all 48 saved-snapshot Decimal80 measured assessments accepted. Wall-clock changes were mixed; this is an accepted API-overhead reduction, not a uniform speedup claim. The durable record is [EXPERIMENT2A_GPU_SPAI_STAGE_A.md](EXPERIMENT2A_GPU_SPAI_STAGE_A.md). Do not begin a further optimization, BSPAI, or mixed precision without new authorization.
