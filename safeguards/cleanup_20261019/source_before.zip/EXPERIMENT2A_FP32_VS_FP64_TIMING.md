# Experiment 2A — FP32 versus FP64 timing, complete record

**Date:** 12 October 2026  
**Classification:** exploratory host-wall-clock timing, with saved numerical acceptance sidecars.

## Completion and integrity

The complete four-matrix campaign finished normally. It contains 48 timed configurations (four matrices, two precisions, and CPU/GPU SPAI, fixed-P GMRES, and native pipeline modes). Each configuration retained exactly three warm-ups and three measured trials: 288 records in total. No samples were restarted, deleted, or excluded.

All solver children returned zero, reported success/convergence, and had a positive elapsed time. All 48 saved Decimal80 sidecars returned zero, assessed all three measured records, reported zero failures, and accepted the configuration. The lifecycle log has 48 starts and 48 finishes with zero overlaps. The shared experiment lock is absent after normal completion.

The raw evidence is retained in `results/experiment2a_fp32_vs_fp64_stencil8192_20261012/` and `results/experiment2a_fp32_vs_fp64_remaining_20261012/`.

## Frozen inputs and construction outcomes

| Matrix | SHA-256 | P nnz | fits | growths |
|---|---|---:|---:|---:|
| stencil_8192 | `90d25d6332cc3729030c13e89deb74169b13aef8c1fe89b1ffa4af6709f09b1f` | 40,197 | 16,257 | 8,065 |
| irregular_8192 | `232c6639f922657753dacdf305fcff180b6090f72b47e4cd92eb29c9bbb497be` | 11,870 | 9,139 | 947 |
| stencil_12000 | `67bd44621dd175b1d498013f0fff38f652a5f442853c9586ae5af9d2c971f1c3` | 59,205 | 23,881 | 11,881 |
| irregular_12000 | `01355bc6d400890f023c9fa7ed6a99a46050dbb2b2a59036568075bfb0449f12` | 17,379 | 13,386 | 1,386 |

For a given matrix, the recorded construction counts agree across precision and CPU/GPU modes. Each of the eight untimed fixed-P preparations succeeded; the CPU/GPU fixed-P pair in each precision references the same serialized P SHA-256.

## Timing results

Values are medians in milliseconds of the three retained measured trials. The interval is one public API call, including its synchronization; JSON, validation, and aggregation are outside the interval.

| Matrix / precision | CPU SPAI | GPU SPAI | CPU fixed-P GMRES | GPU fixed-P GMRES | CPU native pipeline | GPU native pipeline |
|---|---:|---:|---:|---:|---:|---:|
| stencil_8192 FP32 | 3286.5540 | 4749.0386 | 204.9343 | 210.8804 | 3710.6146 | 5319.8848 |
| stencil_8192 FP64 | 5363.0660 | 2330.4080 | 355.3424 | 524.2216 | 3861.2715 | 4623.7047 |
| irregular_8192 FP32 | 692.2383 | 1205.3106 | 95.2614 | 106.1507 | 893.5767 | 1399.3208 |
| irregular_8192 FP64 | 836.8006 | 1196.1678 | 351.9354 | 530.1581 | 2768.5423 | 3443.3083 |
| stencil_12000 FP32 | 2708.9336 | 3443.3742 | 193.8655 | 210.5575 | 3175.3095 | 3881.6095 |
| stencil_12000 FP64 | 4344.0303 | 3366.7888 | 688.5431 | 939.4633 | 7759.4091 | 7265.0355 |
| irregular_12000 FP32 | 1502.1147 | 1720.6026 | 201.0510 | 215.3509 | 1911.6624 | 2204.2267 |
| irregular_12000 FP64 | 1917.6849 | 1781.5631 | 682.2568 | 940.7884 | 5004.9539 | 5396.7012 |

For the direct precision comparison, the following are FP64/FP32 median-time ratios; a value above one means the FP32 denominator was faster for that exact column.

| Matrix | CPU SPAI | GPU SPAI | CPU fixed-P GMRES | GPU fixed-P GMRES | CPU pipeline | GPU pipeline |
|---|---:|---:|---:|---:|---:|---:|
| stencil_8192 | 1.632 | 0.491 | 1.734 | 2.486 | 1.041 | 0.869 |
| irregular_8192 | 1.209 | 0.992 | 3.694 | 4.994 | 3.098 | 2.461 |
| stencil_12000 | 1.604 | 0.978 | 3.552 | 4.462 | 2.444 | 1.872 |
| irregular_12000 | 1.277 | 1.035 | 3.393 | 4.369 | 2.618 | 2.448 |

## Numerical outcomes

All recorded modes converged. Fixed-P GMRES iterations were unchanged within each CPU/GPU pair: FP32 used 6 on stencil and 8 on irregular inputs; FP64 used 14 on stencil and 16 on irregular inputs. Every native pipeline completed two outer corrections. FP32 native-pipeline total inner iterations were 15/17/16/17 for stencil_8192, irregular_8192, stencil_12000, and irregular_12000 respectively (the GPU stencil_12000 path recorded 15).

The stored native-pipeline normwise backward errors were below their frozen targets in every trial: FP32 values were approximately `7.16e-8` to `7.41e-8`, below `10*2^-24 = 5.9604644775390625e-7`; FP64 values were approximately `1.33e-16` to `1.38e-16`, below `10*2^-53`.

Decimal80 sidecars independently applied the frozen precision-specific criterion: fixed-P GMRES used the preconditioned relative residual target (`1e-4` FP32, `1e-8` FP64), while native pipelines used the original-system backward-error targets above. All 144 measured trials were accepted. The raw JSONL and sidecars retain the per-trial solutions, residuals, forward-error diagnostics, and construction telemetry.

## Interpretation limits

These results are machine-specific, exploratory wall-clock observations, not a general performance or scalability claim. Fixed-P CPU/GPU rows compare the same precision-specific serialized P; native pipelines construct their own P and therefore are not assumed to be equal-work comparisons. FP64 timing also retains the pre-existing MSVC CPU Release CTest `1/4` wider-oracle limitation. The serial lifecycle and manifests demonstrate exclusive execution, although the deleted root-lock file leaves no durable acquire/release journal.
