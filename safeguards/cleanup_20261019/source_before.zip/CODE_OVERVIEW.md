# BSPAI–GMRES–IR Code Overview

This overview describes the production CUDA **binary64** path. The experimental FP32 path is separate.

## 1. GPU GMRES operation split

Implementation: [`src/cuda_gmres.cu`](C:/Users/Anirudh/Desktop/pcapproj/src/cuda_gmres.cu:71).

| GMRES operation | Location | Details |
|---|---|---|
| \(A v\) | GPU | cuSPARSE CSR SpMV in `Matrix::apply()`. |
| Apply \(P\) | GPU | A second cuSPARSE CSR SpMV. The code always evaluates \(P(A v)\); it never forms \(P A\). |
| Initial residual \(b-Ax_0\) for inner GMRES | GPU | Device SpMV plus device vector subtraction and norm. |
| Preconditioned RHS \(P b\) | GPU | Device SpMV; its norm supplies the normalization denominator. |
| Arnoldi work vector | GPU | \(w=P(A v_k)\) remains device-resident. |
| MGS dot products | GPU reduction, host scalar control | `cublasDdot_64` computes each dot product on the GPU, then returns the scalar to the host. |
| MGS orthogonalization update | GPU | `cublasDaxpy_64` performs \(w \leftarrow w-h_{jk}v_j\). The host supplies \(h_{jk}\). |
| Norms | GPU reduction, host scalar observation | A project-specific `safe_scaled_norm` CUDA kernel computes the norm; the scalar is copied to the host. |
| Basis-vector normalization | GPU | `divide_vector` performs \(v_{k+1}=w/h_{k+1,k}\). |
| Basis storage | GPU | Krylov vectors remain device-resident during Arnoldi. |
| Givens rotations and projected residual \(g\) update | CPU | Hessenberg/Givens arrays and scalar arithmetic are host-controlled. |
| GMRES least-squares/back-substitution | CPU | `candidate_coefficients()` solves the small rotated triangular system on the host. No cuSOLVER least-squares call is used here. |
| Candidate vector update \(x_0+V_k y_k\) | GPU | Device copy followed by GPU AXPY operations using host-computed \(y_k\). |
| True candidate residual check | GPU | Computes \(A x\), \(b-Ax\), \(P(Ax)\), \(P b-P(Ax)\), and both norms on the device. |
| Convergence acceptance | CPU decision, GPU residual data | The host uses the Hessenberg estimate to trigger a check, then accepts only after the GPU-recomputed residual is returned. |
| Finite-value checks | GPU kernel, host flag observation | `finite_flag` scans device vectors; only the flag is copied back. |
| Final solution/history | Device until termination, then CPU | Solution, basis vectors, and candidate snapshots are downloaded after termination. |

GPU GMRES is therefore **GPU-vector-resident but host-controlled**. Vector arithmetic and sparse products run on the GPU; small projected-system bookkeeping, Givens logic, back-substitution, and branch decisions run on the CPU. This is also documented in [`docs/CUDA_STAGE1_GMRES.md`](C:/Users/Anirudh/Desktop/pcapproj/docs/CUDA_STAGE1_GMRES.md:5).

## 2. Iterative-refinement operation split

Implementation: [`src/cuda_ir.cpp`](C:/Users/Anirudh/Desktop/pcapproj/src/cuda_ir.cpp:20).

The outer refinement loop is deliberately CPU-staged.

| Refinement operation | Location |
|---|---|
| Initial guess \(x_0=P b\) | CPU, using host `CsrMatrix::multiply()` |
| Original residual \(r=b-Ax\) | CPU |
| Residual 2-norm/infinity norm | CPU |
| Normwise/componentwise backward error | CPU |
| Optional forward-error diagnostic | CPU |
| Outer stopping decision \(\eta \le 10\cdot2^{-53}\) | CPU |
| Correction RHS creation | CPU |
| Inner correction solve \(P A d=P r\) | GPU GMRES |
| Correction solution download | GPU → CPU |
| Outer update \(x\leftarrow x+d\) | CPU |
| Recomputed diagnostics after the update | CPU |
| Stagnation, inner-failure, and outer-cap decisions | CPU |

The relevant outer-loop statements are:

- `initial.x = p.multiply(rhs)` — CPU initial guess.
- `evaluate_ir_diagnostics(...)` — CPU residual/backward-error calculation.
- `context->solve(residual)` — GPU inner GMRES.
- `next.x[i] += inner.solution[i]` — CPU correction update.
- The next `evaluate_ir_diagnostics(...)` and stopping checks — CPU.

The project does **not** implement a fully GPU-resident iterative-refinement loop.

## 3. Host/device movement during one refinement step

### One-time context construction

The persistent `CudaGmresContext` uploads immutable \(A\) and \(P\) CSR data once and retains them across all corrections.

For nonempty matrices, this is logically:

- \(A\) row offsets, column indices, values: host → device.
- \(P\) row offsets, column indices, values: host → device.

The “two matrix uploads” counter means two matrix objects; the transfer telemetry counts the individual CSR arrays.

### Each inner correction

For every refinement step:

1. CPU computes the original residual \(r=b-Ax\).
2. CPU uploads \(r\) as the GPU GMRES RHS.
3. CPU uploads an explicitly zero initial correction vector.
4. Arnoldi runs without full-vector host/device transfers.
5. Dot products, norms, and finite flags produce scalar/status transfers to the host.
6. Host scalar coefficients are supplied to GPU AXPY, division, and SpMV operations.
7. After termination, the correction solution is downloaded.
8. The implementation also downloads completed basis vectors and candidate snapshots for diagnostics and validation.

The project records this in [`docs/CUDA_STAGE2_HYBRID_IR.md`](C:/Users/Anirudh/Desktop/pcapproj/docs/CUDA_STAGE2_HYBRID_IR.md:22): no Arnoldi vector transfers occur during the iteration; full-vector downloads happen only after inner termination.

## 4. Does GPU GMRES use the CUDA-SPAI preconditioner?

Yes, in the native GPU-SPAI pipeline.

The path is:

```text
cuda_construct_spai(A)
    ↓
GPU-built P is downloaded and canonicalized as a host CsrMatrix
    ↓
cuda_refine_with_preconditioner(A, that exact P, ...)
    ↓
CudaGmresContext(A, P, ...)
```

In [`src/cuda_ir.cpp`](C:/Users/Anirudh/Desktop/pcapproj/src/cuda_ir.cpp:82), `cuda_gpu_spai_gmres_ir()` passes `out.solver.construction.preconditioner` directly into `cuda_refine_with_preconditioner()`. There is no CPU SPAI rebuild and no fallback preconditioner.

There is, however, a host round trip:

1. CUDA SPAI assembles \(P\) on the GPU.
2. \(P\) values are downloaded.
3. The host canonicalizes them through `CsrMatrix`.
4. The persistent GPU GMRES context uploads \(A\) and \(P\).

The handoff explicitly records that this is not a direct device-to-device ownership transfer.

For comparison:

- `cuda_spai_gmres_ir()` uses **CPU-constructed** SPAI \(P\), then GPU GMRES.
- `cuda_gpu_spai_gmres_ir()` uses the **CUDA-constructed** \(P\), then the same GPU GMRES/CPU-outer refinement path.

## 5. CUDA-SPAI work split

CUDA-SPAI is separate from the GMRES iteration.

GPU work includes:

- row scaling and construction of sparse \(B=A^T D\);
- reduced-matrix gathering;
- cuSOLVER QR;
- application of \(Q^T\);
- triangular solves;
- fitted and full residual calculations;
- candidate-score kernels;
- final packed \(P=N^T D\) assembly.

CPU work includes:

- pattern and shadow formation;
- candidate metadata;
- sorting;
- score mean/filter/tie decisions;
- adaptive scheduling;
- fit-history management;
- final host canonicalization of \(P\).

See [`src/cuda_spai.cu`](C:/Users/Anirudh/Desktop/pcapproj/src/cuda_spai.cu:179) and [`CODEBASE_GUIDE.md`](C:/Users/Anirudh/Desktop/pcapproj/CODEBASE_GUIDE.md:100).

## 6. New project code versus MATLAB functionality

The repository contains no local MATLAB implementation; the handoff explicitly says the MATLAB reference was not cached in the project. The MATLAB behavior was inspected externally only for selected parts, especially `spai_dd.m`.

### Algorithmic functionality already represented in the MATLAB baseline

At the algorithm level, the MATLAB baseline already contains the CPU-oriented SPAI–GMRES–IR ideas:

- identity-starting SPAI patterns;
- QR-based sparse approximate-inverse fits;
- adaptive candidate growth;
- restricted candidate scoring;
- \(x_0=P b\);
- residual \(r=b-Ax\);
- left-preconditioned correction solve;
- correction update \(x\leftarrow x+d\).

### Newly implemented by this project

The project implemented the actual production backends and infrastructure:

- canonical C++ CSR matrix representation and Matrix Market input;
- C++ CPU SPAI, GMRES, and iterative refinement;
- CUDA CSR SpMV;
- GPU-resident binary64 GMRES;
- persistent GPU GMRES context and transfer telemetry;
- safe-scaled device norm;
- CUDA SPAI construction;
- sparse \(B\), compact QR workspaces, and packed GPU \(P\);
- CPU-outer/GPU-inner iterative refinement;
- CUDA-SPAI-to-GPU-GMRES integration;
- CLI, CUDA build graph, regression tests, sanitizer checks, and independent validation tooling.

### Important: it is not a bitwise MATLAB port

The project deliberately reconciles several MATLAB behaviors:

- MATLAB `spai_dd.m` uses strict `< epsilon`; the project uses `<= epsilon`.
- MATLAB’s `1:alpha` behavior differs from the project’s explicit growth-event budget.
- MATLAB applies `sqrt(abs(delta))` to the score radicand; the project uses a bounded negative-radicand guard.
- The project adds explicit rank, nonfinite-arithmetic, candidate-exhaustion, overflow, and failure statuses.

These differences are recorded in [`docs/PHASE2A_ALGORITHM_SPEC.md`](C:/Users/Anirudh/Desktop/pcapproj/docs/PHASE2A_ALGORITHM_SPEC.md:101). Exact MATLAB GMRES/IR normalization and stopping-source equivalence was not fully verified, so the project should be described as a **new C++/CUDA implementation of the specified algorithm**, not as a line-by-line MATLAB translation.
