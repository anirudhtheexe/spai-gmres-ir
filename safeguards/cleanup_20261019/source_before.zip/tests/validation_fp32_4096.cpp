// Validation-only Experiment 2A 4096 pipeline driver.  It deliberately calls
// the public FP32 APIs exactly once per backend and contains no timing loop.
#include "bspai/fp32_cuda_spai.hpp"
#include "bspai/fp32_cuda_gmres.hpp"
#include <cuda_runtime_api.h>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <string>
#include <cstdio>
#include <vector>

namespace {
using bspai::Fp32CsrMatrix;
#ifndef BSPAI_VALIDATION_N
#define BSPAI_VALIDATION_N 4096
#endif
#ifndef BSPAI_VALIDATION_NNZ
#define BSPAI_VALIDATION_NNZ 20224
#endif
#ifndef BSPAI_VALIDATION_ALPHA
#define BSPAI_VALIDATION_ALPHA 512
#endif
#ifndef BSPAI_VALIDATION_TAG
#define BSPAI_VALIDATION_TAG "FP32_4096"
#endif

struct MatrixInput { Fp32CsrMatrix matrix; std::vector<std::string> source_values; };

std::uint32_t bits(float value) {
    std::uint32_t result = 0;
    std::memcpy(&result, &value, sizeof result);
    return result;
}

void number_bits(std::ostream& out, const std::vector<float>& values) {
    out << '[';
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (i) out << ',';
        out << bits(values[i]);
    }
    out << ']';
}

void json_string(std::ostream& out, const std::string& value) {
    out << '"';
    for (char c : value) {
        if (c == '\\' || c == '"') out << '\\';
        out << c;
    }
    out << '"';
}

MatrixInput read_fp32_matrix_market(const std::string& path) {
    std::ifstream input(path.c_str());
    if (!input) throw std::runtime_error("cannot open immutable Matrix Market input");
    std::string banner;
    if (!std::getline(input, banner) || banner != "%%MatrixMarket matrix coordinate real general")
        throw std::runtime_error("expected general real coordinate Matrix Market input");
    std::string line;
    do { if (!std::getline(input, line)) throw std::runtime_error("missing Matrix Market dimensions"); }
    while (!line.empty() && line[0] == '%');
    std::istringstream dimensions(line);
    std::size_t rows = 0, cols = 0, entries = 0;
    if (!(dimensions >> rows >> cols >> entries) || !rows || rows != cols)
        throw std::runtime_error("expected nonempty square Matrix Market matrix");
    std::vector<bspai::Fp32Entry> values;
    std::vector<std::string> source_values;
    values.reserve(entries); source_values.reserve(entries);
    for (std::size_t k = 0; k < entries; ++k) {
        if (!std::getline(input, line)) throw std::runtime_error("truncated Matrix Market entries");
        std::istringstream entry(line);
        std::size_t row = 0, col = 0; std::string decimal;
        if (!(entry >> row >> col >> decimal) || !row || !col || row > rows || col > cols)
            throw std::runtime_error("invalid Matrix Market entry");
        std::size_t used = 0;
        const float value = std::stof(decimal, &used);
        if (used != decimal.size() || !std::isfinite(value)) throw std::runtime_error("nonfinite FP32 matrix entry");
        values.push_back({row - 1, col - 1, value});
        source_values.push_back(decimal);
    }
    return {Fp32CsrMatrix::from_entries(rows, cols, values), source_values};
}

std::vector<float> periodic7_truth(std::size_t n) {
    std::vector<float> truth(n);
    for (std::size_t i = 0; i < n; ++i) truth[i] = static_cast<float>(static_cast<int>(i % 7) - 3) / 4.0f;
    return truth;
}

struct ConstructionSummary { std::size_t fits = 0, growths = 0; };
ConstructionSummary summarize(const bspai::Fp32SpaiResult& result) {
    ConstructionSummary summary;
    for (const auto& column : result.columns) { summary.fits += column.fits; summary.growths += column.growths; }
    return summary;
}

std::size_t pattern_symmetric_difference(const Fp32CsrMatrix& left, const Fp32CsrMatrix& right) {
    if (left.rows() != right.rows() || left.cols() != right.cols()) return std::numeric_limits<std::size_t>::max();
    std::size_t difference = 0;
    for (std::size_t row = 0; row < left.rows(); ++row) {
        std::size_t i = left.row_offsets()[row], j = right.row_offsets()[row];
        const std::size_t ie = left.row_offsets()[row + 1], je = right.row_offsets()[row + 1];
        while (i < ie || j < je) {
            if (j == je || (i < ie && left.column_indices()[i] < right.column_indices()[j])) { ++difference; ++i; }
            else if (i == ie || right.column_indices()[j] < left.column_indices()[i]) { ++difference; ++j; }
            else { ++i; ++j; }
        }
    }
    return difference;
}

double relative_forward_error(const std::vector<float>& x, const std::vector<float>& truth) {
    long double numerator = 0, denominator = 0;
    for (std::size_t i = 0; i < x.size(); ++i) {
        const long double delta = static_cast<long double>(x[i]) - truth[i];
        numerator += delta * delta; denominator += static_cast<long double>(truth[i]) * truth[i];
    }
    return static_cast<double>(std::sqrt(numerator) / std::sqrt(denominator));
}

void emit_inner(std::ostream& out, const bspai::Fp32IrResult& result) {
    out << "\"inner\":[";
    for (std::size_t i = 0; i < result.inner_history.size(); ++i) {
        if (i) out << ',';
        const auto& inner = result.inner_history[i];
        out << "{\"status\":\"" << bspai::fp32_gmres_status_name(inner.status)
            << "\",\"converged\":" << (inner.converged ? "true" : "false")
            << ",\"iterations\":" << inner.iterations
            << ",\"reported_preconditioned_relative_bits\":" << bits(inner.final_preconditioned_relative) << '}';
    }
    out << ']';
}

void emit_outer(std::ostream& out, const bspai::Fp32IrResult& result) {
    out << "\"outer_be_bits\":[";
    for (std::size_t i = 0; i < result.outer_history.size(); ++i) {
        if (i) out << ',';
        out << bits(result.outer_history[i].normwise_backward_error);
    }
    out << ']';
}

void emit_run(std::ostream& out, const char* backend, const Fp32CsrMatrix& matrix,
              const std::vector<float>& rhs, const std::vector<float>& truth,
              const bspai::Fp32IrResult& result) {
    const ConstructionSummary construction = summarize(result.construction);
    const bspai::Fp32IrDiagnostics diagnostics = bspai::fp32_evaluate_ir_diagnostics(matrix, rhs, result.solution);
    out << "\"backend\":\"" << backend << "\",\"status\":\"" << bspai::fp32_ir_status_name(result.status)
        << "\",\"converged\":" << (result.converged ? "true" : "false")
        << ",\"construction_status\":\"" << bspai::fp32_spai_status_name(result.construction.status)
        << "\",\"p_nnz\":" << result.construction.preconditioner_nnz
        << ",\"fits\":" << construction.fits << ",\"growths\":" << construction.growths
        << ",\"outer_steps\":" << result.outer_steps << ",\"inner_attempts\":" << result.inner_attempts << ',';
    emit_inner(out, result); out << ','; emit_outer(out, result);
    out << ",\"final_residual_inf_bits\":" << bits(diagnostics.residual_inf)
        << ",\"final_residual_2_bits\":" << bits(diagnostics.residual_2)
        << ",\"final_backward_error_bits\":" << bits(diagnostics.normwise_backward_error)
        << ",\"forward_error_host_long_double\":" << relative_forward_error(result.solution, truth)
        << ",\"solution_bits\":";
    number_bits(out, result.solution);
    out << '}';
}
}

int main(int argc, char** argv) {
    try {
        if (argc != 4) throw std::runtime_error("usage: validation_fp32 immutable-matrix.mtx expected-nnz persistent-output.jsonl");
        const std::string matrix_path = argv[1], output_path = argv[3], temporary_path = output_path + ".tmp";
        const std::size_t expected_nnz = static_cast<std::size_t>(std::stoull(argv[2]));
        { std::ifstream existing(output_path.c_str()); if (existing) throw std::runtime_error("refusing to overwrite validation snapshot"); }
        { std::ifstream existing(temporary_path.c_str()); if (existing) throw std::runtime_error("stale validation temporary snapshot exists"); }
        const MatrixInput input = read_fp32_matrix_market(matrix_path);
        const Fp32CsrMatrix& matrix = input.matrix;
        if (matrix.rows() != BSPAI_VALIDATION_N || matrix.values().size() != expected_nnz) throw std::runtime_error("unexpected immutable validation input dimensions");
        const std::vector<float> truth = periodic7_truth(matrix.rows());
        const std::vector<float> rhs = matrix.multiply(truth);
        bspai::Fp32IrOptions options;
        options.spai.epsilon = .3f; options.spai.beta = 8; options.spai.alpha = BSPAI_VALIDATION_ALPHA;
        options.gmres.tolerance = 1.0e-4f; options.gmres.max_iterations = matrix.rows(); options.max_outer_steps = 20;

        // This is exactly one public CPU full-pipeline execution.
        const bspai::Fp32IrResult cpu = bspai::fp32_spai_gmres_ir(matrix, rhs, options);
        std::size_t free_before = 0, total_before = 0, free_after = 0, total_after = 0;
        const cudaError_t before_status = cudaMemGetInfo(&free_before, &total_before);
        if (before_status != cudaSuccess) throw std::runtime_error("cudaMemGetInfo before GPU pipeline failed");
        // This is exactly one public GPU full-pipeline execution.
        const bspai::Fp32IrResult gpu = bspai::fp32_cuda_spai_gmres_ir(matrix, rhs, options);
        const cudaError_t after_status = cudaMemGetInfo(&free_after, &total_after);
        if (after_status != cudaSuccess) throw std::runtime_error("cudaMemGetInfo after GPU pipeline failed");

        std::ofstream snapshot(temporary_path.c_str(), std::ios::out | std::ios::trunc);
        if (!snapshot) throw std::runtime_error("cannot create validation temporary snapshot");
        snapshot << std::setprecision(std::numeric_limits<double>::max_digits10);
        snapshot << BSPAI_VALIDATION_TAG << "_INPUT {\"matrix_path\":"; json_string(snapshot, matrix_path);
        snapshot << ",\"rows\":" << matrix.rows() << ",\"nnz\":" << matrix.values().size()
                  << ",\"alpha\":" << BSPAI_VALIDATION_ALPHA << ",\"beta\":8,\"epsilon_bits\":" << bits(.3f)
                  << ",\"gmres_tolerance_bits\":" << bits(1.0e-4f)
                  << ",\"outer_tolerance_bits\":" << bits(bspai::fp32_ir_backward_tolerance())
                  << ",\"matrix_value_bits\":";
        number_bits(snapshot, matrix.values());
        snapshot << ",\"rhs_bits\":"; number_bits(snapshot, rhs);
        snapshot << ",\"truth_bits\":"; number_bits(snapshot, truth); snapshot << "}\n";
        snapshot << BSPAI_VALIDATION_TAG << "_RESULT {\"cpu\":{"; emit_run(snapshot, "cpu", matrix, rhs, truth, cpu);
        snapshot << ",\"gpu\":{"; emit_run(snapshot, "gpu", matrix, rhs, truth, gpu);
        snapshot << ",\"p_pattern_symmetric_difference\":"
                  << pattern_symmetric_difference(cpu.construction.preconditioner, gpu.construction.preconditioner)
                  << ",\"gpu_vram_before_free\":" << free_before << ",\"gpu_vram_after_free\":" << free_after
                  << ",\"gpu_vram_total\":" << total_before << "}\n";
        snapshot.close();
        if (!snapshot) { std::remove(temporary_path.c_str()); throw std::runtime_error("failed while writing validation snapshot"); }
        if (std::rename(temporary_path.c_str(), output_path.c_str()) != 0) {
            std::remove(temporary_path.c_str());
            throw std::runtime_error("atomic validation snapshot publication failed");
        }
        std::cout << BSPAI_VALIDATION_TAG << " snapshot=" << output_path << '\n';
        return cpu.converged && gpu.converged ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "validation_fp32_4096: " << error.what() << '\n';
        return 2;
    }
}
