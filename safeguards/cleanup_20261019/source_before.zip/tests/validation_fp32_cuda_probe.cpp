#include "bspai/fp32_cuda_gmres.hpp"
#include <iostream>
#include <cstdio>
#include <cstring>

static void print_result(const char* label, const bspai::Fp32GmresResult& r) {
    std::printf("%s status=%s converged=%d iterations=%zu solution=", label,
                bspai::fp32_gmres_status_name(r.status), r.converged ? 1 : 0, r.iterations);
    for (float x : r.solution) { unsigned bits=0; std::memcpy(&bits,&x,sizeof(bits)); std::printf("%.9g[0x%08x] ", static_cast<double>(x),bits); }
    std::printf("reported_original=%.9g reported_preconditioned_relative=%.9g\\n",
                static_cast<double>(r.final_original_residual),
                static_cast<double>(r.final_preconditioned_relative));
    std::printf("history estimate=");
    for(float x:r.hessenberg_residual_history) std::printf("%.9g ",static_cast<double>(x));
    std::printf("original=");
    for(float x:r.original_residual_history) std::printf("%.9g ",static_cast<double>(x));
    std::printf("relative=");
    for(float x:r.preconditioned_relative_history) std::printf("%.9g ",static_cast<double>(x));
    std::printf("\\n");
}
int main() {
    const bspai::Fp32CsrMatrix a = bspai::Fp32CsrMatrix::from_entries(3, 3, {
        {0,0,4.0f}, {0,1,-1.0f}, {1,0,-2.0f}, {1,1,5.0f}, {1,2,-1.0f}, {2,1,-1.0f}, {2,2,3.0f}});
    const bspai::Fp32CsrMatrix p = bspai::Fp32CsrMatrix::from_entries(3, 3,
        {{0,0,1.0f}, {1,1,1.0f}, {2,2,1.0f}});
    const std::vector<float> truth{.25f, -.5f, .75f};
    const std::vector<float> rhs = a.multiply(truth);
    bspai::Fp32GmresOptions o; o.tolerance=1e-4f; o.max_iterations=3;
    const std::vector<float> x0{.1f, -.2f, .3f};
    print_result("cpu", bspai::fp32_left_preconditioned_gmres(a,p,rhs,o,x0));
    print_result("gpu", bspai::fp32_cuda_left_preconditioned_gmres(a,p,rhs,o,x0));
}
