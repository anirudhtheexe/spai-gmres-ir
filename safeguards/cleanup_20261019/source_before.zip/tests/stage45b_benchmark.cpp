// Stage 4.5B exploratory benchmark harness.  This is test infrastructure:
// it neither changes nor reimplements SPAI, GMRES, or iterative refinement.
#include "bspai/cuda_ir.hpp"
#include <cuda_runtime_api.h>
#include <chrono>
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <sstream>
#include <vector>

// All fields added in this file are emitted after the measured public API
// call.  They are benchmark diagnostics only; they must not alter the
// frozen solver call or its numerical inputs.

namespace {
using Clock = std::chrono::steady_clock;

struct Args {
    std::string matrix, mode, rhs = "equal_unit2", p_path, p_output;
    double epsilon = 0.3;
    std::size_t alpha = 0, beta = 8, innercap = 0, outercap = 20;
    std::size_t warmups = 3, trials = 10;
};

std::string quote(const std::string& s) {
    std::string r("\"");
    for (char c : s) { if (c == '\\' || c == '\"') r += '\\'; if (c == '\n') r += "\\n"; else r += c; }
    return r + '\"';
}
void numbers(std::ostream& out, const std::vector<double>& values) {
    out << '[';
    for (std::size_t i = 0; i < values.size(); ++i) { if (i) out << ','; out << values[i]; }
    out << ']';
}
std::size_t count(const std::string& s) {
    if (s.empty() || s.find_first_not_of("0123456789") != std::string::npos) throw std::invalid_argument("invalid count");
    std::size_t used = 0; const unsigned long long n = std::stoull(s, &used);
    if (used != s.size() || n > std::numeric_limits<std::size_t>::max()) throw std::invalid_argument("count out of range");
    return static_cast<std::size_t>(n);
}
Args parse(int argc, char** argv) {
    Args a;
    for (int i = 1; i < argc; i += 2) {
        if (i + 1 == argc || std::string(argv[i]).compare(0, 2, "--") != 0) throw std::invalid_argument("arguments are --key value pairs");
        const std::string key(argv[i]), value(argv[i + 1]);
        if (key == "--matrix") a.matrix = value; else if (key == "--mode") a.mode = value;
        else if (key == "--rhs") a.rhs = value; else if (key == "--p") a.p_path = value;
        else if (key == "--p-output") a.p_output = value; else if (key == "--epsilon") a.epsilon = std::stod(value);
        else if (key == "--alpha") a.alpha = count(value); else if (key == "--beta") a.beta = count(value);
        else if (key == "--innercap") a.innercap = count(value); else if (key == "--outercap") a.outercap = count(value);
        else if (key == "--warmups") a.warmups = count(value); else if (key == "--trials") a.trials = count(value);
        else throw std::invalid_argument("unknown option: " + key);
    }
    if (a.matrix.empty() || a.mode.empty() || !std::isfinite(a.epsilon) || a.epsilon <= 0 || !a.beta)
        throw std::invalid_argument("matrix, mode, finite epsilon, and nonzero beta are required");
    return a;
}
bspai::CsrMatrix load(const std::string& path) {
    std::ifstream in(path); if (!in) throw std::invalid_argument("cannot open matrix: " + path);
    return bspai::read_matrix_market(in);
}
void write_matrix_market(const std::string& path, const bspai::CsrMatrix& a) {
    std::ofstream out(path, std::ios::out | std::ios::trunc);
    if (!out) throw std::invalid_argument("cannot create fixed-P file: " + path);
    out << std::setprecision(std::numeric_limits<double>::max_digits10);
    out << "%%MatrixMarket matrix coordinate real general\n% Stage45B canonical CPU SPAI P; preparation is outside timing\n";
    out << a.rows() << ' ' << a.cols() << ' ' << a.values().size() << '\n';
    for (std::size_t row = 0; row < a.rows(); ++row)
        for (std::size_t p = a.row_offsets()[row]; p < a.row_offsets()[row + 1]; ++p)
            out << row + 1 << ' ' << a.column_indices()[p] + 1 << ' ' << a.values()[p] << '\n';
    if (!out) throw std::runtime_error("failed while writing fixed-P file");
}
std::vector<double> rhs_for(const bspai::CsrMatrix& a, const std::string& kind) {
    if (kind == "equal_unit2") return std::vector<double>(a.rows(), 1.0 / std::sqrt(static_cast<double>(a.rows())));
    if (kind == "periodic7") { std::vector<double> x(a.rows()); for (std::size_t i = 0; i < x.size(); ++i) x[i] = static_cast<double>(static_cast<int>(i % 7) - 3) / 4; return a.multiply(x); }
    throw std::invalid_argument("rhs must be equal_unit2 or periodic7");
}
std::vector<double> manufactured_solution(const bspai::CsrMatrix& a, const std::string& kind) {
    if (kind != "periodic7") return {};
    std::vector<double> x(a.rows());
    for (std::size_t i = 0; i < x.size(); ++i)
        x[i] = static_cast<double>(static_cast<int>(i % 7) - 3) / 4;
    return x;
}
bspai::IrOptions options_for(const Args& args, std::size_t n) {
    bspai::IrOptions o; o.spai.epsilon = args.epsilon; o.spai.alpha = args.alpha; o.spai.beta = args.beta;
    o.gmres.max_iterations = args.innercap; o.max_outer_steps = args.outercap;
    if (!n || o.spai.alpha > n || o.gmres.max_iterations > n || o.max_outer_steps > 20) throw std::invalid_argument("invalid frozen caps");
    return o;
}
void gpu_sync() { const cudaError_t s = cudaDeviceSynchronize(); if (s != cudaSuccess) throw std::runtime_error(cudaGetErrorString(s)); }
void gpu_memory(std::ostream& out) { std::size_t free = 0, total = 0; const cudaError_t s = cudaMemGetInfo(&free, &total); if (s == cudaSuccess) out << "{\"free_bytes\":" << free << ",\"total_bytes\":" << total << '}'; else out << "{\"error\":" << quote(cudaGetErrorString(s)) << '}'; }
void construction_fields(std::ostream& out, const bspai::SpaiResult& r) {
    double max_full = 0;
    std::size_t fits = 0, growths = 0, fit_attempts = 0, growth_attempts = 0;
    std::size_t score_clamps = 0, max_pattern = 0, max_shadow = 0;
    for (const auto& c : r.columns) {
        if (std::isfinite(c.full_residual)) max_full = std::max(max_full, c.full_residual);
        fits += c.fits; growths += c.growths; fit_attempts += c.fit_attempts;
        growth_attempts += c.growth_attempts; score_clamps += c.score_clamps;
        max_pattern = std::max(max_pattern, c.pattern.size());
        for (const auto& f : c.history) {
            max_pattern = std::max(max_pattern, f.pattern.size());
            max_shadow = std::max(max_shadow, f.shadow.size());
        }
    }
    out << "\"construction_status\":" << quote(bspai::spai_status_name(r.status))
        << ",\"construction_nnz_p\":" << r.preconditioner.values().size()
        << ",\"construction_max_full_residual\":" << max_full
        << ",\"construction_fit_count\":" << fits
        << ",\"construction_growth_count\":" << growths
        << ",\"construction_fit_attempt_count\":" << fit_attempts
        << ",\"construction_growth_attempt_count\":" << growth_attempts
        << ",\"construction_score_clamp_count\":" << score_clamps
        << ",\"construction_max_pattern_columns\":" << max_pattern
        << ",\"construction_max_reduced_rows\":" << max_shadow
        << ",\"construction_max_reduced_elements\":" << max_pattern * max_shadow;
}
void diagnostics_fields(std::ostream& out, const bspai::CsrMatrix& a, const std::vector<double>& b,
                        const std::vector<double>& x, const std::vector<double>& reference) {
    const bspai::IrDiagnostics d = bspai::evaluate_ir_diagnostics(a, b, x, reference);
    out << "\"original_residual_2\":" << d.residual_2 << ",\"original_residual_inf\":" << d.residual_inf
        << ",\"normwise_backward_error\":" << d.normwise_backward_error
        << ",\"backward_tolerance\":" << bspai::ir_backward_tolerance()
        << ",\"has_manufactured_reference\":" << d.has_reference
        << ",\"manufactured_forward_error\":" << d.forward_error;
}
void ir_work_fields(std::ostream& out, const bspai::IrResult& r) {
    std::size_t inner_iterations = 0, accepted_inner = 0;
    for (const auto& g : r.inner_history) {
        inner_iterations += g.iterations;
        accepted_inner += g.converged ? 1 : 0;
    }
    out << ",\"outer_history_count\":" << r.history.size()
        << ",\"inner_history_count\":" << r.inner_history.size()
        << ",\"inner_total_iterations\":" << inner_iterations
        << ",\"inner_converged_count\":" << accepted_inner;
}
void cuda_spai_wall_clock_fields(std::ostream& out, const bspai::CudaSpaiTelemetry& t) {
    out << ",\"gpu_spai_telemetry\":{\"allocation_calls\":" << t.device_allocation_calls
        << ",\"free_calls\":" << t.device_free_calls << ",\"reallocation_calls\":" << t.device_reallocation_calls
        << ",\"allocated_bytes_cumulative\":" << t.device_allocated_bytes << ",\"freed_bytes_cumulative\":" << t.device_freed_bytes
        << ",\"peak_device_bytes\":" << t.peak_device_bytes << ",\"max_single_allocation_bytes\":" << t.max_single_allocation_bytes
        << ",\"current_device_bytes_at_return\":" << t.current_device_bytes << ",\"outstanding_allocations_at_return\":" << t.outstanding_device_allocations
        << ",\"allocation_wall_ms\":" << t.allocation_wall_ms << ",\"free_wall_ms\":" << t.free_wall_ms
        << ",\"uploads\":" << t.uploads << ",\"upload_bytes\":" << t.upload_bytes << ",\"upload_min_bytes\":" << t.upload_min_bytes << ",\"upload_max_bytes\":" << t.upload_max_bytes
        << ",\"upload_size_buckets\":{\"le_256\":" << t.upload_le_256_bytes << ",\"le_4096\":" << t.upload_le_4096_bytes << ",\"gt_4096\":" << t.upload_gt_4096_bytes << '}'
        << ",\"downloads\":" << t.downloads << ",\"download_bytes\":" << t.download_bytes << ",\"download_min_bytes\":" << t.download_min_bytes << ",\"download_max_bytes\":" << t.download_max_bytes
        << ",\"download_size_buckets\":{\"le_256\":" << t.download_le_256_bytes << ",\"le_4096\":" << t.download_le_4096_bytes << ",\"gt_4096\":" << t.download_gt_4096_bytes << '}'
        << ",\"synchronizations\":{\"upload_lifetime\":" << t.upload_synchronizations << ",\"download_lifetime\":" << t.download_synchronizations << ",\"explicit_completion\":" << t.explicit_synchronizations << '}'
        << ",\"streams\":" << t.streams_created << ",\"qr_submissions\":" << t.qr_submissions << ",\"score_evaluations\":" << t.gpu_score_evaluations
        << ",\"wall_clock_ms\":{\"total\":" << t.construction_wall_total_ms << ",\"matrix_setup\":" << t.construction_wall_matrix_setup_ms << ",\"adaptive_fits\":" << t.construction_wall_adaptive_fits_ms << ",\"packing_assembly\":" << t.construction_wall_packing_assembly_ms << "}}";
}
void emit_manifest(const Args& args, const bspai::CsrMatrix& a) {
    std::cout << "{\"schema_version\":1,\"event\":\"manifest\",\"stage\":\"4.5B exploratory\",\"mode\":" << quote(args.mode)
              << ",\"matrix\":" << quote(args.matrix) << ",\"rows\":" << a.rows() << ",\"cols\":" << a.cols() << ",\"nnz\":" << a.values().size()
              << ",\"rhs\":" << quote(args.rhs) << ",\"epsilon\":" << args.epsilon << ",\"alpha\":" << args.alpha << ",\"beta\":" << args.beta
              << ",\"tau\":1e-8,\"innercap\":" << args.innercap << ",\"outercap\":" << args.outercap << ",\"warmups\":" << args.warmups << ",\"measured_trials\":" << args.trials
              << ",\"clock\":\"std::chrono::steady_clock host wall time\",\"primary_boundary\":\"whole frozen public API call; for CUDA, cudaDeviceSynchronize immediately before start and immediately after return. Public calls own their observable allocation, transfer, host processing, and cleanup. No numerical diagnostic is inside this interval.\"}\n";
}
template<class Run, class Post>
void execute_samples(const Args& args, bool gpu, Run run, Post post) {
    const std::size_t total = args.warmups + args.trials;
    for (std::size_t ordinal = 0; ordinal < total; ++ordinal) {
        const bool measured = ordinal >= args.warmups;
        std::size_t before_free = 0, before_total = 0, after_free = 0, after_total = 0;
        if (gpu) { gpu_sync(); cudaMemGetInfo(&before_free, &before_total); }
        const Clock::time_point begin = Clock::now();
        std::string body, error;
        try {
            // The lambda contains precisely one frozen public API call.
            // CUDA completion is part of the primary endpoint, not a diagnostic.
            const auto result = run();
            if (gpu) gpu_sync();
            const double elapsed_ms = std::chrono::duration<double, std::milli>(Clock::now() - begin).count();
            if (gpu) cudaMemGetInfo(&after_free, &after_total);
            std::ostringstream post_stream; post_stream << std::setprecision(std::numeric_limits<double>::max_digits10);
            post(post_stream, result); body = post_stream.str();
            std::cout << std::setprecision(std::numeric_limits<double>::max_digits10) << "{\"schema_version\":1,\"event\":\"sample\",\"mode\":" << quote(args.mode)
                      << ",\"phase\":" << quote(measured ? "measured" : "warmup") << ",\"ordinal\":" << ordinal
                      << ",\"elapsed_ms\":" << elapsed_ms << ",\"timing_components\":{\"primary_public_api_and_sync_ms\":" << elapsed_ms
                      << ",\"separate_setup_transfer_cleanup_ms\":null,\"separate_components_note\":\"not externally observable without changing the frozen public-call boundary\"}";
            if (gpu) std::cout << ",\"gpu_memory_before\":{\"free_bytes\":" << before_free << ",\"total_bytes\":" << before_total << "},\"gpu_memory_after\":{\"free_bytes\":" << after_free << ",\"total_bytes\":" << after_total << '}';
            std::cout << ',' << body << "}\n";
            continue;
        } catch (const std::exception& e) { error = e.what(); }
        // Even an exception record retains its measured API interval, but no
        // post-timing numerical diagnostic or memory inference is attempted.
        if (gpu) { try { gpu_sync(); cudaMemGetInfo(&after_free, &after_total); } catch (...) {} }
        const double elapsed_ms = std::chrono::duration<double, std::milli>(Clock::now() - begin).count();
        std::cout << std::setprecision(17) << "{\"schema_version\":1,\"event\":\"sample\",\"mode\":" << quote(args.mode)
                  << ",\"phase\":" << quote(measured ? "measured" : "warmup") << ",\"ordinal\":" << ordinal
                  << ",\"elapsed_ms\":" << elapsed_ms << ",\"timing_components\":{\"primary_public_api_and_sync_ms\":" << elapsed_ms
                  << ",\"separate_setup_transfer_cleanup_ms\":null,\"separate_components_note\":\"not externally observable without changing the frozen public-call boundary\"}";
        if (gpu) std::cout << ",\"gpu_memory_before\":{\"free_bytes\":" << before_free << ",\"total_bytes\":" << before_total << "},\"gpu_memory_after\":{\"free_bytes\":" << after_free << ",\"total_bytes\":" << after_total << '}';
        std::cout << ",\"harness_exception\":" << quote(error) << ",\"status\":\"harness_exception\",\"converged\":false";
        std::cout << "}\n";
    }
}
}

int main(int argc, char** argv) {
    try {
        std::cout << std::setprecision(std::numeric_limits<double>::max_digits10) << std::boolalpha;
        const Args args = parse(argc, argv); const bspai::CsrMatrix a = load(args.matrix); const bspai::IrOptions options = options_for(args, a.rows()); const std::vector<double> b = rhs_for(a, args.rhs); const std::vector<double> reference = manufactured_solution(a, args.rhs);
        if (a.rows() != a.cols()) throw std::invalid_argument("benchmark matrix must be nonempty square");
        if (args.mode == "prepare_fixed_p") {
            if (args.p_output.empty()) throw std::invalid_argument("prepare_fixed_p requires --p-output");
            const bspai::SpaiResult r = bspai::construct_spai(a, options.spai);
            if (r.status == bspai::SpaiStatus::success) write_matrix_market(args.p_output, r.preconditioner);
            std::cout << "{\"schema_version\":1,\"event\":\"fixed_p_preparation\",\"matrix\":" << quote(args.matrix) << ','; construction_fields(std::cout, r); std::cout << ",\"p_output\":" << quote(args.p_output) << "}\n";
            return r.status == bspai::SpaiStatus::success ? 0 : 1;
        }
        emit_manifest(args, a);
        if (args.mode == "cpu_spai") execute_samples(args, false, [&]() { return bspai::construct_spai(a, options.spai); }, [&](std::ostream& o, const bspai::SpaiResult& r) { construction_fields(o, r); o << ",\"status\":" << quote(bspai::spai_status_name(r.status)) << ",\"converged\":" << (r.status == bspai::SpaiStatus::success); });
        else if (args.mode == "gpu_spai") execute_samples(args, true, [&]() { return bspai::cuda_construct_spai(a, options.spai); }, [&](std::ostream& o, const bspai::CudaSpaiResult& r) { construction_fields(o, r.construction); o << ",\"status\":" << quote(bspai::spai_status_name(r.construction.status)) << ",\"converged\":" << (r.construction.status == bspai::SpaiStatus::success) << ",\"gpu_spai_peak_device_bytes\":" << r.telemetry.peak_device_bytes << ",\"gpu_spai_upload_bytes\":" << r.telemetry.upload_bytes << ",\"gpu_spai_download_bytes\":" << r.telemetry.download_bytes; cuda_spai_wall_clock_fields(o,r.telemetry); });
        else if (args.mode == "cpu_pipeline") execute_samples(args, false, [&]() { return bspai::spai_gmres_ir(a, b, options); }, [&](std::ostream& o, const bspai::IrResult& r) { o << "\"status\":" << quote(bspai::ir_status_name(r.status)) << ",\"converged\":" << r.converged << ",\"outer_steps\":" << r.outer_steps << ",\"inner_attempts\":" << r.inner_attempts << ','; construction_fields(o, r.construction); ir_work_fields(o, r); o << ','; diagnostics_fields(o, a, b, r.solution, reference); o << ",\"solution\":"; numbers(o, r.solution); });
        else if (args.mode == "gpu_pipeline") execute_samples(args, true, [&]() { return bspai::cuda_gpu_spai_gmres_ir(a, b, options); }, [&](std::ostream& o, const bspai::CudaIrResult& r) { o << "\"status\":" << quote(bspai::ir_status_name(r.solver.status)) << ",\"converged\":" << r.solver.converged << ",\"outer_steps\":" << r.solver.outer_steps << ",\"inner_attempts\":" << r.solver.inner_attempts << ','; construction_fields(o, r.solver.construction); ir_work_fields(o, r.solver); o << ','; diagnostics_fields(o, a, b, r.solver.solution, reference); o << ",\"solution\":"; numbers(o, r.solver.solution); o << ",\"gpu_spai_peak_device_bytes\":" << r.gpu_spai_telemetry.peak_device_bytes << ",\"gpu_spai_upload_bytes\":" << r.gpu_spai_telemetry.upload_bytes << ",\"gpu_spai_download_bytes\":" << r.gpu_spai_telemetry.download_bytes; cuda_spai_wall_clock_fields(o,r.gpu_spai_telemetry); });
        else if (args.mode == "cpu_gmres_fixed" || args.mode == "gpu_gmres_fixed") {
            if (args.p_path.empty()) throw std::invalid_argument("fixed-P modes require --p prepared before timing"); const bspai::CsrMatrix p = load(args.p_path);
            if (p.rows() != a.rows() || p.cols() != a.cols()) throw std::invalid_argument("fixed P has wrong dimensions");
            if (args.mode == "cpu_gmres_fixed") execute_samples(args, false, [&]() { return bspai::left_preconditioned_gmres(a, p, b, options.gmres); }, [&](std::ostream& o, const bspai::GmresResult& r) { o << "\"status\":" << quote(bspai::gmres_status_name(r.status)) << ",\"converged\":" << r.converged << ",\"iterations\":" << r.iterations << ",\"final_preconditioned_relative\":" << r.final_preconditioned_relative << ','; diagnostics_fields(o, a, b, r.solution, reference); o << ",\"solution\":"; numbers(o, r.solution); });
            else execute_samples(args, true, [&]() { return bspai::cuda_left_preconditioned_gmres(a, p, b, options.gmres); }, [&](std::ostream& o, const bspai::CudaGmresResult& r) { o << "\"status\":" << quote(bspai::gmres_status_name(r.solver.status)) << ",\"converged\":" << r.solver.converged << ",\"iterations\":" << r.solver.iterations << ",\"final_preconditioned_relative\":" << r.solver.final_preconditioned_relative << ','; diagnostics_fields(o, a, b, r.solver.solution, reference); o << ",\"solution\":"; numbers(o, r.solver.solution); });
        } else throw std::invalid_argument("mode must be prepare_fixed_p, cpu_spai, gpu_spai, cpu_gmres_fixed, gpu_gmres_fixed, cpu_pipeline, or gpu_pipeline");
    } catch (const std::exception& e) { std::cerr << "stage45b_benchmark: " << e.what() << '\n'; return 2; }
}
