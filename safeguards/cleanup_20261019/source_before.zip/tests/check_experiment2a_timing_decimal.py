"""Snapshot-only Decimal80 acceptance checker for Experiment 2A timing rows.

It never starts a solver.  It reconstructs the immutable periodic7 RHS in the
declared working precision, then checks every retained measured solution.
"""
import argparse
import decimal
import json
import struct
import sys
from pathlib import Path

decimal.getcontext().prec = 80


def f32(value):
    return struct.unpack("<f", struct.pack("<f", float(value)))[0]


def load_mm(path, precision):
    entries = {}
    lines = [line.strip() for line in Path(path).read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    if not lines[0].lower().startswith("%%matrixmarket matrix coordinate real general"):
        raise ValueError("expected real general Matrix Market")
    body = [line for line in lines[1:] if not line.startswith("%")]
    n, m, _ = map(int, body[0].split())
    if not n or n != m:
        raise ValueError("expected square input")
    for line in body[1:]:
        i, j, value = line.split()[:3]
        key = (int(i) - 1, int(j) - 1)
        parsed = f32(value) if precision == "fp32" else float(value)
        entries[key] = (f32(entries.get(key, 0.0) + parsed) if precision == "fp32" else entries.get(key, 0.0) + parsed)
    return n, {key: value for key, value in entries.items() if value != 0.0}


def periodic_rhs(a, n, precision):
    x = [f32((i % 7 - 3) / 4.0) if precision == "fp32" else (i % 7 - 3) / 4.0 for i in range(n)]
    b = [0.0] * n
    for (i, j), value in a.items():
        term = f32(value * x[j]) if precision == "fp32" else value * x[j]
        b[i] = f32(b[i] + term) if precision == "fp32" else b[i] + term
    return b


def D(value):
    return decimal.Decimal.from_float(float(value))


def diagnostics(a, b, x):
    bd, xd = list(map(D, b)), list(map(D, x))
    ax = [decimal.Decimal(0)] * len(b)
    rows = [decimal.Decimal(0)] * len(b)
    for (i, j), value in a.items():
        value = D(value)
        ax[i] += value * xd[j]
        rows[i] += abs(value)
    residual = [bd[i] - ax[i] for i in range(len(b))]
    rinf = max(map(abs, residual), default=decimal.Decimal(0))
    denom = max(rows, default=decimal.Decimal(0)) * max(map(abs, xd), default=decimal.Decimal(0)) + max(map(abs, bd), default=decimal.Decimal(0))
    eta = decimal.Decimal(0) if denom == 0 and rinf == 0 else rinf / denom
    forward = (sum(((xd[i] - D((i % 7 - 3) / 4.0)) ** 2 for i in range(len(x))), decimal.Decimal(0)).sqrt() /
               sum((D((i % 7 - 3) / 4.0) ** 2 for i in range(len(x))), decimal.Decimal(0)).sqrt())
    return {"residual_inf_decimal80": str(rinf), "normwise_backward_error_decimal80": str(eta), "forward_error_decimal80": str(forward)}


def fixed_relative(a, p, b, x):
    bd, xd = list(map(D, b)), list(map(D, x))
    residual = bd[:]
    for (i, j), value in a.items():
        residual[i] -= D(value) * xd[j]
    pb = [decimal.Decimal(0)] * len(b)
    pr = [decimal.Decimal(0)] * len(b)
    for (i, j), value in p.items():
        value = D(value); pb[i] += value * bd[j]; pr[i] += value * residual[j]
    numerator = sum((z * z for z in pr), decimal.Decimal(0)).sqrt()
    denominator = sum((z * z for z in pb), decimal.Decimal(0)).sqrt()
    return decimal.Decimal(0) if numerator == denominator == 0 else numerator / denominator


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--artifact", required=True)
    parser.add_argument("--matrix", required=True)
    parser.add_argument("--precision", choices=("fp32", "fp64"), required=True)
    parser.add_argument("--mode", required=True)
    parser.add_argument("--fixed-p")
    parser.add_argument("--gmres-tolerance")
    args = parser.parse_args()
    records = [json.loads(line) for line in Path(args.artifact).read_text(encoding="utf-8").splitlines() if line]
    n, a = load_mm(args.matrix, args.precision)
    b = periodic_rhs(a, n, args.precision)
    fixed = load_mm(args.fixed_p, args.precision)[1] if args.fixed_p else None
    target = decimal.Decimal(10) * (decimal.Decimal(2) ** (-24 if args.precision == "fp32" else -53))
    tolerance = decimal.Decimal(args.gmres_tolerance) if args.gmres_tolerance else None
    checked, failures = [], []
    measured = [record for record in records if record.get("event") == "sample" and record.get("phase") == "measured"]
    if len(measured) != 3:
        failures.append("expected exactly three measured records")
    for sample in measured:
        item = {"ordinal": sample.get("ordinal"), "converged": sample.get("converged", False)}
        if not sample.get("converged"):
            item["accepted"] = False; item["failure"] = "solver_not_converged"; failures.append("solver_not_converged")
        elif args.mode.endswith("spai"):
            item["accepted"] = sample.get("construction_status") == "success"
            if not item["accepted"]: failures.append("construction_not_success")
        else:
            x = sample.get("solution")
            if not isinstance(x, list) or len(x) != n:
                item["accepted"] = False; item["failure"] = "missing_or_wrong_length_solution"; failures.append(item["failure"])
            else:
                item.update(diagnostics(a, b, x))
                eta = decimal.Decimal(item["normwise_backward_error_decimal80"])
                if args.mode.endswith("_fixed"):
                    relative = fixed_relative(a, fixed, b, x)
                    item["preconditioned_relative_decimal80"] = str(relative)
                    item["accepted"] = relative <= tolerance
                    if not item["accepted"]: failures.append("fixed_gmres_tolerance")
                else:
                    item["accepted"] = eta <= target
                    if not item["accepted"]: failures.append("pipeline_backward_error")
        checked.append(item)
    result = {"schema_version": 1, "event": "decimal80_snapshot_assessment", "artifact": args.artifact,
              "precision": args.precision, "mode": args.mode, "working_precision_backward_target": str(target),
              "checked": checked, "failures": failures, "accepted": not failures}
    print(json.dumps(result, separators=(",", ":")))
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    sys.exit(main())
