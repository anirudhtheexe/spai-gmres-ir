"""Independent Decimal80 audit for validation_fp32_4096; never feeds a solver."""
import argparse
from decimal import Decimal as D, getcontext
import json
import os
from pathlib import Path
import struct
import subprocess
import sys


def f32_from_bits(value):
    return D.from_float(struct.unpack('<f', struct.pack('<I', value))[0])


def read_matrix(path, expected_n, expected_nnz):
    entries = []
    with Path(path).open() as stream:
        if stream.readline().strip() != '%%MatrixMarket matrix coordinate real general':
            raise RuntimeError('unexpected Matrix Market banner')
        line = next(line for line in stream if not line.startswith('%'))
        rows, cols, count = map(int, line.split())
        for _ in range(count):
            row, col, value = stream.readline().split()
            entries.append((int(row) - 1, int(col) - 1, D(value)))
    if rows != expected_n or cols != expected_n or len(entries) != expected_nnz:
        raise RuntimeError('unexpected immutable stencil dimensions')
    return rows, entries


def backward_error(entries, rhs, solution):
    rows = len(rhs)
    residual = list(rhs)
    row_norm = [D(0)] * rows
    for row, col, value in entries:
        residual[row] -= value * solution[col]
        row_norm[row] += abs(value)
    inf = max(map(abs, residual), default=D(0))
    denominator = max(row_norm) * max(map(abs, solution)) + max(map(abs, rhs))
    return (inf / denominator if denominator else D(0)), inf


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('snapshot')
    parser.add_argument('--matrix', required=True)
    parser.add_argument('--expected-n', required=True, type=int)
    parser.add_argument('--expected-nnz', required=True, type=int)
    args = parser.parse_args()
    getcontext().prec = 80
    records = {}
    for line in Path(args.snapshot).read_text().splitlines():
        if line.startswith('FP32_') and '_INPUT ' in line:
            # The one authorized corrective snapshot predates the runner's
            # Windows-path escaping fix. Only its path field contains a
            # backslash, so normalize that legacy record without touching the
            # recorded numerical payload or launching another solver run.
            payload = line.split(' ', 1)[1]
            if '\\' in payload:
                payload = payload.replace('\\', '\\\\')
            records['input'] = json.loads(payload)
        elif line.startswith('FP32_') and '_RESULT ' in line:
            payload = line.split(' ', 1)[1]
            # Only the earlier one-shot FP32_4096 corrective snapshot has
            # accidental root closes.  Valid FP32_12000 records require the
            # ordinary CPU-object close at this boundary.
            if line.startswith('FP32_4096_RESULT ') and '}},"gpu":{' in payload:
                payload = payload.replace('}},"gpu":{', '},"gpu":{', 1)
                payload = payload.replace('}},"p_pattern_symmetric_difference":', '},"p_pattern_symmetric_difference":', 1)
            records['result'] = json.loads(payload)
        else:
            print(line)
    failures = []
    def check(condition, name):
        if not condition:
            failures.append(name)
            print('FAIL:', name, file=sys.stderr)
    check(set(records) == {'input', 'result'}, 'both machine-readable records present')
    if failures:
        return 1
    n, original_entries = read_matrix(args.matrix, args.expected_n, args.expected_nnz)
    payload = records['input']
    check(payload['rows'] == n and payload['nnz'] == len(original_entries), 'input dimensions/nnz')
    rounded_values = [f32_from_bits(v) for v in payload['matrix_value_bits']]
    check(len(rounded_values) == len(original_entries), 'FP32 matrix payload length')
    rounded_entries = [(row, col, value) for (row, col, _), value in zip(original_entries, rounded_values)]
    truth = [f32_from_bits(v) for v in payload['truth_bits']]
    rhs = [f32_from_bits(v) for v in payload['rhs_bits']]
    check(len(truth) == n and len(rhs) == n, 'truth/RHS payload lengths')
    expected_truth = [D((i % 7) - 3) / D(4) for i in range(n)]
    check(truth == expected_truth, 'periodic7 FP32 truth payload')
    # These stencil coefficients are dyadic; still verify bit-rounded payload
    # explicitly against the immutable source instead of assuming that fact.
    for index, ((_, _, original), rounded) in enumerate(zip(original_entries, rounded_values)):
        expected = f32_from_bits(struct.unpack('<I', struct.pack('<f', float(original)))[0])
        if rounded != expected:
            check(False, 'immutable source to FP32 matrix rounding at entry %d' % index)
            break
    original_rhs = [D(0)] * n
    rounded_rhs_real = [D(0)] * n
    for row, col, value in original_entries:
        original_rhs[row] += value * truth[col]
    for row, col, value in rounded_entries:
        rounded_rhs_real[row] += value * truth[col]
    # Stored b was formed in FP32, so compare it with a bounded real
    # reconstruction rather than accidentally treating Decimal80 as solver arithmetic.
    u = D(2) ** -24
    for got, expected in zip(rhs, rounded_rhs_real):
        check(abs(got - expected) <= D(128) * u * max(D(1), abs(expected)), 'rounded-A manufactured RHS consistency')
    target = D(10) * u
    outcomes = {}
    for backend in ('cpu', 'gpu'):
        item = records['result'][backend]
        solution = [f32_from_bits(v) for v in item['solution_bits']]
        check(len(solution) == n, backend + ' solution payload length')
        check(item['construction_status'] == 'success', backend + ' SPAI success')
        check(item['converged'] is True and item['status'] == 'success', backend + ' pipeline success')
        check(item['p_nnz'] > 0 and item['fits'] >= n, backend + ' SPAI diagnostics')
        check(item['outer_be_bits'] and len(item['outer_be_bits']) == item['outer_steps'] + 1, backend + ' outer-history consistency')
        check(len(item['inner']) == item['inner_attempts'] == item['outer_steps'], backend + ' inner-history consistency')
        check(all(inner['converged'] and inner['iterations'] > 0 for inner in item['inner']), backend + ' inner GMRES corrections')
        rounded_be, rounded_inf = backward_error(rounded_entries, rhs, solution)
        original_be, original_inf = backward_error(original_entries, original_rhs, solution)
        forward = (sum(((x-y)*(x-y) for x, y in zip(solution, truth)), D(0)).sqrt() /
                   sum(y*y for y in truth).sqrt())
        reported_be = f32_from_bits(item['final_backward_error_bits'])
        check(abs(reported_be - rounded_be) <= D(256) * u * max(D(1), rounded_be), backend + ' recorded FP32 BE matches Decimal80 reconstruction')
        check(reported_be <= target, backend + ' stored final FP32 backward-error target')
        check(rounded_be <= target, backend + ' Decimal80 rounded-system backward-error target')
        outcomes[backend] = {
            'rounded_system_backward_error': str(rounded_be),
            'original_input_backward_error': str(original_be),
            'rounded_system_residual_inf': str(rounded_inf),
            'original_input_residual_inf': str(original_inf),
            'forward_error': str(forward),
        }
    check(records['result']['p_pattern_symmetric_difference'] >= 0, 'CPU/GPU P-pattern diagnostic present')
    print(json.dumps({'decimal80_4096': outcomes,
                      'p_pattern_symmetric_difference': records['result']['p_pattern_symmetric_difference'],
                      'failures': len(failures)}, sort_keys=True))
    return 1 if failures else 0


if __name__ == '__main__':
    sys.exit(main())
