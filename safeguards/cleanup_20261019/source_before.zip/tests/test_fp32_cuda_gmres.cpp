#include "bspai/fp32_cuda_gmres.hpp"
#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
namespace {
void check(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }
void close(const std::vector<float>& got, const std::vector<float>& expected, float tolerance) {
    check(got.size() == expected.size(), "FP32 CUDA vector size");
    for (std::size_t i = 0; i < got.size(); ++i) check(std::fabs(got[i] - expected[i]) <= tolerance, "FP32 CUDA solution mismatch");
}
void finite_history(const std::vector<float>& history, std::size_t iterations, const char* message) {
    check(history.size() == iterations, message);
    for (float value : history) check(std::isfinite(value), message);
}
}
int main() {
    try {
        const bspai::Fp32CsrMatrix a = bspai::Fp32CsrMatrix::from_entries(3, 3, {
            {0,0,4.0f}, {0,1,-1.0f}, {1,0,-2.0f}, {1,1,5.0f}, {1,2,-1.0f}, {2,1,-1.0f}, {2,2,3.0f}});
        const bspai::Fp32CsrMatrix p = bspai::Fp32CsrMatrix::from_entries(3, 3, {{0,0,1.0f}, {1,1,1.0f}, {2,2,1.0f}});
        const std::vector<float> truth{0.25f, -0.5f, 0.75f};
        const std::vector<float> rhs = a.multiply(truth);
        // Retain the formerly failing, stricter smoke case as regression
        // evidence; the Experiment 2A contract tolerance remains 1e-4 below.
        bspai::Fp32GmresOptions strict_gmres; strict_gmres.tolerance = 2.0e-5f; strict_gmres.max_iterations = 3;
        const bspai::Fp32GmresResult gpu = bspai::fp32_cuda_left_preconditioned_gmres(a, p, rhs, strict_gmres);
        check(gpu.converged, "FP32 CUDA GMRES convergence");
        check(gpu.iterations > 0 && gpu.iterations <= 3, "FP32 CUDA GMRES iteration bound");
        check(std::isfinite(gpu.final_original_residual) && std::isfinite(gpu.final_preconditioned_relative), "FP32 CUDA GMRES diagnostics");
        close(gpu.solution, truth, 3.0e-4f);

        // A nonzero x0 forces a multi-step projected solve.  Every candidate
        // must be formed as x0 + V_k*y_k; starting a later candidate from the
        // prior candidate instead double-counts earlier Krylov corrections.
        bspai::Fp32GmresOptions gmres; gmres.tolerance = 1.0e-4f; gmres.max_iterations = 3;
        const std::vector<float> initial_guess{0.10f, -0.20f, 0.30f};
        const bspai::Fp32GmresResult cpu_from_x0 = bspai::fp32_left_preconditioned_gmres(
            a, p, rhs, gmres, initial_guess);
        const bspai::Fp32GmresResult gpu_from_x0 = bspai::fp32_cuda_left_preconditioned_gmres(
            a, p, rhs, gmres, initial_guess);
        check(cpu_from_x0.converged && gpu_from_x0.converged, "FP32 CUDA GMRES immutable-x0 regression convergence");
        check(cpu_from_x0.iterations > 1 && gpu_from_x0.iterations > 1, "FP32 CUDA GMRES immutable-x0 regression multi-iteration");
        check(cpu_from_x0.iterations == gpu_from_x0.iterations, "FP32 CUDA GMRES immutable-x0 regression iteration count");
        check(gpu_from_x0.final_preconditioned_relative <= gmres.tolerance, "FP32 CUDA GMRES immutable-x0 regression residual acceptance");
        finite_history(gpu_from_x0.hessenberg_residual_history, gpu_from_x0.iterations, "FP32 CUDA GMRES Hessenberg-history diagnostics");
        finite_history(gpu_from_x0.original_residual_history, gpu_from_x0.iterations, "FP32 CUDA GMRES original-residual-history diagnostics");
        finite_history(gpu_from_x0.preconditioned_relative_history, gpu_from_x0.iterations, "FP32 CUDA GMRES preconditioned-residual-history diagnostics");
        check(gpu_from_x0.preconditioned_relative_history.back() == gpu_from_x0.final_preconditioned_relative,
              "FP32 CUDA GMRES final recomputed residual history");
        close(gpu_from_x0.solution, cpu_from_x0.solution, 5.0e-4f);
        bspai::Fp32IrOptions ir; ir.gmres = strict_gmres; ir.max_outer_steps = 3;
        const bspai::Fp32IrResult refined = bspai::fp32_cuda_refine_with_preconditioner(a, p, rhs, ir);
        check(refined.converged, "FP32 CUDA iterative refinement convergence");
        const bspai::Fp32IrDiagnostics diagnostics = bspai::fp32_evaluate_ir_diagnostics(a, rhs, refined.solution);
        check(std::isfinite(diagnostics.normwise_backward_error) && diagnostics.normwise_backward_error <= bspai::fp32_ir_backward_tolerance(), "FP32 CUDA iterative refinement backward error");
        std::cout << std::setprecision(9)
                  << "FP32 CUDA nonzero-x0 estimate=" << gpu_from_x0.hessenberg_residual_history.back()
                  << " recomputed_relative=" << gpu_from_x0.final_preconditioned_relative << '\n'
                  << "FP32 CUDA GMRES tests passed\n";
        return 0;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
