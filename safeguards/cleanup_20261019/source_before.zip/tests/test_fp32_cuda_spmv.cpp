#include "bspai/fp32_cuda_spmv.hpp"
#include <cmath>
#include <iostream>
#include <stdexcept>
int main() {
    try {
        const bspai::Fp32CsrMatrix a = bspai::Fp32CsrMatrix::from_entries(3, 3,
            {{0,0,2.0f},{0,2,-1.0f},{1,1,3.0f},{2,0,4.0f}});
        const std::vector<float> x{.25f,-.5f,.75f};
        const std::vector<float> expected = a.multiply(x);
        bspai::Fp32CudaCsrSpmv gpu(a);
        const std::vector<float> got = gpu.multiply(x);
        for(std::size_t i=0;i<got.size();++i)
            if(std::fabs(got[i]-expected[i])>1e-6f) throw std::runtime_error("FP32 CUDA SpMV mismatch");
        std::cout << "FP32 CUDA SpMV passed\n"; return 0;
    } catch(const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
