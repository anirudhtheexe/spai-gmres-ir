# Experiment 1: FP64 CPU/GPU scalability study

**Date:** 11 October 2026. **Status:** completed as a bounded, resource-screened exploratory study; no crossover was observed because no tier beyond n=1024 passed the conservative host-memory safety gate.

## Frozen method and evidence

The study uses the existing uniform-binary64 CPU/CUDA Release implementation without source-algorithm changes: epsilon .3, beta 8, alpha `ceil(n/8)`, GMRES tolerance `1e-8`, inner cap `n`, outer cap 20, and outer backward-error target `10*2^-53`. CPU Release remains only partially admitted (unchanged MSVC CTest 1/4 wide-oracle limitation); CUDA Release is CTest 5/5. Consequently every result here is exploratory, not publication-ready.

New deterministic inputs are in `data/stage45b_fp64_scalability_v1/`, produced by `scripts/generate_stage45b_scalability.py`. They retain the v1 directional stencil weights, irregular-block rule, strict diagonal dominance, and `periodic7` manufactured RHS. Rectangular 2-D grids preserve the same four-neighbor stencil at n=2048/8192. Every input and generator has a manifest/hash; no reordering, regularization, or numerical-policy change occurred.

The sequential runner has an atomic lock, a 300-s per-configuration watchdog, four-hour global budget, external 5-s GPU state samples, no retry/outlier deletion, and a 30% free-memory margin. Primary timing is synchronized host `steady_clock` over the frozen public API call; observable allocation, transfers, host processing, synchronization, and cleanup are included. Decimal80 diagnostics and telemetry are outside the interval. Fixed-P comparisons use one stored CPU P per CPU/GPU pair; native pipelines are workload-dependent and not equal-work comparisons.

Raw campaign: `results/stage45b_fp64_scalability_20261011/`; conditional n=16384 preflights: `results/stage45b_fp64_scalability_stretch_preflight_20261011/`; machine-readable aggregation and five SVG plots: `results/stage45b_fp64_scalability_aggregation_20261011/SCALABILITY_SUMMARY.json`.

## Executed numerical/timing records

All 12 measured configurations at n=1024 completed: 3 warm-ups and 5 retained measurements/mode. The independently reassessed sidecars pass the exact fixed-P Decimal80 preconditioned residual criterion and the native pipeline Decimal80 backward-error criterion. Binary64 pack/text round-trip audits, fixed-P hashes, construction/QR telemetry, IR inner-work fields, manufactured-solution diagnostics, and GPU source-allocation telemetry are retained in JSONL.

Independent validation audited all 96 retained samples (60 measured) and all 12 raw SHA-256 sidecars. Fixed-P P hashes matched their on-disk canonical files for each CPU/GPU pair. Fixed-P Decimal80 relative residuals ranged from approximately `8.125e-9` to `8.766e-9`, below `1e-8`; native terminal backward errors ranged from `1.140e-16` to `1.581e-16`, below `10u`. The assessment validates terminal acceptance, not a complete high-dimensional construction-pattern/history equivalence proof. External five-second `nvidia-smi` sampling was outside the timed child process, but is a possible small measurement perturbation.

| Family | n / nnz | SPAI CPU/GPU ms, ratio | fixed-P GMRES CPU/GPU ms, ratio | pipeline CPU/GPU ms, ratio |
|---|---:|---:|---:|---:|
| stencil | 1024 / 4992 | 95.309 / 624.691, 0.153 | 18.813 / 65.392, 0.288 | 148.097 / 993.033, 0.149 |
| irregular | 1024 / 4951 | 45.814 / 365.986, 0.125 | 17.275 / 84.962, 0.203 | 93.895 / 609.998, 0.154 |

Ratios are CPU median/GPU median; below one means GPU slower. Full min/mean/standard-deviation/IQR records are in the aggregation. GPU SPAI source-owned peak allocation was 605,216 bytes (stencil) and 728,048 bytes (irregular), excluding vendor-internal allocations.

## Resource outcomes

At the n=2048 preflight, host free RAM was 1,579,565,056 bytes, hence the 70% allowed bound was 1,105,695,539 bytes. The conservative source-informed n=2048 native estimate was 1,611,675,696 bytes, so both synthetic families were classified `resource_abort/host_memory_margin` before launching. n=4096 and n=8192 were likewise aborted. The optional n=16384 preflight was explicitly recorded separately: its estimate was 103,087,816,752 host bytes and 103,090,683,968 device bytes versus 1,573,883,494 and 5,180,594,585 allowed bytes, respectively. No unsafe run was attempted.

This machine state also blocks the requested 8k--20k real-matrix execution. Research selected but did not download unnecessary archives: SuiteSparse Averous/epb1 (ID 288, real nonsymmetric 14,734², 95,053 nnz, no explicit zeros, condition estimate 5.94e3) and conditional Hamm/memplus (ID 543, real nonsymmetric 17,758², 99,147 numerical nnz; 27,003 explicit zeros in 126,150 records; condition estimate 1.294e5). Data-level diagonal/scaling checks were therefore not asserted. Their official pages are https://sparse.tamu.edu/Averous/epb1 and https://sparse.tamu.edu/Hamm/memplus; SuiteSparse collection licensing is CC-BY 4.0 and citation is Davis--Hu (2011), DOI 10.1145/2049662.2049663.

## Findings and limits

No CPU/GPU crossover was observed. This is not evidence that no crossover exists: no successful measurement beyond n=1024 was safe under the actual 16-GB host-RAM state, and all n>1024 entries are resource aborts rather than failed solves. GPU was slower in every executed n=1024 median comparison. No profiling, optimization, FP32/mixed precision, BSPAI, restart, new preconditioner, or tolerance change was performed.

For a future rerun, first restore substantially more host headroom, repeat preflight unchanged, acquire only `epb1` first after byte-level eligibility checks, and retain all abort/failure records. Do not compare native pipeline speedups as equal-work performance or claim scalable behavior from this bounded result.
