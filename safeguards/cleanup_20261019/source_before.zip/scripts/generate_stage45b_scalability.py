"""Generate Stage 4.5B FP64 scalability inputs without altering v1 inputs.

This is deliberately a separate generator version.  The Stage 4.5A v1 files
remain byte-for-byte reproducible; a fresh output directory is required here.
The numerical stencil weights, irregular-block rules, diagonal dominance, and
periodic7 manufactured-solution rule are the same as stage45a-dyadic-v1.
"""
import argparse
import hashlib
import json
from pathlib import Path

VERSION = "stage45b-fp64-scalability-v2"


def cases(include_stretch=True, include_12000=False, include_arrowhead_chain_12000=False):
    # 2048 and 8192 cannot be square grids.  Their row-major rectangular grids
    # preserve the four-neighbour stencil and its exact directional weights.
    stencil = [(32, 32), (32, 64), (64, 64), (64, 128), (128, 128)]
    # 100 x 120 is an exact rectangular 12,000-vertex grid.  It retains the
    # same row-major four-neighbour stencil, including its directional weights.
    if include_12000:
        stencil.append((100, 120))
    result = []
    for rows, cols in stencil:
        n = rows * cols
        if n == 16384 and not include_stretch:
            continue
        result.append({"id": "stencil_%d" % n, "family": "stencil", "n": n,
                       "grid_rows": rows, "grid_cols": cols})
    irregular_sizes = [1024, 2048, 4096, 8192, 16384]
    if include_12000:
        irregular_sizes.append(12000)
    for n in irregular_sizes:
        if n == 16384 and not include_stretch:
            continue
        result.append({"id": "irregular_%d" % n, "family": "irregular", "n": n})
    # Experiment 2A stress input: one controlled long hub row plus a directed
    # nearest-neighbour chain.  It is opt-in so retained FP64 v2 inputs stay
    # byte-for-byte unchanged.
    if include_arrowhead_chain_12000:
        # Preserve the Stage 4.5A arrowhead pilot's degree-64 structure.
        # This has 36,124 stored entries and a maximum row length of 65.
        result.append({"id": "arrowhead_chain_12000", "family": "arrowhead_chain",
                       "n": 12000, "long_row_degree": 64})
    return result


def rows_for(case):
    n = case["n"]
    rows = [{} for _ in range(n)]
    if case["family"] == "stencil":
        height, width = case["grid_rows"], case["grid_cols"]
        if height * width != n:
            raise ValueError("invalid rectangular stencil dimensions")
        for i, row in enumerate(rows):
            y, x = divmod(i, width)
            for valid, j, weight in ((x > 0, i - 1, .25),
                                     (x + 1 < width, i + 1, .125),
                                     (y > 0, i - width, .5),
                                     (y + 1 < height, i + width, .0625)):
                if valid:
                    row[j] = -weight
    elif case["family"] == "irregular":
        start, block = 0, 0
        while start < n:
            width = min((3, 5, 8, 13)[block % 4], n - start)
            for local in range(width):
                i = start + local
                for shift in range(1, 1 + min(width - 1, 1 + i % 5)):
                    j = start + (local + shift) % width
                    rows[i][j] = -((1 + (i + shift) % 4) / 16)
                j = (i + width + 1) % n
                if j != i:
                    rows[i][j] = -.0625
            start += width
            block += 1
    elif case["family"] == "arrowhead_chain":
        degree = case["long_row_degree"]
        if not 1 <= degree < n:
            raise ValueError("invalid arrowhead-chain long-row degree")
        for k in range(degree):
            j = 1 + (k * (n - 1)) // degree
            rows[0][j] = -(1 + k % 4) / 32
            rows[j][0] = -(1 + k % 3) / 16
        for i in range(1, n):
            if i > 1:
                rows[i][i - 1] = -.125
            if i + 1 < n:
                rows[i][i + 1] = -.0625
    else:
        raise ValueError("unknown family")
    for i, row in enumerate(rows):
        row[i] = sum(abs(v) for v in row.values()) + .5
    return rows


def matrix_bytes(case):
    rows = rows_for(case)
    lines = ["%%MatrixMarket matrix coordinate real general",
             "%% Generator %s; no reordering or regularization" % VERSION,
             "%d %d %d" % (case["n"], case["n"], sum(map(len, rows)))]
    lines.extend("%d %d %.17g" % (i + 1, j + 1, value)
                 for i, row in enumerate(rows) for j, value in sorted(row.items()))
    return ("\n".join(lines) + "\n").encode("ascii")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True,
                        help="new directory only; never overwrites a retained input set")
    parser.add_argument("--exclude-stretch", action="store_true",
                        help="omit conditional 16384 cases at generation time")
    parser.add_argument("--include-12000", action="store_true",
                        help="include the two requested 12,000-row cases")
    parser.add_argument("--include-arrowhead-chain-12000", action="store_true",
                        help="add the opt-in deterministic Experiment 2A arrowhead-chain input")
    parser.add_argument("--only-n", type=int,
                        help="write only one requested dimension from the selected case set")
    args = parser.parse_args()
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=False)
    source_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    notes = {
        "stencil": "row-major rectangular 2-D grid, west/east/north/south weights -1/4,-1/8,-1/2,-1/16; 1024 remains 32x32",
        "irregular": "same v1 blocks 3,5,8,13; same directed shifts and cross-edge rule",
        "arrowhead_chain": "Stage45A degree-64 hub: supports 1+floor(k*(n-1)/64), weights -(1+k%4)/32; reverse -(1+k%3)/16; directed chain lower -1/8, upper -1/16; expected nnz 36124 and max row 65 at n=12000",
        "diagonal": "each row diagonal equals sum(abs(offdiagonal))+1/2; strictly row diagonally dominant",
        "rhs": "periodic7: x_i=(i%7-3)/4; b is binary64 CSR A*x",
    }
    manifest = {"schema_version": 1, "generator": VERSION,
                "generator_sha256": source_hash, "untimed": True,
                "cases": [], "formula_notes": notes}
    selected_cases = cases(not args.exclude_stretch, args.include_12000,
                           args.include_arrowhead_chain_12000)
    if args.only_n is not None:
        selected_cases = [case for case in selected_cases if case["n"] == args.only_n]
        if not selected_cases:
            raise ValueError("--only-n selected no generated cases")
    for case in selected_cases:
        raw = matrix_bytes(case)
        name = case["id"] + ".mtx"
        (output / name).write_bytes(raw)
        provenance = dict(case, source_id="controlled/" + case["id"], source_url=None,
                          license_url=None, raw_path=name,
                          raw_sha256=hashlib.sha256(raw).hexdigest(), raw_bytes=len(raw),
                          generator=VERSION, generator_sha256=source_hash,
                          generator_method=notes[case["family"]],
                          diagonal_method=notes["diagonal"], rhs_method="periodic7",
                          options={"epsilon": .3, "alpha": (case["n"] + 7) // 8,
                                   "beta": 8, "tau": 1e-8, "innercap": case["n"],
                                   "outercap": 20, "backward_tolerance": 10 * 2 ** -53})
        provenance_name = case["id"] + ".provenance.json"
        (output / provenance_name).write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8", newline="\n")
        manifest["cases"].append(dict(provenance, provenance_path=provenance_name))
    (output / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"generator": VERSION, "cases": len(manifest["cases"]), "manifest": str(output / "MANIFEST.json")}))


if __name__ == "__main__":
    main()
