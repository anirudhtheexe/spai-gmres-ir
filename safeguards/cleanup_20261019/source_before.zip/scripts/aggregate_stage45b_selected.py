"""Create the final selected Stage 4.5B exploratory benchmark aggregation.

This is deliberately a reporting-only tool.  It reads only the independently
reassessed summary and the additive assessment sidecars: it never reads or
rewrites raw JSONL samples, runs no executables, and creates a new output
directory rather than modifying a retained campaign directory.

The selection is intentionally explicit.  Results from the interrupted first
campaign are retained for audit, but its add32 and all synthetic configurations
are excluded from the final aggregate because that campaign was contaminated by
concurrent execution.  The clean continuation supplies add32 and the four
synthetic cases.  Eight complete application-matrix sets are selected from the
original campaign.
"""

import argparse
import json
import math
from pathlib import Path
from xml.sax.saxutils import escape


MODES = (
    "cpu_spai", "gpu_spai", "cpu_gmres_fixed", "gpu_gmres_fixed",
    "cpu_pipeline", "gpu_pipeline",
)
ORIGINAL_CASES = (
    "cage5", "gre_115", "pores_3", "steam1", "saylr1", "sherman4",
    "orsreg_1", "sherman5",
)
CONTINUATION_CASES = (
    "add32", "stencil_256", "stencil_1024", "irregular_256",
    "irregular_1024",
)


def load_json(path):
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def by_key(summary):
    result = {}
    for entry in summary:
        key = (entry["case"], entry["mode"])
        if key in result:
            raise ValueError("duplicate reassessed summary entry: %s/%s" % key)
        result[key] = entry
    return result


def status_counts(sidecar, mode):
    """Return counts/statuses from sidecar records, without opening raw JSONL."""
    records = sidecar.get("records", [])
    samples = [r for r in records if r.get("ordinal") is not None]
    measured = [r for r in samples if r.get("phase") == "measured"]
    warmups = [r for r in samples if r.get("phase") == "warmup"]
    status = {}
    for record in samples:
        label = str(record.get("status"))
        status[label] = status.get(label, 0) + 1

    def independent_accepts(record):
        if not record.get("converged"):
            return False
        if mode in ("cpu_spai", "gpu_spai"):
            return record.get("status") == "success"
        if mode in ("cpu_gmres_fixed", "gpu_gmres_fixed"):
            return record.get("independent_decimal80_gmres", {}).get(
                "accepts_frozen_gmres_tolerance") is True
        return record.get("independent_decimal80", {}).get(
            "accepts_frozen_backward_error") is True

    return {
        "sidecar_record_count": len(records),
        "sample_count": len(samples),
        "warmup_count": len(warmups),
        "measured_count": len(measured),
        "converged_measured_count": sum(bool(r.get("converged")) for r in measured),
        "independently_accepted_measured_count": sum(
            independent_accepts(r) for r in measured),
        "status_counts_all_samples": status,
    }


def pair_speedup(items, case, cpu_mode, gpu_mode):
    cpu = items[(case, cpu_mode)]["timing"]
    gpu = items[(case, gpu_mode)]["timing"]
    if not cpu.get("completed_trials") or not gpu.get("completed_trials"):
        return None
    return cpu["median_ms"] / gpu["median_ms"]


def svg_document(title, rows, value_label, filename):
    """Write a static two-series horizontal bar chart with no plotting dependency."""
    width, left, right, top, row_height = 1500, 265, 230, 100, 48
    height = top + row_height * len(rows) + 90
    maximum = max((max(r["cpu"], r["gpu"]) for r in rows), default=1.0) or 1.0
    plot_width = width - left - right
    pieces = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">' % (width, height, width, height),
        '<style>text{font-family:Arial,sans-serif;fill:#111}.title{font-size:22px;font-weight:bold}.axis{font-size:12px;fill:#444}.label{font-size:13px}.value{font-size:12px}.cpu{fill:#356ae6}.gpu{fill:#e87125}.grid{stroke:#d5d5d5;stroke-width:1}</style>',
        '<text class="title" x="20" y="35">%s</text>' % escape(title),
        '<rect class="cpu" x="%d" y="55" width="18" height="14"/><text class="axis" x="%d" y="67">CPU</text>' % (left, left + 24),
        '<rect class="gpu" x="%d" y="55" width="18" height="14"/><text class="axis" x="%d" y="67">GPU</text>' % (left + 85, left + 109),
    ]
    for tick in range(6):
        fraction = tick / 5.0
        x = left + plot_width * fraction
        value = maximum * fraction
        pieces.append('<line class="grid" x1="%.2f" y1="%d" x2="%.2f" y2="%d"/>' % (x, top - 5, x, height - 50))
        pieces.append('<text class="axis" x="%.2f" y="%d" text-anchor="middle">%.4g</text>' % (x, height - 30, value))
    for index, row in enumerate(rows):
        y = top + row_height * index
        label = "%s (n=%s)" % (row["case"], row["rows"])
        pieces.append('<text class="label" x="10" y="%d">%s</text>' % (y + 22, escape(label)))
        for offset, backend, value in ((0, "cpu", row["cpu"]), (18, "gpu", row["gpu"])):
            bar = plot_width * value / maximum
            pieces.append('<rect class="%s" x="%d" y="%d" width="%.3f" height="14"/>' % (backend, left, y + offset, bar))
            pieces.append('<text class="value" x="%.3f" y="%d">%.6g %s</text>' % (left + bar + 5, y + offset + 12, value, escape(value_label)))
    pieces.append('</svg>')
    filename.write_text("\n".join(pieces), encoding="utf-8")


def speedup_svg(rows, filename):
    width, height, left, right, top, bottom = 1500, 720, 115, 100, 85, 105
    values = [r["speedup"] for r in rows if r["speedup"] is not None]
    maximum = max([1.0] + values) * 1.08
    plot_width, plot_height = width - left - right, height - top - bottom
    pieces = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d">' % (width, height, width, height),
        '<style>text{font-family:Arial,sans-serif;fill:#111}.title{font-size:22px;font-weight:bold}.axis{font-size:12px;fill:#444}.label{font-size:12px}.point{fill:#e87125}.baseline{stroke:#444;stroke-width:1.5}.grid{stroke:#d5d5d5;stroke-width:1}</style>',
        '<text class="title" x="20" y="35">Full-pipeline speedup: CPU median / GPU median</text>',
        '<text class="axis" x="20" y="58">Values below 1 indicate a slower GPU pipeline; no failed solves are included.</text>',
    ]
    for tick in range(6):
        val = maximum * tick / 5.0
        y = top + plot_height * (1.0 - val / maximum)
        pieces.append('<line class="grid" x1="%d" y1="%.2f" x2="%d" y2="%.2f"/>' % (left, y, width - right, y))
        pieces.append('<text class="axis" x="%d" y="%.2f" text-anchor="end">%.3g</text>' % (left - 8, y + 4, val))
    baseline_y = top + plot_height * (1.0 - 1.0 / maximum)
    pieces.append('<line class="baseline" x1="%d" y1="%.2f" x2="%d" y2="%.2f"/>' % (left, baseline_y, width - right, baseline_y))
    for index, row in enumerate(rows):
        x = left + plot_width * (index + 0.5) / len(rows)
        y = top + plot_height * (1.0 - row["speedup"] / maximum)
        pieces.append('<circle class="point" cx="%.2f" cy="%.2f" r="5"/>' % (x, y))
        pieces.append('<text class="label" transform="translate(%.2f,%d) rotate(45)" text-anchor="start">%s n=%s</text>' % (x - 4, height - bottom + 18, escape(row["case"]), row["rows"]))
    pieces.append('</svg>')
    filename.write_text("\n".join(pieces), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", default="results/stage45b_exploratory_20261011")
    parser.add_argument("--continuation", default="results/stage45b_add32_synthetic_continuation_20261011")
    parser.add_argument("--output-dir", default="results/stage45b_selected_aggregation_20261011")
    args = parser.parse_args()

    original = Path(args.original).resolve()
    continuation = Path(args.continuation).resolve()
    output = Path(args.output_dir).resolve()
    if output.exists():
        raise SystemExit("refusing to overwrite existing output directory: %s" % output)
    output.mkdir(parents=True)

    sources = (("original", original, ORIGINAL_CASES), ("continuation", continuation, CONTINUATION_CASES))
    selected = {}
    for source_name, directory, cases in sources:
        summary_file = directory / "SUMMARY_REASSESSED.json"
        if not summary_file.is_file():
            raise FileNotFoundError(summary_file)
        reassessed = by_key(load_json(summary_file))
        for case in cases:
            for mode in MODES:
                entry = reassessed.get((case, mode))
                if entry is None:
                    raise ValueError("incomplete selected configuration: %s/%s from %s" % (case, mode, directory))
                sidecar_name = entry.get("assessment_artifact") or (case + "_" + mode + ".assessment.json")
                sidecar_path = directory / sidecar_name
                if not sidecar_path.is_file():
                    raise FileNotFoundError(sidecar_path)
                sidecar = load_json(sidecar_path)
                raw_name = entry.get("raw_artifact") or sidecar.get("artifact")
                if not raw_name:
                    raise ValueError("sidecar lacks raw artifact link: %s" % sidecar_path)
                selected[(case, mode)] = {
                    "case": case,
                    "mode": mode,
                    "source_campaign": source_name,
                    "source_directory": str(directory),
                    "raw_artifact": raw_name,
                    "raw_sha256": sidecar.get("raw_sha256"),
                    "assessment_artifact": sidecar_path.name,
                    "timing": entry,
                    "observation_counts": status_counts(sidecar, mode),
                }

    for case in ORIGINAL_CASES + CONTINUATION_CASES:
        for cpu_mode, gpu_mode, label in (
            ("cpu_spai", "gpu_spai", "spai_construction"),
            ("cpu_gmres_fixed", "gpu_gmres_fixed", "fixed_p_gmres"),
            ("cpu_pipeline", "gpu_pipeline", "full_pipeline"),
        ):
            selected[(case, cpu_mode)]["cpu_over_gpu_median_speedup"] = pair_speedup(selected, case, cpu_mode, gpu_mode)
            selected[(case, gpu_mode)]["paired_cpu_over_gpu_median_speedup"] = selected[(case, cpu_mode)]["cpu_over_gpu_median_speedup"]

    ordered = [selected[(case, mode)] for case in ORIGINAL_CASES + CONTINUATION_CASES for mode in MODES]
    output_data = {
        "schema_version": 1,
        "title": "Stage 4.5B selected exploratory benchmark aggregation",
        "selection_policy": {
            "original_cases": list(ORIGINAL_CASES),
            "continuation_cases": list(CONTINUATION_CASES),
            "exclusions": [
                "All original-campaign add32 artifacts are excluded; continuation supplies the complete six-mode add32 set.",
                "All original-campaign synthetic artifacts are excluded; continuation supplies complete six-mode sets for stencil_256, stencil_1024, irregular_256, and irregular_1024.",
                "No unassessed runner SUMMARY.json is consumed; statistics are copied only from SUMMARY_REASSESSED.json and acceptance/status evidence from *.assessment.json sidecars.",
            ],
            "timing_scope": "Exploratory host-wall-clock data. Timing samples remain in linked immutable raw JSONL artifacts; diagnostics were outside timed calls.",
        },
        "records": ordered,
    }
    (output / "SELECTED_SUMMARY.json").write_text(json.dumps(output_data, indent=2), encoding="utf-8")

    cases = ORIGINAL_CASES + CONTINUATION_CASES
    def chart_rows(cpu_mode, gpu_mode):
        rows = []
        for case in cases:
            cpu, gpu = selected[(case, cpu_mode)]["timing"], selected[(case, gpu_mode)]["timing"]
            if not cpu.get("completed_trials") or not gpu.get("completed_trials"):
                continue
            rows.append({"case": case, "rows": cpu["rows"], "cpu": cpu["median_ms"], "gpu": gpu["median_ms"]})
        return rows

    svg_document("CPU vs GPU SPAI construction median elapsed time", chart_rows("cpu_spai", "gpu_spai"), "ms", output / "spai_construction_selected.svg")
    svg_document("CPU vs GPU fixed-P GMRES median elapsed time", chart_rows("cpu_gmres_fixed", "gpu_gmres_fixed"), "ms", output / "fixed_p_gmres_selected.svg")
    svg_document("CPU vs GPU native full-pipeline median elapsed time", chart_rows("cpu_pipeline", "gpu_pipeline"), "ms", output / "full_pipeline_selected.svg")
    speedups = []
    for case in cases:
        cpu = selected[(case, "cpu_pipeline")]
        speed = cpu.get("cpu_over_gpu_median_speedup")
        if speed is not None:
            speedups.append({"case": case, "rows": cpu["timing"]["rows"], "speedup": speed})
    speedup_svg(speedups, output / "full_pipeline_speedup_selected.svg")
    print("selected_records=%d; selected_cases=%d; output=%s" % (len(ordered), len(cases), output))


if __name__ == "__main__":
    main()
