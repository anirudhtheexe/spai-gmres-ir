"""Strictly serial post-optimization FP32 GPU-SPAI evidence launcher.

Runs only the existing FP32 ``gpu_spai`` and native ``gpu_pipeline`` public
API modes for the four frozen Experiment 2A matrices.  A solver child is
always reaped before its durable JSONL artifact is handed to the snapshot-only
Decimal80 checker.  The shared root lock prevents another Stage 4.5B or
Experiment 2A runner from overlapping it.
"""
import argparse
import atexit
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from benchmark_experiment_lock import ExperimentLock


CASES = (
    ("stencil_8192", "data/stage45b_fp64_scalability_v1/stencil_8192.mtx"),
    ("irregular_8192", "data/stage45b_fp64_scalability_v1/irregular_8192.mtx"),
    ("stencil_12000", "data/stage45b_fp64_12000_v1/stencil_12000.mtx"),
    ("irregular_12000", "data/stage45b_fp64_12000_v1/irregular_12000.mtx"),
)
MODES = ("gpu_spai", "gpu_pipeline")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_dimension(path):
    with Path(path).open(encoding="utf-8-sig") as source:
        for line in source:
            if line and not line.startswith("%"):
                n, m, _ = map(int, line.split())
                if not n or n != m:
                    raise ValueError("expected nonempty square Matrix Market input: " + str(path))
                return n
    raise ValueError("missing Matrix Market dimensions: " + str(path))


def write_jsonl_new(path, records):
    """Create a durable artifact once; retained evidence is never overwritten."""
    with Path(path).open("x", encoding="utf-8", newline="\n") as out:
        for record in records:
            out.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
        out.flush()
        os.fsync(out.fileno())


def parse_records(stdout):
    records, ignored = [], []
    for line in stdout.splitlines():
        if not line.startswith("{"):
            ignored.append(line)
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            ignored.append(line)
    return records, ignored


def run_one(command, timeout, lock, case, mode):
    """Run precisely one child synchronously; no sampler or helper overlaps it."""
    started = time.time()
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    lock.update(active_case=case, active_mode=mode, child_pid=child.pid,
                child_started_unix=started, last_exit=None)
    try:
        stdout, stderr = child.communicate(timeout=timeout)
        outcome = {"status": "completed" if child.returncode == 0 else "process_exit_nonzero",
                   "pid": child.pid, "started_unix": started, "completed_unix": time.time(),
                   "returncode": child.returncode, "watchdog_timeout": False}
        return child.returncode, stdout, stderr, outcome
    except subprocess.TimeoutExpired:
        child.kill()
        stdout, stderr = child.communicate()
        outcome = {"status": "watchdog_timeout", "pid": child.pid, "started_unix": started,
                   "completed_unix": time.time(), "returncode": child.returncode,
                   "watchdog_timeout": True}
        return None, stdout or "", stderr or "", outcome
    finally:
        lock.update(child_pid=None, child_started_unix=None, last_exit=outcome)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fp32-runner", required=True)
    parser.add_argument("--precision", choices=("fp32", "fp64"), default="fp32")
    parser.add_argument("--checker", required=True,
                        help="snapshot-only Decimal80 checker accepting --artifact --matrix --precision --mode")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--root", default=".")
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    parser.add_argument("--cases", nargs="+", choices=[case[0] for case in CASES])
    args = parser.parse_args()
    if args.timeout_seconds <= 0:
        parser.error("--timeout-seconds must be positive")

    root = Path(args.root).resolve()
    runner, checker = Path(args.fp32_runner).resolve(), Path(args.checker).resolve()
    if not runner.is_file() or not checker.is_file():
        raise SystemExit("runner and checker must both exist before acquisition")
    output = (root / args.output_dir).resolve()
    if output.exists():
        raise SystemExit("refusing to overwrite evidence directory: " + str(output))
    output.mkdir(parents=True)
    selected = set(args.cases or [case[0] for case in CASES])

    lock = ExperimentLock(root / "results", Path(__file__).resolve(), output).acquire()
    completion = "interrupted_unclassified"
    atexit.register(lambda: lock.release(completion))
    manifest = {
        "schema_version": 1,
        "experiment": "Experiment 2A post-optimization GPU-SPAI memory evidence",
        "started_unix": time.time(),
        "sequential": True,
        "exclusive_lock": str(lock.path),
        "warmups": 3,
        "measured_trials": 3,
        "modes": list(MODES),
        "precision_contract": {"precision": args.precision, "epsilon": .3, "beta": 8,
                               "gmres_tolerance": "1e-4" if args.precision == "fp32" else "1e-8",
                               "outer_be": "10*2^-24" if args.precision == "fp32" else "10*2^-53"},
        "runner": str(runner), "runner_sha256": sha256(runner),
        "checker": str(checker), "checker_sha256": sha256(checker),
        "notes": "One child at a time. Each raw harness JSONL is durable before a separate snapshot-only Decimal80 checker child is started. No artifact is overwritten.",
    }
    (output / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    progress = output / "PROGRESS.jsonl"

    def log(event, **fields):
        with progress.open("a", encoding="utf-8", newline="\n") as out:
            out.write(json.dumps(dict(event=event, unix=time.time(), **fields), separators=(",", ":")) + "\n")
            out.flush()
            os.fsync(out.fileno())

    summary = []
    for case, relative_matrix in CASES:
        if case not in selected:
            continue
        matrix = (root / relative_matrix).resolve()
        n = load_dimension(matrix)
        common = ["--matrix", str(matrix), "--rhs", "periodic7", "--epsilon", "0.3",
                  "--alpha", str((n + 7) // 8), "--beta", "8", "--innercap", str(n),
                  "--outercap", "20", "--warmups", "3", "--trials", "3"]
        for mode in MODES:
            command = [str(runner), "--mode", mode, *common]
            log("configuration_started", case=case, precision=args.precision, mode=mode)
            rc, stdout, stderr, process = run_one(command, args.timeout_seconds, lock, case, mode)
            records, ignored = parse_records(stdout)
            artifact = output / (case + "_" + args.precision + "_" + mode + ".jsonl")
            wrapper = {"event": "artifact_manifest", "case": case, "precision": args.precision, "mode": mode,
                       "matrix": str(matrix), "matrix_sha256": sha256(matrix), "command": command,
                       "returncode": rc, "stderr": stderr, "stdout_ignored": ignored, "process": process}
            write_jsonl_new(artifact, [wrapper, *records] if records else
                            [wrapper, {"event": "process_termination_unclassified", "process": process}])

            # This child consumes the saved snapshot only and starts only after
            # the solver child is reaped and the raw JSONL write has completed.
            check = [sys.executable, str(checker), "--artifact", str(artifact), "--matrix", str(matrix),
                     "--precision", args.precision, "--mode", mode]
            log("snapshot_check_started", case=case, precision=args.precision, mode=mode)
            check_rc, check_out, check_err, check_process = run_one(
                check, args.timeout_seconds, lock, case, "snapshot_check:" + mode)
            check_records, check_ignored = parse_records(check_out)
            check_path = output / (case + "_" + args.precision + "_" + mode + "_decimal80.jsonl")
            write_jsonl_new(check_path, [{"event": "checker_manifest", "command": check,
                                          "returncode": check_rc, "stderr": check_err,
                                          "stdout_ignored": check_ignored, "process": check_process},
                                         *check_records])
            accepted = check_rc == 0
            summary.append({"case": case, "precision": args.precision, "mode": mode,
                            "raw_artifact": artifact.name, "decimal80_artifact": check_path.name,
                            "solver_returncode": rc, "checker_returncode": check_rc, "accepted": accepted})
            log("configuration_finished", case=case, precision=args.precision, mode=mode,
                solver_returncode=rc, checker_returncode=check_rc)
            if accepted:
                lock.update(last_successful_configuration={"case": case, "precision": args.precision,
                                                           "mode": mode, "completed_unix": time.time()})

    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    completion = "completed"
    print(json.dumps({"output": str(output), "summary_records": len(summary)}))


if __name__ == "__main__":
    main()
