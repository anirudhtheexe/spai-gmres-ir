"""Sequential runner for the controlled FP64 scaling experiment.

The runner never modifies a solver.  It creates a new evidence directory,
uses one child process at a time, retains all observations, and enforces the
per-configuration watchdog.  It deliberately performs *no* Windows host-RAM,
page-file, or host-allocation preflight/monitoring: Windows owns those
decisions.  GPU launches alone receive a no-margin dedicated-VRAM screen based
on source allocations that are known before the corresponding production call.
Dynamic SPAI and cuSPARSE allocations remain observable only at execution and
are retained as CUDA failures if they cannot be satisfied.
"""
import argparse
import atexit
import decimal
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import threading
import time

import run_stage45b_exploratory as common
from benchmark_experiment_lock import ExperimentLock

MODES = ("cpu_spai", "gpu_spai", "cpu_gmres_fixed", "gpu_gmres_fixed",
         "cpu_pipeline", "gpu_pipeline")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bits(value):
    return struct.unpack("<Q", struct.pack("<d", float(value)))[0]


def binary64_audit(values):
    packed = b"".join(struct.pack("<d", float(x)) for x in values)
    return {"count": len(values), "little_endian_sha256": hashlib.sha256(packed).hexdigest(),
            "exact_pack_unpack": all(bits(x) == bits(struct.unpack("<d", struct.pack("<d", float(x)))[0]) for x in values),
            "max_digits10_text_roundtrip": all(bits(x) == bits(float(format(float(x), ".17g"))) for x in values)}


def gpu_snapshot():
    query = "timestamp,pstate,temperature.gpu,clocks.current.graphics,clocks.current.memory,power.draw,power.limit,memory.free,memory.total"
    try:
        p = subprocess.run(["nvidia-smi", "--query-gpu=" + query, "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=15, check=False)
        rows = [x.strip() for x in p.stdout.splitlines() if x.strip()]
        return {"query": query, "returncode": p.returncode, "rows": rows,
                "stderr": p.stderr.strip()}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"query": query, "error": str(exc)}


def gpu_free_bytes(snapshot):
    # CSV units are MiB under nvidia-smi's nounits mode; unavailable fields may
    # be [N/A], in which case preflight fails closed for GPU configurations.
    try:
        fields = [x.strip() for x in snapshot["rows"][0].split(",")]
        return int(float(fields[-2]) * 1024 * 1024)
    except (KeyError, IndexError, ValueError):
        return None


def csr_device_bytes(n, nnz):
    """The exact CSR storage cuda_gmres.cu allocates for one matrix."""
    return 8 * (n + 1) + 16 * nnz


def gpu_spai_initial_bytes(n, nnz):
    """Known initial cuda_construct_spai allocations, excluding dynamic slots.

    cuda_spai.cu allocates offsets/indices/values/D/B/status before adaptive
    patterns are known.  Eight slots initially allocate diagnostics (3 doubles)
    and infos (3 ints).  Reduced QR/candidate/output buffers are deliberately
    excluded: their actual sizes depend on the adaptive construction and must
    be handled by CUDA at run time rather than guessed as dense staging.
    """
    return (8 * (n + 1) + 8 * nnz + 8 * nnz + 8 * n + 8 * nnz + 4 * n
            + min(n, 8) * (3 * 8 + 3 * 4))


def gpu_fixed_gmres_known_bytes(n, a_nnz, p_nnz):
    """Known cuda_gmres.cu allocations for cap=n, excluding queried workspace.

    Run constructs nine n-vectors, an n*(n+1) basis and n*n snapshots before
    Arnoldi, two scalar buffers, and exact CSR A/P payloads.  cuSPARSE SpMV
    workspaces are queried and allocated inside Matrix after launch; they are
    not safely knowable from Python and are not substituted with an estimate.
    """
    vectors = 9 * n * 8
    basis_and_snapshots = (n * (n + 1) + n * n) * 8
    scalar_buffers = 4 + 8
    return vectors + basis_and_snapshots + scalar_buffers + csr_device_bytes(n, a_nnz) + csr_device_bytes(n, p_nnz)


def gpu_preflight(mode, n, nnz, p_nnz=None):
    """Reject only a GPU mode whose source-known initial allocations exceed VRAM.

    There is intentionally no host-memory probe, safety margin, or dense
    worst-case estimate.  A pass is not an OOM guarantee because vendor and
    adaptive allocations occur during the production call; those outcomes are
    retained by the normal watchdog/process-failure records.
    """
    gpu = gpu_snapshot()
    available = gpu_free_bytes(gpu)
    result = {"schema_version": 2, "mode": mode, "gpu": gpu,
              "host_memory_policy": "not probed or gated",
              "accepted": False, "reason": None}
    if available is None:
        result["reason"] = "gpu_vram_probe_unavailable"
        return result
    if mode == "gpu_spai":
        required = gpu_spai_initial_bytes(n, nnz)
        basis = "cuda_spai_initial_source_allocations"
    elif mode == "gpu_pipeline":
        required = gpu_spai_initial_bytes(n, nnz)
        basis = "cuda_spai_initial_source_allocations_before_adaptive_P_and_GMRES"
    elif mode == "gpu_gmres_fixed":
        if p_nnz is None:
            result["reason"] = "fixed_p_nnz_unavailable"
            return result
        required = gpu_fixed_gmres_known_bytes(n, nnz, p_nnz)
        basis = "cuda_gmres_known_upfront_source_allocations_excluding_queried_cusparse_workspace"
    else:
        raise ValueError("GPU preflight requested for non-GPU mode: " + mode)
    result.update(available_dedicated_vram_bytes=available,
                  required_known_source_allocation_bytes=required,
                  requirement_basis=basis,
                  safety_margin_bytes=0)
    if required > available:
        result["reason"] = "gpu_vram_known_allocation_exceeds_free"
    else:
        result["accepted"] = True
        result["reason"] = "accepted_known_allocation_only"
    return result


class GpuSampler:
    # This telemetry is deliberately external to the benchmark executable and
    # is never included in its timing boundary.
    def __init__(self, interval): self.interval, self.samples, self.stop = interval, [], threading.Event(); self.thread = None
    def _run(self):
        while not self.stop.is_set():
            self.samples.append({"unix": time.time(), "snapshot": gpu_snapshot()})
            self.stop.wait(self.interval)
    def __enter__(self):
        self.thread = threading.Thread(target=self._run, daemon=True); self.thread.start(); return self
    def __exit__(self, *_):
        self.stop.set(); self.thread.join(timeout=self.interval + 5)


def run_with_telemetry(command, timeout, sample_interval, lock, case, mode):
    with GpuSampler(sample_interval) as sampler:
        started = time.time()
        try:
            p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            lock.update(active_case=case, active_mode=mode, child_pid=p.pid,
                        child_started_unix=started, last_exit=None)
            stdout, stderr = p.communicate(timeout=timeout)
            outcome = {"status": "completed" if p.returncode == 0 else "process_exit_nonzero",
                       "pid": p.pid, "started_unix": started, "completed_unix": time.time(),
                       "returncode": p.returncode, "watchdog_timeout": False}
            lock.update(child_pid=None, child_started_unix=None, last_exit=outcome)
            return p.returncode, stdout, stderr, sampler.samples, None, outcome
        except subprocess.TimeoutExpired as exc:
            p.kill(); stdout, stderr = p.communicate()
            outcome = {"status": "watchdog_timeout", "pid": p.pid, "started_unix": started,
                       "completed_unix": time.time(), "returncode": p.returncode, "watchdog_timeout": True}
            lock.update(child_pid=None, child_started_unix=None, last_exit=outcome)
            return None, (stdout or ""), (stderr or ""), sampler.samples, "watchdog_timeout", outcome


def write_jsonl(path, records):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        for record in records:
            f.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
        f.flush(); os.fsync(f.fileno())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--runner", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--manifest", default="benchmarks/stage45b_fp64_scalability_cases.json")
    p.add_argument("--root", default=".")
    p.add_argument("--timeout-seconds", type=int, default=300)
    p.add_argument("--total-budget-seconds", type=int, default=14400)
    p.add_argument("--telemetry-seconds", type=float, default=5.0)
    p.add_argument("--cases", nargs="+")
    p.add_argument("--include-stretch", action="store_true")
    args = p.parse_args()
    if args.timeout_seconds <= 0 or args.total_budget_seconds <= 0 or args.telemetry_seconds <= 0:
        p.error("budgets and telemetry interval must be positive")
    root = Path(args.root).resolve(); output = (root / args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=False); (output / "fixed_p").mkdir()
    experiment_lock = ExperimentLock(root / "results", Path(__file__).resolve(), output).acquire()
    completion_status = "interrupted_unclassified"
    atexit.register(lambda: experiment_lock.release(completion_status))
    decimal.getcontext().prec = 80
    manifest = json.loads((root / args.manifest).read_text(encoding="utf-8"))
    selected = set(args.cases or [x["id"] for x in manifest["cases"]])
    unknown = selected - {x["id"] for x in manifest["cases"]}
    if unknown: p.error("unknown cases: " + ", ".join(sorted(unknown)))
    run_manifest = {"schema_version": 1, "stage": "4.5B FP64 scalability", "runner": str(Path(args.runner).resolve()),
                    "runner_sha256": sha(args.runner), "started_unix": time.time(), "sequential": True,
                    "configuration_watchdog_seconds": args.timeout_seconds, "total_budget_seconds": args.total_budget_seconds,
                    "host_memory_policy": "not probed, estimated, monitored, or gated; Windows manages RAM and paging",
                    "gpu_preflight_policy": "no-margin source-known allocation screen; dynamic/vendor allocations execute normally",
                    "telemetry_seconds": args.telemetry_seconds,
                    "frozen_settings": manifest["frozen_settings"], "selected_cases": sorted(selected),
                    "conditional_16384_enabled": args.include_stretch,
                    "notes": "No retry, outlier deletion, restart, tolerance change, or concurrent benchmark process."}
    (output / "RUN_MANIFEST.json").write_text(json.dumps(run_manifest, indent=2) + "\n", encoding="utf-8")
    summary, started = [], time.monotonic()
    for case in manifest["cases"]:
        if case["id"] not in selected or (case.get("conditional") and not args.include_stretch):
            continue
        matrix = (root / case["matrix"]).resolve()
        n, m, a = common.load_mm(matrix)
        if n != m:
            raise ValueError("only square inputs are supported")
        tier = manifest["predeclared_trials"][case["tier"]]
        if time.monotonic() - started >= args.total_budget_seconds:
            summary.append({"case": case["id"], "classification": "resource_abort", "substatus": "total_budget_exhausted_before_case"})
            break
        common_args = ["--matrix", str(matrix), "--rhs", case["rhs"], "--epsilon", "0.3", "--alpha", str((n + 7) // 8), "--beta", "8", "--innercap", str(n), "--outercap", "20", "--warmups", str(tier["warmups"]), "--trials", str(tier["measured_trials"])]
        pfile = output / "fixed_p" / (case["id"] + ".mtx")
        prep = [args.runner, "--mode", "prepare_fixed_p", *common_args, "--p-output", str(pfile)]
        remaining_for_prep = max(1, int(args.total_budget_seconds - (time.monotonic() - started)))
        returncode, stdout, stderr, telemetry, timeout, process = run_with_telemetry(
            prep, min(args.timeout_seconds, remaining_for_prep), args.telemetry_seconds, experiment_lock, case["id"], "prepare_fixed_p")
        prep_records = [json.loads(x) for x in stdout.splitlines() if x.startswith("{")]
        write_jsonl(output / (case["id"] + "_fixed_p_preparation.jsonl"), [{"event": "artifact_manifest", "command": prep, "returncode": returncode, "stderr": stderr, "telemetry": telemetry, "timeout": timeout, "process": process}, *prep_records])
        if timeout or returncode or not pfile.exists() or not prep_records or prep_records[-1].get("construction_status") != "success":
            summary.append({"case": case["id"], "classification": "construction_failure" if not timeout else "resource_abort", "substatus": "fixed_p_preparation"})
            continue
        _, _, fixed = common.load_mm(pfile)
        audit = {"matrix": binary64_audit([v for _, v in sorted(a.items())]), "rhs": binary64_audit(common.rhs(a, n, case["rhs"])), "fixed_p": binary64_audit([v for _, v in sorted(fixed.items())]), "matrix_sha256": sha(matrix), "fixed_p_file_sha256": sha(pfile)}
        (output / (case["id"] + "_binary64_audit.json")).write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
        for mode in MODES:
            remaining = args.total_budget_seconds - (time.monotonic() - started)
            if remaining <= 0:
                summary.append({"case": case["id"], "mode": mode, "classification": "resource_abort", "substatus": "total_budget_exhausted"})
                break
            command = [args.runner, "--mode", mode, *common_args]
            if mode.endswith("_fixed"): command += ["--p", str(pfile)]
            if mode.startswith("gpu_"):
                gpu_pre = gpu_preflight(mode, n, len(a), len(fixed) if mode.endswith("_fixed") else None)
                gpu_pre.update(case=case["id"], matrix=str(matrix), matrix_sha256=sha(matrix), rows=n, nnz=len(a),
                               fixed_p_sha256=sha(pfile) if mode.endswith("_fixed") else None)
                gpu_pre_name = case["id"] + "_" + mode + "_gpu_preflight.json"
                (output / gpu_pre_name).write_text(json.dumps(gpu_pre, indent=2) + "\n", encoding="utf-8")
                if not gpu_pre["accepted"]:
                    summary.append({"case": case["id"], "mode": mode, "classification": "resource_abort",
                                    "substatus": gpu_pre["reason"], "preflight": gpu_pre_name})
                    continue
            returncode, stdout, stderr, telemetry, timeout, process = run_with_telemetry(command, min(args.timeout_seconds, max(1, int(remaining))), args.telemetry_seconds, experiment_lock, case["id"], mode)
            records = [json.loads(x) for x in stdout.splitlines() if x.startswith("{")]
            wrapper = {"event": "artifact_manifest", "case": case, "matrix": str(matrix), "command": command, "returncode": returncode,
                       "stderr": stderr, "telemetry_during_configuration": telemetry, "timeout": timeout, "process": process,
                       "matrix_sha256": sha(matrix), "fixed_p_sha256": sha(pfile) if mode.endswith("_fixed") else None,
                       "binary64_audit": audit}
            for record in records:
                if record.get("event") == "sample" and record.get("converged") and record.get("solution"):
                    record["independent_decimal80"] = common.decimal_diagnostics(a, common.rhs(a, n, case["rhs"]), record["solution"])
                    record["binary64_solution_roundtrip"] = binary64_audit(record["solution"])
                    if mode.endswith("_fixed"):
                        record["independent_decimal80_gmres"] = common.decimal_fixed_gmres(a, fixed, common.rhs(a, n, case["rhs"]), record["solution"])
            artifact = output / (case["id"] + "_" + mode + ".jsonl")
            no_records_status = "resource_abort" if timeout else "process_termination_unclassified"
            write_jsonl(artifact, [wrapper, *records] if records else [wrapper, {"event": no_records_status, "substatus": timeout or "process_disappeared_without_usable_json", "process": process}])
            local = common.summary(records, mode); local.update(case=case["id"], mode=mode, rows=n, nnz=len(a), raw_artifact=artifact.name, classification="completed" if local.get("completed_trials") else ("resource_abort" if timeout else "not_accepted"))
            summary.append(local)
            if local.get("completed_trials"):
                experiment_lock.update(last_successful_configuration={"case": case["id"], "mode": mode, "completed_unix": time.time()})
    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    completion_status = "completed"
    print(json.dumps({"output": str(output), "summary_records": len(summary)}))


if __name__ == "__main__":
    main()
