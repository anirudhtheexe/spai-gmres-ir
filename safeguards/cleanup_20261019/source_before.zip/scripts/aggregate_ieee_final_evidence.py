#!/usr/bin/env python3
"""Derive traceable CSV, JSON, and SVG artifacts from saved IEEE campaign snapshots.

This is deliberately an offline reader: it does not launch a solver, checker, or profiler.
"""
from __future__ import annotations

import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results" / "ieee_final_evidence_20261012"
RUNS = {
    "fp64": ROOT / "results" / "ieee_final_scalability_fp64_stage_a_20261012",
    "fp32": ROOT / "results" / "ieee_final_scalability_fp32_stage_a_20261012",
}
ORDER = [1024, 2048, 4096, 8192, 12000]
MODES = ("spai", "gmres_fixed", "pipeline")


def read_jsonl(path: Path):
    with path.open(encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def write_csv(path: Path, rows, columns):
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=columns)
        w.writeheader()
        w.writerows(rows)


def esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;")


def svg(path: Path, title: str, panels):
    """Minimal dependency-free vector line-chart writer."""
    width, height, margin = 1250, 300 * len(panels) + 80, 85
    bits = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
            '<style>text{font-family:Arial,sans-serif;fill:#172033}.t{font-size:20px;font-weight:bold}.p{font-size:14px;font-weight:bold}.a{font-size:12px}.l{fill:none;stroke-width:2.5}</style>',
            f'<text class="t" x="{margin}" y="30">{esc(title)}</text>']
    colors = ["#1565c0", "#d84315", "#2e7d32", "#7b1fa2"]
    for pi, panel in enumerate(panels):
        top = 55 + pi * 300
        vals = [v for _, series in panel["series"] for _, v in series if v is not None and v > 0]
        ymin, ymax = min(vals), max(vals)
        log = panel.get("log", False)
        transform = (lambda x: math.log10(x)) if log else (lambda x: x)
        lo, hi = transform(ymin), transform(ymax)
        pad = max((hi - lo) * .12, .05)
        lo -= pad; hi += pad
        x0, x1, y0, y1 = margin, width - 220, top + 30, top + 245
        bits += [f'<text class="p" x="{x0}" y="{top}">{esc(panel["title"])}</text>',
                 f'<line stroke="#52606d" x1="{x0}" y1="{y1}" x2="{x1}" y2="{y1}"/><line stroke="#52606d" x1="{x0}" y1="{y0}" x2="{x0}" y2="{y1}"/>']
        for i in range(5):
            z = lo + (hi-lo)*i/4; y = y1 - (z-lo)/(hi-lo)*(y1-y0)
            value = 10**z if log else z
            bits += [f'<line stroke="#d8dee9" x1="{x0}" y1="{y:.1f}" x2="{x1}" y2="{y:.1f}"/>', f'<text class="a" text-anchor="end" x="{x0-8}" y="{y+4:.1f}">{value:.2g}</text>']
        labels = panel["x"]
        for i, label in enumerate(labels):
            x = x0 + (x1-x0)*i/(len(labels)-1)
            bits += [f'<line stroke="#52606d" x1="{x:.1f}" y1="{y1}" x2="{x:.1f}" y2="{y1+5}"/>', f'<text class="a" text-anchor="middle" x="{x:.1f}" y="{y1+21}">{esc(label)}</text>']
        for si, (name, series) in enumerate(panel["series"]):
            points=[]
            for i, (_, value) in enumerate(series):
                if value is None or value <= 0: continue
                x=x0+(x1-x0)*i/(len(labels)-1); y=y1-(transform(value)-lo)/(hi-lo)*(y1-y0)
                points.append((x,y))
            color=colors[si%len(colors)]
            bits.append(f'<polyline class="l" stroke="{color}" points="' + " ".join(f"{x:.1f},{y:.1f}" for x,y in points) + '"/>')
            for x,y in points: bits.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="3.5" fill="{color}"/>')
            bits.append(f'<rect x="{x1+22}" y="{top+35+si*22}" width="12" height="12" fill="{color}"/><text class="a" x="{x1+40}" y="{top+46+si*22}">{esc(name)}</text>')
        bits.append(f'<text class="a" x="{x0}" y="{y0-7}">{esc(panel.get("ylabel", "ms"))}</text>')
    bits.append('</svg>')
    path.write_text("\n".join(bits), encoding="utf-8")


def main():
    for p in (OUT / "raw", OUT / "summaries", OUT / "validation", OUT / "figures", OUT / "manifests"):
        p.mkdir(parents=True, exist_ok=True)
    samples, medians, validation, manifests = [], [], [], []
    for precision, directory in RUNS.items():
        summary = json.loads((directory / "SUMMARY.json").read_text(encoding="utf-8"))
        for entry in summary:
            raw_path = directory / entry["raw_artifact"]
            checker_path = directory / entry["decimal80_artifact"]
            raw = read_jsonl(raw_path)
            artifact = next(r for r in raw if r.get("event") == "artifact_manifest")
            # FP64 driver emits a solver manifest while the FP32 driver embeds
            # equivalent dimensions in its artifact record.  Trial phases are
            # the authoritative protocol evidence for both drivers.
            manifest = next((r for r in raw if r.get("event") == "manifest"), {})
            trials = [r for r in raw if r.get("event") == "sample"]
            measured = [r for r in trials if r["phase"] == "measured"]
            case = entry["case"]; family, ntext = case.rsplit("_", 1); n = int(ntext)
            for t in trials:
                samples.append({"precision":precision,"case":case,"family":family,"n":n,"mode":entry["mode"],"phase":t["phase"],"ordinal":t["ordinal"],"elapsed_ms":t["elapsed_ms"],"status":t.get("status"),"converged":t.get("converged"),"p_nnz":t.get("construction_nnz_p"),"fits":t.get("construction_fit_count"),"growths":t.get("construction_growth_count"),"outer_steps":t.get("outer_steps"),"inner_total_iterations":t.get("inner_total_iterations"),"backward_error":t.get("normwise_backward_error"),"forward_error":t.get("manufactured_forward_error")})
            times = [float(t["elapsed_ms"]) for t in measured]
            representative = measured[len(measured)//2]
            medians.append({"precision":precision,"case":case,"family":family,"n":n,"mode":entry["mode"],"matrix_sha256":artifact["matrix_sha256"],"warmups":len([t for t in trials if t["phase"] == "warmup"]),"measured_trials":len(measured),"trial_ms":";".join(f"{x:.6f}" for x in times),"median_ms":statistics.median(times),"min_ms":min(times),"max_ms":max(times),"status":representative.get("status"),"converged":representative.get("converged"),"p_nnz":representative.get("construction_nnz_p"),"fits":representative.get("construction_fit_count"),"growths":representative.get("construction_growth_count"),"outer_steps":representative.get("outer_steps"),"inner_total_iterations":representative.get("inner_total_iterations"),"backward_error":representative.get("normwise_backward_error"),"forward_error":representative.get("manufactured_forward_error"),"solver_returncode":entry["solver_returncode"],"checker_returncode":entry["checker_returncode"],"accepted":entry["accepted"],"raw_artifact":str(raw_path.relative_to(ROOT)),"decimal80_artifact":str(checker_path.relative_to(ROOT))})
            check = next(r for r in read_jsonl(checker_path) if r.get("event") == "decimal80_snapshot_assessment")
            validation.append({"precision":precision,"case":case,"mode":entry["mode"],"accepted":check["accepted"],"failure_count":len(check["failures"]),"checked_measured_trials":len(check["checked"]),"checker_returncode":entry["checker_returncode"],"artifact":str(raw_path.relative_to(ROOT)),"sidecar":str(checker_path.relative_to(ROOT))})
            manifests.append({"precision":precision,"case":case,"mode":entry["mode"],"matrix":artifact["matrix"],"matrix_sha256":artifact["matrix_sha256"],"command":" ".join(artifact["command"]),"raw_artifact":str(raw_path.relative_to(ROOT)),"decimal80_artifact":str(checker_path.relative_to(ROOT))})
    cols=list(samples[0]); write_csv(OUT / "raw" / "fresh_all_samples.csv", samples, cols)
    cols=list(medians[0]); write_csv(OUT / "summaries" / "fresh_median_results.csv", medians, cols)
    cols=list(validation[0]); write_csv(OUT / "validation" / "decimal80_snapshot_validation.csv", validation, cols)
    cols=list(manifests[0]); write_csv(OUT / "manifests" / "fresh_command_matrix.csv", manifests, cols)
    lookup={(r["precision"],r["case"],r["mode"]):r for r in medians}
    pairs=[]
    for precision in RUNS:
        for family in ("stencil","irregular"):
            for n in ORDER:
                case=f"{family}_{n}"
                for scope, cpu, gpu in (("SPAI construction","cpu_spai","gpu_spai"),("fixed-P GMRES","cpu_gmres_fixed","gpu_gmres_fixed"),("native pipeline","cpu_pipeline","gpu_pipeline")):
                    c,g=lookup[(precision,case,cpu)],lookup[(precision,case,gpu)]
                    pairs.append({"precision":precision,"case":case,"family":family,"n":n,"scope":scope,"cpu_median_ms":c["median_ms"],"gpu_median_ms":g["median_ms"],"cpu_over_gpu_speedup":c["median_ms"]/g["median_ms"],"accepted":bool(c["accepted"] and g["accepted"])})
    cols=list(pairs[0]); write_csv(OUT / "summaries" / "fresh_cpu_gpu_speedups.csv", pairs, cols)
    summary={"campaign":"IEEE final evidence fresh Stage-A-current scalability","protocol":{"warmups":3,"measured_trials":3,"checker":"saved-snapshot Decimal80"},"configuration_count":len(medians),"measured_trial_count":len(medians)*3,"accepted_configurations":sum(bool(r["accepted"]) for r in medians),"accepted_decimal80_sidecars":sum(bool(r["accepted"]) for r in validation),"results":medians,"speedups":pairs}
    (OUT / "summaries" / "fresh_campaign_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    def series(precision, family, mode, backend):
        return [(str(n),lookup[(precision,f"{family}_{n}",f"{backend}_{mode}")]["median_ms"]) for n in ORDER]
    svg(OUT / "figures" / "fp64_cpu_gpu_time.svg", "Fresh Stage-A-current FP64 CPU/GPU time", [
        {"title":f"{family}: {mode}","x":[str(n) for n in ORDER],"ylabel":"median wall time (ms; log scale)","log":True,"series":[("CPU",series("fp64",family,mode,"cpu")),("GPU",series("fp64",family,mode,"gpu"))]} for family in ("stencil","irregular") for mode in MODES])
    speed_panels=[]
    for family in ("stencil","irregular"):
        sets=[]
        for mode, label in (("spai","SPAI"),("gmres_fixed","fixed-P GMRES"),("pipeline","pipeline")):
            sets.append((label,[(str(n),lookup[("fp64",f"{family}_{n}",f"cpu_{mode}")]["median_ms"]/lookup[("fp64",f"{family}_{n}",f"gpu_{mode}")]["median_ms"]) for n in ORDER]))
        speed_panels.append({"title":f"FP64 {family}: CPU/GPU speedup (1 = tie)","x":[str(n) for n in ORDER],"ylabel":"CPU time / GPU time","series":sets})
    svg(OUT / "figures" / "fp64_speedup.svg", "Fresh Stage-A-current FP64 CPU/GPU speedup", speed_panels)
    fp_panels=[]
    for family in ("stencil","irregular"):
        for backend in ("cpu","gpu"):
            fp_panels.append({"title":f"{family}: {backend.upper()} native pipeline", "x":[str(n) for n in ORDER], "ylabel":"median wall time (ms; log scale)","log":True,"series":[("FP32",series("fp32",family,"pipeline",backend)),("FP64",series("fp64",family,"pipeline",backend))]})
    svg(OUT / "figures" / "fp32_fp64_pipeline.svg", "Fresh uniform FP32 vs FP64 native-pipeline time", fp_panels)
    api_panels=[{"title":"CUDA API calls per two-construction stencil-8192 trace","x":["post-batching","Stage A"],"ylabel":"calls","series":[("cudaMemcpyAsync",[("post-batching",276008),("Stage A",243748)]),("cudaLaunchKernel",[("post-batching",357658),("Stage A",357658)]),("cudaStreamSynchronize",[("post-batching",130126),("Stage A",130126)])]}]
    svg(OUT / "figures" / "cuda_api_counts.svg", "CUDA API count evidence", api_panels)
    stage=[("FP32 stencil 8192",2222.4,1980.3,2542.8,2203.6),("FP32 irregular 8192",1167.9,1084.4,1548.4,1421.4),("FP32 stencil 12000",3305.6,3060.0,3815.9,3434.6),("FP32 irregular 12000",1675.1,1771.4,2252.0,2061.2),("FP64 stencil 8192",2160.4,2011.6,4862.5,4911.1),("FP64 irregular 8192",1163.6,1127.2,3492.1,3557.5),("FP64 stencil 12000",3475.1,3157.4,8326.1,11559.2),("FP64 irregular 12000",1653.1,1694.9,6585.1,7551.7)]
    svg(OUT / "figures" / "stage_a_walltime.svg", "Stage A vs post-batching: retained GPU wall-clock medians", [{"title":"GPU SPAI construction","x":[r[0] for r in stage],"ylabel":"median ms","series":[("post-batching",[(r[0],r[1]) for r in stage]),("Stage A",[(r[0],r[2]) for r in stage])]}, {"title":"GPU native pipeline","x":[r[0] for r in stage],"ylabel":"median ms","series":[("post-batching",[(r[0],r[3]) for r in stage]),("Stage A",[(r[0],r[4]) for r in stage])]}])
    print(json.dumps({"accepted_configurations":summary["accepted_configurations"],"measured_trials":summary["measured_trial_count"],"out":str(OUT)},indent=2))


if __name__ == "__main__":
    main()
