"""Run one serial, snapshot-verified precision-specific IEEE scaling campaign.

This wrapper is deliberately separate from retained historical runners.  It
creates a new output directory, owns the existing root experiment lock, starts
only one solver/checker child at a time, persists solver stdout before invoking
the Decimal80 checker, and never overwrites evidence.
"""
import argparse
import atexit
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from benchmark_experiment_lock import ExperimentLock


CASES = (
    ("stencil_1024", "data/stage45b_fp64_scalability_v1/stencil_1024.mtx"),
    ("irregular_1024", "data/stage45b_fp64_scalability_v1/irregular_1024.mtx"),
    ("stencil_2048", "data/stage45b_fp64_scalability_v1/stencil_2048.mtx"),
    ("irregular_2048", "data/stage45b_fp64_scalability_v1/irregular_2048.mtx"),
    ("stencil_4096", "data/stage45b_fp64_scalability_v1/stencil_4096.mtx"),
    ("irregular_4096", "data/stage45b_fp64_scalability_v1/irregular_4096.mtx"),
    ("stencil_8192", "data/stage45b_fp64_scalability_v1/stencil_8192.mtx"),
    ("irregular_8192", "data/stage45b_fp64_scalability_v1/irregular_8192.mtx"),
    ("stencil_12000", "data/stage45b_fp64_12000_v1/stencil_12000.mtx"),
    ("irregular_12000", "data/stage45b_fp64_12000_v1/irregular_12000.mtx"),
)
MODES = ("cpu_spai", "gpu_spai", "cpu_gmres_fixed", "gpu_gmres_fixed",
         "cpu_pipeline", "gpu_pipeline")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dimension(path):
    with Path(path).open(encoding="utf-8-sig") as source:
        for line in source:
            if line and not line.startswith("%"):
                n, m, _ = map(int, line.split())
                if not n or n != m:
                    raise ValueError("expected nonempty square Matrix Market input: " + str(path))
                return n
    raise ValueError("missing Matrix Market dimensions: " + str(path))


def write_jsonl_new(path, records):
    with Path(path).open("x", encoding="utf-8", newline="\n") as out:
        for record in records:
            out.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
        out.flush()
        os.fsync(out.fileno())


def parse_records(stdout):
    records, ignored = [], []
    for line in stdout.splitlines():
        if not line.startswith("{"):
            ignored.append(line)
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            ignored.append(line)
    return records, ignored


def run_one(command, timeout, lock, case, precision, mode):
    started = time.time()
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    lock.update(active_case=case, active_mode=precision + ":" + mode,
                child_pid=child.pid, child_started_unix=started, last_exit=None)
    try:
        stdout, stderr = child.communicate(timeout=timeout)
        result = {"status": "completed" if child.returncode == 0 else "process_exit_nonzero",
                  "pid": child.pid, "started_unix": started, "completed_unix": time.time(),
                  "returncode": child.returncode, "watchdog_timeout": False}
        return child.returncode, stdout, stderr, result
    except subprocess.TimeoutExpired:
        child.kill()
        stdout, stderr = child.communicate()
        result = {"status": "watchdog_timeout", "pid": child.pid, "started_unix": started,
                  "completed_unix": time.time(), "returncode": child.returncode,
                  "watchdog_timeout": True}
        return None, stdout or "", stderr or "", result
    finally:
        lock.update(child_pid=None, child_started_unix=None, last_exit=result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runner", required=True)
    parser.add_argument("--precision", choices=("fp32", "fp64"), required=True)
    parser.add_argument("--checker", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--root", default=".")
    parser.add_argument("--timeout-seconds", type=int, default=300)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--trials", type=int, default=3)
    parser.add_argument("--cases", nargs="+", choices=[case[0] for case in CASES])
    args = parser.parse_args()
    if args.timeout_seconds <= 0 or args.warmups < 0 or args.trials < 3:
        parser.error("positive timeout, nonnegative warmups, and at least three trials are required")

    root = Path(args.root).resolve()
    output = (root / args.output_dir).resolve()
    runner, checker = Path(args.runner).resolve(), Path(args.checker).resolve()
    if output.exists():
        raise SystemExit("refusing to overwrite evidence directory: " + str(output))
    if not runner.is_file() or not checker.is_file():
        raise SystemExit("runner and checker must exist before lock acquisition")
    output.mkdir(parents=True)
    fixed_dir = output / "fixed_p"
    fixed_dir.mkdir()
    selected = set(args.cases or [case[0] for case in CASES])
    tolerance = "1e-4" if args.precision == "fp32" else "1e-8"
    outer_be = "10*2^-24" if args.precision == "fp32" else "10*2^-53"
    lock = ExperimentLock(root / "results", Path(__file__).resolve(), output).acquire()
    completion = "interrupted_unclassified"
    atexit.register(lambda: lock.release(completion))
    manifest = {
        "schema_version": 1,
        "experiment": "IEEE final fresh CPU/GPU scalability evidence",
        "precision": args.precision,
        "started_unix": time.time(), "sequential": True,
        "exclusive_lock": str(lock.path), "warmups": args.warmups,
        "measured_trials": args.trials,
        "timing_boundary": "one frozen public API call; GPU synchronizes immediately before and after",
        "parameters": {"epsilon": .3, "beta": 8, "alpha": "ceil(n/8)",
                       "gmres_tolerance": tolerance, "outer_be": outer_be,
                       "innercap": "n", "outercap": 20},
        "runner": str(runner), "runner_sha256": digest(runner),
        "checker": str(checker), "checker_sha256": digest(checker),
        "notes": "One child at a time. Fixed P preparation is untimed. Raw solver JSONL is durable before the snapshot-only Decimal80 checker starts.",
    }
    (output / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    progress = output / "PROGRESS.jsonl"

    def log(event, **fields):
        with progress.open("a", encoding="utf-8", newline="\n") as out:
            out.write(json.dumps(dict(event=event, unix=time.time(), **fields), separators=(",", ":")) + "\n")
            out.flush()
            os.fsync(out.fileno())

    summary = []
    for case, relative in CASES:
        if case not in selected:
            continue
        matrix = (root / relative).resolve()
        n = dimension(matrix)
        common = ["--matrix", str(matrix), "--rhs", "periodic7", "--epsilon", "0.3",
                  "--alpha", str((n + 7) // 8), "--beta", "8", "--innercap", str(n),
                  "--outercap", "20", "--warmups", str(args.warmups), "--trials", str(args.trials)]
        fixed_p = fixed_dir / (case + "_" + args.precision + ".mtx")
        prepare = [str(runner), "--mode", "prepare_fixed_p", *common, "--p-output", str(fixed_p)]
        log("preparation_started", case=case, precision=args.precision)
        rc, stdout, stderr, process = run_one(prepare, args.timeout_seconds, lock, case, args.precision, "prepare_fixed_p")
        records, ignored = parse_records(stdout)
        prep_path = output / (case + "_" + args.precision + "_fixed_p_preparation.jsonl")
        write_jsonl_new(prep_path, [{"event": "artifact_manifest", "command": prepare, "returncode": rc,
                                     "stderr": stderr, "stdout_ignored": ignored, "process": process}, *records])
        prepared = rc == 0 and fixed_p.exists() and bool(records) and records[-1].get("construction_status") == "success"
        log("preparation_finished", case=case, precision=args.precision, returncode=rc, prepared=prepared)
        if not prepared:
            summary.append({"case": case, "precision": args.precision,
                            "classification": "fixed_p_preparation_failure", "artifact": prep_path.name})
            continue
        for mode in MODES:
            command = [str(runner), "--mode", mode, *common]
            if mode.endswith("_fixed"):
                command += ["--p", str(fixed_p)]
            log("configuration_started", case=case, precision=args.precision, mode=mode)
            rc, stdout, stderr, process = run_one(command, args.timeout_seconds, lock, case, args.precision, mode)
            records, ignored = parse_records(stdout)
            artifact = output / (case + "_" + args.precision + "_" + mode + ".jsonl")
            wrapper = {"event": "artifact_manifest", "case": case, "precision": args.precision, "mode": mode,
                       "matrix": str(matrix), "matrix_sha256": digest(matrix), "command": command,
                       "fixed_p": str(fixed_p) if mode.endswith("_fixed") else None,
                       "fixed_p_sha256": digest(fixed_p) if mode.endswith("_fixed") else None,
                       "returncode": rc, "stderr": stderr, "stdout_ignored": ignored, "process": process}
            write_jsonl_new(artifact, [wrapper, *records] if records else
                            [wrapper, {"event": "process_termination_unclassified", "process": process}])
            check = [sys.executable, str(checker), "--artifact", str(artifact), "--matrix", str(matrix),
                     "--precision", args.precision, "--mode", mode]
            if mode.endswith("_fixed"):
                check += ["--fixed-p", str(fixed_p), "--gmres-tolerance", tolerance]
            log("snapshot_check_started", case=case, precision=args.precision, mode=mode)
            check_rc, check_out, check_err, check_process = run_one(check, args.timeout_seconds, lock, case, args.precision, "snapshot_check:" + mode)
            check_records, check_ignored = parse_records(check_out)
            check_path = output / (case + "_" + args.precision + "_" + mode + "_decimal80.jsonl")
            write_jsonl_new(check_path, [{"event": "checker_manifest", "command": check, "returncode": check_rc,
                                          "stderr": check_err, "stdout_ignored": check_ignored,
                                          "process": check_process}, *check_records])
            accepted = rc == 0 and check_rc == 0
            summary.append({"case": case, "precision": args.precision, "mode": mode,
                            "raw_artifact": artifact.name, "decimal80_artifact": check_path.name,
                            "solver_returncode": rc, "checker_returncode": check_rc, "accepted": accepted})
            log("configuration_finished", case=case, precision=args.precision, mode=mode,
                solver_returncode=rc, checker_returncode=check_rc)
            if accepted:
                lock.update(last_successful_configuration={"case": case, "precision": args.precision,
                                                           "mode": mode, "completed_unix": time.time()})
    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    completion = "completed"
    print(json.dumps({"output": str(output), "summary_records": len(summary)}))


if __name__ == "__main__":
    main()
