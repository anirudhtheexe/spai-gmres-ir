"""Process-owned exclusive lock shared by every Stage 4.5B launcher.

The lock deliberately lives at the results root rather than in an individual
evidence directory.  A new output directory must not make a second benchmark
runner permissible.  Existing locks are never automatically removed: callers
must inspect their recorded owner and explicitly reclaim only a confirmed-dead
owner outside this module.
"""
import json
import os
from pathlib import Path
import time
import uuid


LOCK_NAME = "STAGE45B_EXPERIMENT_LOCK.json"


def _write_atomic(path, payload):
    temporary = path.with_name(path.name + "." + payload["owner_token"] + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def process_liveness(pid):
    """Return a documented best-effort liveness observation without acting on it."""
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return {"pid": pid, "alive": False, "method": "os.kill"}
    except PermissionError:
        return {"pid": pid, "alive": True, "method": "os.kill_permission_denied"}
    except OSError as exc:
        # Windows reports ERROR_INVALID_PARAMETER (87) for a nonexistent PID
        # when probing with signal 0.  Preserve other OS errors as unknown
        # rather than risking reclamation of a possibly live owner.
        if getattr(exc, "winerror", None) == 87:
            return {"pid": pid, "alive": False, "method": "os.kill_winerror_87"}
        return {"pid": pid, "alive": None, "method": "os.kill_error", "error": str(exc)}
    except (TypeError, ValueError):
        return {"pid": pid, "alive": None, "method": "invalid_pid"}
    return {"pid": pid, "alive": True, "method": "os.kill"}


class ExperimentLock:
    def __init__(self, results_root, launcher, output_dir):
        self.path = Path(results_root) / LOCK_NAME
        self.owner_token = uuid.uuid4().hex
        self.payload = {
            "schema_version": 1,
            "owner_token": self.owner_token,
            "runner_pid": os.getpid(),
            "runner_started_unix": time.time(),
            "launcher": str(launcher),
            "output_dir": str(output_dir),
            "active_case": None,
            "active_mode": None,
            "child_pid": None,
            "child_started_unix": None,
            "last_successful_configuration": None,
            "last_exit": None,
        }

    def acquire(self):
        try:
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            existing = json.loads(self.path.read_text(encoding="utf-8"))
            existing["owner_liveness_at_rejection"] = process_liveness(existing.get("runner_pid"))
            raise RuntimeError("Stage 4.5B experiment is already locked: " + json.dumps(existing, sort_keys=True)) from exc
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(self.payload, f, indent=2); f.write("\n"); f.flush(); os.fsync(f.fileno())
        return self

    def update(self, **fields):
        self.payload.update(fields)
        _write_atomic(self.path, self.payload)

    def release(self, completion_status):
        self.update(active_case=None, active_mode=None, child_pid=None,
                    child_started_unix=None, completed_unix=time.time(),
                    completion_status=completion_status)
        # Only the token owner may release.  Never unlink another process's lock.
        current = json.loads(self.path.read_text(encoding="utf-8"))
        if current.get("owner_token") == self.owner_token:
            self.path.unlink()
