"""Run the predeclared Stage 4.5B exploratory campaign.

This script does no numerical work in a timed interval.  The C++ harness
times one frozen public call per sample; this runner retains every emitted
sample, then independently checks each finite successful solution in Decimal80.
It creates a new output directory and never replaces an artifact.
"""
import argparse, atexit, decimal, hashlib, json, math, os, statistics, subprocess, sys, time
from pathlib import Path
from benchmark_experiment_lock import ExperimentLock

U = decimal.Decimal(2) ** -53

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_mm(path):
    """Canonical sparse coordinate loader sufficient for retained real inputs."""
    lines = [x.strip() for x in Path(path).read_text(encoding='utf-8-sig').splitlines() if x.strip()]
    banner = lines[0].lower()
    if not banner.startswith('%%matrixmarket matrix coordinate real'):
        raise ValueError('only real coordinate Matrix Market input is supported')
    body = [x for x in lines[1:] if not x.startswith('%')]
    n, m, _ = map(int, body[0].split())
    entries = {}
    symmetric = 'symmetric' in banner
    for line in body[1:]:
        i, j, v = line.split()[:3]; key = (int(i) - 1, int(j) - 1)
        entries[key] = entries.get(key, 0.0) + float(v)
        if symmetric and key[0] != key[1]: entries[(key[1], key[0])] = entries.get((key[1], key[0]), 0.0) + float(v)
    return n, m, {k:v for k,v in entries.items() if v != 0.0}

def decimal_d(x): return decimal.Decimal.from_float(float(x))

def rhs(a, n, kind):
    if kind == 'equal_unit2': return [1.0 / math.sqrt(n)] * n
    if kind == 'periodic7':
        x = [(i % 7 - 3) / 4.0 for i in range(n)]
        out = [0.0] * n
        for (i, j), v in a.items(): out[i] += v * x[j]
        return out
    raise ValueError(kind)

def decimal_diagnostics(a, b, x):
    n = len(b); bd = list(map(decimal_d, b)); xd = list(map(decimal_d, x)); ax = [decimal.Decimal(0)] * n
    row_sum = [decimal.Decimal(0)] * n; component = [abs(bd[i]) for i in range(n)]
    for (i, j), value in a.items():
        d = decimal_d(value); ax[i] += d * xd[j]; row_sum[i] += abs(d); component[i] += abs(d) * abs(xd[j])
    r = [bd[i] - ax[i] for i in range(n)]; rinf = max(map(abs, r), default=decimal.Decimal(0))
    r2 = sum((z*z for z in r), decimal.Decimal(0)).sqrt(); den = max(row_sum, default=decimal.Decimal(0)) * max(map(abs, xd), default=decimal.Decimal(0)) + max(map(abs, bd), default=decimal.Decimal(0))
    eta = decimal.Decimal(0) if den == 0 and rinf == 0 else rinf / den
    return {'original_residual_2_decimal80': str(r2), 'original_residual_inf_decimal80': str(rinf), 'normwise_backward_error_decimal80': str(eta), 'accepts_frozen_backward_error': eta <= decimal.Decimal(10) * U}

def decimal_fixed_gmres(a, p, b, x, tau=1e-8):
    """Independent Decimal80 left-preconditioned GMRES acceptance check.

    This intentionally does not use the IR backward-error stopping rule: a
    fixed-P GMRES row is accepted by ||P(b-Ax)||_2 / ||Pb||_2 <= tau.
    """
    n=len(b); bd=list(map(decimal_d,b)); xd=list(map(decimal_d,x)); ax=[decimal.Decimal(0)]*n
    for (i,j),v in a.items(): ax[i] += decimal_d(v)*xd[j]
    residual=[bd[i]-ax[i] for i in range(n)]; pb=[decimal.Decimal(0)]*n; pr=[decimal.Decimal(0)]*n
    for (i,j),v in p.items():
        d=decimal_d(v); pb[i] += d*bd[j]; pr[i] += d*residual[j]
    numerator=sum((z*z for z in pr),decimal.Decimal(0)).sqrt(); denominator=sum((z*z for z in pb),decimal.Decimal(0)).sqrt()
    relative=decimal.Decimal(0) if numerator == denominator == 0 else numerator/denominator
    # Decimal80 evaluates the exact stored binary64 inputs and solution.  Keep
    # the frozen tau exact; boundary disagreements are results, not allowances.
    return {'preconditioned_relative_decimal80':str(relative),'tau_decimal':str(decimal.Decimal(str(tau))),'accepts_frozen_gmres_tolerance':relative <= decimal.Decimal(str(tau))}

def run(command, timeout):
    cp = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    records=[]
    for line in cp.stdout.splitlines():
        try: records.append(json.loads(line))
        except json.JSONDecodeError: pass
    return cp, records

def summary(samples, mode):
    def accepted(x):
        if x.get('phase') != 'measured' or not x.get('converged') or x.get('harness_exception'): return False
        # Construction is admitted by its explicit frozen construction status;
        # solve rows additionally require the out-of-band Decimal80 acceptance.
        if mode in ('cpu_spai', 'gpu_spai'): return x.get('construction_status') == 'success'
        if mode in ('cpu_gmres_fixed','gpu_gmres_fixed'):
            return x.get('independent_decimal80_gmres', {}).get('accepts_frozen_gmres_tolerance') is True
        return x.get('independent_decimal80', {}).get('accepts_frozen_backward_error') is True
    values = [x['elapsed_ms'] for x in samples if accepted(x)]
    if not values: return {'completed_trials':0}
    values.sort(); mean=statistics.fmean(values); std=statistics.stdev(values) if len(values)>1 else 0.0
    half=len(values)//2; lower=values[:half]; upper=values[-half:] if half else values
    return {'completed_trials':len(values),'minimum_ms':values[0],'median_ms':statistics.median(values),'mean_ms':mean,'stddev_ms':std,'iqr_ms':statistics.median(upper)-statistics.median(lower)}

def svg_bar(path, title, rows, value_key):
    # Dependency-free static SVG, deliberately retaining GPU-slower bars.
    width, height, left, top = 1200, 700, 180, 80; maxv=max((r.get(value_key,0) for r in rows), default=1) or 1
    pieces=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}"><style>text{{font-family:Arial;font-size:13px}} .c{{fill:#356ae6}} .g{{fill:#e87125}}</style><text x="20" y="30" font-size="20">{title}</text>']
    for i,r in enumerate(rows):
        y=top+i*42; c='#356ae6' if r['backend']=='cpu' else '#e87125'; w=900*r.get(value_key,0)/maxv
        pieces.append(f'<text x="10" y="{y+16}">{r["label"]}</text><rect x="{left}" y="{y}" width="{w}" height="24" fill="{c}"/><text x="{left+w+5}" y="{y+16}">{r.get(value_key,0):.4g} ms</text>')
    pieces.append('</svg>'); Path(path).write_text(''.join(pieces), encoding='utf-8')

def main():
    p=argparse.ArgumentParser(); p.add_argument('--runner', required=True); p.add_argument('--output-dir', required=True); p.add_argument('--manifest', default='benchmarks/stage45b_cases.json'); p.add_argument('--root', default='.'); p.add_argument('--expensive-trials', type=int, default=3); p.add_argument('--timeout-seconds', type=int, default=300); p.add_argument('--only', nargs='*',help='deprecated alias for --cases'); p.add_argument('--cases',nargs='+',help='run exactly these manifest case ids'); p.add_argument('--resume',action='store_true'); args=p.parse_args()
    if args.only is not None and args.cases is not None: p.error('use only one of --only or --cases')
    selected_cases = set(args.cases if args.cases is not None else (args.only or []))
    root=Path(args.root).resolve(); output=(root/args.output_dir).resolve();
    if output.exists() and not args.resume: raise SystemExit('refusing to overwrite existing output directory: '+str(output))
    output.mkdir(parents=True,exist_ok=True); (output/'fixed_p').mkdir(exist_ok=True)
    # One root-level atomic lock is shared with the scalability launcher, so a
    # different output directory cannot accidentally authorize overlap.
    experiment_lock=ExperimentLock(root/'results',Path(__file__).resolve(),output).acquire()
    completion_status='interrupted_unclassified'
    atexit.register(lambda: experiment_lock.release(completion_status))
    progress=output/'PROGRESS.jsonl'
    def log(event, **fields):
        with progress.open('a',encoding='utf-8',newline='\n') as f:
            f.write(json.dumps(dict(event=event,unix=time.time(),**fields),separators=(',',':'))+'\n'); f.flush(); os.fsync(f.fileno())
    decimal.getcontext().prec=80
    manifest=json.loads((root/args.manifest).read_text(encoding='utf-8'))
    known_cases={case['id'] for case in manifest['cases']}
    unknown=selected_cases-known_cases
    if unknown: raise SystemExit('unknown manifest case id(s): '+', '.join(sorted(unknown)))
    all_summary=[]; run_meta={'schema_version':1,'stage':'4.5B exploratory','runner':str(Path(args.runner).resolve()),'runner_sha256':sha(args.runner),'warmups':3,'inexpensive_trials':10,'expensive_trials':args.expensive_trials,'configuration_timeout_seconds':args.timeout_seconds,'selected_cases':sorted(selected_cases) if selected_cases else 'all','started_unix':time.time(),'notes':'No outlier removal. Fixed-P files are prepared once on CPU outside timed calls and reused verbatim by CPU/GPU GMRES.'}
    if not (output/'RUN_MANIFEST.json').exists(): (output/'RUN_MANIFEST.json').write_text(json.dumps(run_meta,indent=2),encoding='utf-8')
    log('runner_started',resume=args.resume)
    base_modes=['cpu_spai','gpu_spai','cpu_gmres_fixed','gpu_gmres_fixed','cpu_pipeline','gpu_pipeline']
    for case_index, case in enumerate(manifest['cases']):
        if selected_cases and case['id'] not in selected_cases: continue
        matrix=(root/case['matrix']).resolve(); n,m,a=load_mm(matrix); b=rhs(a,n,case['rhs']); trials=args.expensive_trials if case['tier']=='expensive' else 10
        common=['--matrix',str(matrix),'--rhs',case['rhs'],'--epsilon','0.3','--alpha',str(case['alpha']),'--beta','8','--innercap',str(case['innercap']),'--outercap',str(case['outercap']),'--warmups','3','--trials',str(trials)]
        pfile=output/'fixed_p'/(case['id']+'.mtx'); prep=[args.runner,'--mode','prepare_fixed_p',*common,'--p-output',str(pfile)]
        try:
            if args.resume and (output/(case['id']+'_fixed_p_preparation.jsonl')).exists() and pfile.exists():
                records=[json.loads(x) for x in (output/(case['id']+'_fixed_p_preparation.jsonl')).read_text(encoding='utf-8').splitlines() if x]
                cp=type('Completed',(),{'returncode':0})()
                log('preparation_reused',case=case['id'])
            else:
                log('preparation_started',case=case['id']); cp,records=run(prep,args.timeout_seconds)
                (output/(case['id']+'_fixed_p_preparation.jsonl')).write_text('\n'.join(json.dumps(x,separators=(',',':')) for x in records)+'\n',encoding='utf-8'); log('preparation_finished',case=case['id'],returncode=cp.returncode)
            prep_ok = bool(records) and records[-1].get('construction_status') == 'success'
            if cp.returncode or not pfile.exists() or not prep_ok:
                # A fixed-P comparison is invalid without the single canonical file.
                # Preserve preparation evidence and leave this case unbenchmarked.
                continue
        except subprocess.TimeoutExpired:
            (output/(case['id']+'_fixed_p_preparation.jsonl')).write_text(json.dumps({'event':'resource_abort','substatus':'watchdog_timeout'})+'\n',encoding='utf-8'); continue
        # Deterministic pair order alternates by case.  It does not discard or
        # reorder samples inside a configuration, and is recorded per artifact.
        modes = base_modes if case_index % 2 == 0 else ['gpu_spai','cpu_spai','gpu_gmres_fixed','cpu_gmres_fixed','gpu_pipeline','cpu_pipeline']
        for mode in modes:
            command=[args.runner,'--mode',mode,*common]
            if mode.endswith('_fixed'): command += ['--p',str(pfile)]
            artifact=output/(case['id']+'_'+mode+'.jsonl'); wrapper={'event':'artifact_manifest','matrix_sha256':sha(matrix),'matrix':str(matrix),'case':case,'command':command,'runner_sha256':sha(args.runner),'fixed_p_sha256':sha(pfile) if mode.endswith('_fixed') else None,'pair_order':'cpu_first' if case_index % 2 == 0 else 'gpu_first','records':[]}
            if args.resume and artifact.exists():
                log('configuration_reused',case=case['id'],mode=mode)
                continue
            try:
                log('configuration_started',case=case['id'],mode=mode)
                cp, records=run(command,args.timeout_seconds); wrapper.update(returncode=cp.returncode,stdout_unparsed=[x for x in cp.stdout.splitlines() if not x.startswith('{')],stderr=cp.stderr)
            except subprocess.TimeoutExpired as e:
                records=[{'schema_version':1,'event':'resource_abort','substatus':'watchdog_timeout','message':'predeclared 300-second configuration watchdog'}]; wrapper.update(returncode=None,stderr=str(e))
            for record in records:
                if record.get('event')=='sample' and record.get('converged') and record.get('solution'):
                    # Independent Decimal80 check occurs after the timed public call.
                    record['independent_decimal80']=decimal_diagnostics(a,b,record['solution'])
                    if mode.endswith('_fixed'):
                        _,_,fixed=load_mm(pfile); record['independent_decimal80_gmres']=decimal_fixed_gmres(a,fixed,b,record['solution'])
                wrapper['records'].append(record)
            artifact.write_text('\n'.join(json.dumps(x,allow_nan=False,separators=(',',':')) for x in [dict(wrapper,records=None), *wrapper['records']])+'\n',encoding='utf-8')
            log('configuration_finished',case=case['id'],mode=mode,returncode=wrapper.get('returncode'))
            s=summary(wrapper['records'], mode); s.update(case=case['id'],mode=mode,rows=n,nnz=len(a),matrix_sha256=wrapper['matrix_sha256']); all_summary.append(s)
    # Pair only completed configurations; never manufacture a speedup for a failure.
    index={(r['case'],r['mode']):r for r in all_summary}
    for r in all_summary:
        paired={'cpu_spai':'gpu_spai','cpu_gmres_fixed':'gpu_gmres_fixed','cpu_pipeline':'gpu_pipeline'}
        if r['mode'] in paired:
            other=index.get((r['case'],paired[r['mode']]))
            if r.get('completed_trials') and other and other.get('completed_trials'):
                r['gpu_speedup_cpu_over_gpu']=r['median_ms']/other['median_ms']
    (output/'SUMMARY.json').write_text(json.dumps(all_summary,indent=2),encoding='utf-8')
    completion_status='completed'
    for prefix,title,file in [('spai','CPU vs GPU SPAI construction median','spai_construction.svg'),('gmres','CPU vs GPU fixed-P GMRES median','fixed_p_gmres.svg'),('pipeline','CPU vs GPU full pipeline median','full_pipeline.svg')]:
        subset=[]
        for r in all_summary:
            if (prefix=='spai' and r['mode'] in ('cpu_spai','gpu_spai')) or (prefix=='gmres' and r['mode'] in ('cpu_gmres_fixed','gpu_gmres_fixed')) or (prefix=='pipeline' and r['mode'] in ('cpu_pipeline','gpu_pipeline')):
                subset.append({'label':r['case']+' '+r['mode'].replace('_',' '),'backend':'gpu' if r['mode'].startswith('gpu') else 'cpu',**r})
        svg_bar(output/file,title,subset,'median_ms')
    speed=[]
    for r in all_summary:
        if r['mode']=='cpu_pipeline' and 'gpu_speedup_cpu_over_gpu' in r: speed.append({'label':r['case']+' n='+str(r['rows']),'backend':'gpu','median_ms':r['gpu_speedup_cpu_over_gpu']})
    svg_bar(output/'speedup_vs_dimension.svg','Full-pipeline CPU/GPU speedup (CPU median / GPU median)',speed,'median_ms')
if __name__=='__main__': main()
