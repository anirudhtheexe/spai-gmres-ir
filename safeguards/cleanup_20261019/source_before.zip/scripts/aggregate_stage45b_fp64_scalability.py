"""Create additive summaries and static SVG plots for FP64 scaling evidence.

This reporting tool never executes a solver or changes raw JSONL.  It accepts
partial campaigns: resource aborts and incomplete six-mode sets remain in the
machine-readable output and are omitted only from pairwise speedup arithmetic.
"""
import argparse
import json
from pathlib import Path
from xml.sax.saxutils import escape

MODES = ("cpu_spai", "gpu_spai", "cpu_gmres_fixed", "gpu_gmres_fixed", "cpu_pipeline", "gpu_pipeline")


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def plot_pairs(path, title, rows, unit="ms"):
    width, left, right, top, row_h = 1400, 240, 220, 105, 55
    height = top + max(1, len(rows)) * row_h + 85
    maximum = max((max(r["cpu"], r["gpu"]) for r in rows), default=1.0) or 1.0
    span = width - left - right
    p = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (width, height),
         '<style>text{font-family:Arial,sans-serif;fill:#111}.t{font-size:22px;font-weight:bold}.l{font-size:13px}.v{font-size:12px}.cpu{fill:#356ae6}.gpu{fill:#e87125}.g{stroke:#ddd}</style>',
         '<text class="t" x="20" y="35">%s</text>' % escape(title),
         '<rect class="cpu" x="%d" y="58" width="18" height="14"/><text class="l" x="%d" y="70">CPU</text><rect class="gpu" x="%d" y="58" width="18" height="14"/><text class="l" x="%d" y="70">GPU</text>' % (left, left+24, left+90, left+114)]
    for tick in range(6):
        x = left + span * tick / 5.0; p.append('<line class="g" x1="%.1f" y1="%d" x2="%.1f" y2="%d"/><text class="v" x="%.1f" y="%d" text-anchor="middle">%.4g</text>' % (x, top-5, x, height-38, x, height-18, maximum*tick/5.0))
    for i, row in enumerate(rows):
        y = top + i * row_h
        p.append('<text class="l" x="8" y="%d">%s n=%s</text>' % (y+24, escape(row["case"]), row["rows"]))
        for offset, klass, value in ((0, "cpu", row["cpu"]), (20, "gpu", row["gpu"])):
            bar = span * value / maximum
            p.append('<rect class="%s" x="%d" y="%d" width="%.3f" height="15"/><text class="v" x="%.3f" y="%d">%.6g %s</text>' % (klass, left, y+offset, bar, left+bar+4, y+offset+12, value, unit))
    p.append('</svg>'); Path(path).write_text("\n".join(p), encoding="utf-8")


def plot_scalar(path, title, rows, field, unit):
    width, height, left, right, top, bottom = 1400, 720, 120, 130, 90, 105
    maximum = max([1.0] + [r[field] for r in rows]) * 1.08; span = width-left-right; rise = height-top-bottom
    p = ['<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d">' % (width,height),
         '<style>text{font-family:Arial,sans-serif;fill:#111}.t{font-size:22px;font-weight:bold}.l{font-size:12px}.p{fill:#e87125}.g{stroke:#ddd}.b{stroke:#333;stroke-width:1.5}</style>', '<text class="t" x="20" y="35">%s</text>' % escape(title)]
    for tick in range(6):
        value=maximum*tick/5.; y=top+rise*(1-value/maximum)
        p.append('<line class="g" x1="%d" y1="%.1f" x2="%d" y2="%.1f"/><text class="l" x="%d" y="%.1f" text-anchor="end">%.4g</text>' % (left,y,width-right,y,left-8,y+4,value))
    for i,row in enumerate(rows):
        x=left+span*(i+.5)/max(1,len(rows)); y=top+rise*(1-row[field]/maximum)
        p.append('<circle class="p" cx="%.1f" cy="%.1f" r="5"/><text class="l" transform="translate(%.1f,%d) rotate(45)">%s n=%s</text>' % (x,y,x-4,height-bottom+20,escape(row["case"]),row["rows"]))
    p.append('</svg>'); Path(path).write_text("\n".join(p), encoding="utf-8")


def raw_gpu_memory(directory, entry):
    raw = directory / entry["raw_artifact"]
    values=[]
    for line in raw.read_text(encoding="utf-8").splitlines()[1:]:
        rec=json.loads(line)
        if rec.get("phase")=="measured" and rec.get("gpu_spai_peak_device_bytes") is not None:
            values.append(rec["gpu_spai_peak_device_bytes"])
    return max(values) if values else None


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--campaign-dir",required=True); p.add_argument("--output-dir",required=True); args=p.parse_args()
    source=Path(args.campaign_dir).resolve(); out=Path(args.output_dir).resolve(); out.mkdir(parents=True,exist_ok=False)
    summary_path=source/"SUMMARY_REASSESSED.json"
    if not summary_path.is_file(): raise FileNotFoundError("run postprocess_stage45b_exploratory.py first: "+str(summary_path))
    reassessed=load(summary_path); index={(r["case"],r["mode"]):r for r in reassessed}
    raw_summary=load(source/"SUMMARY.json") if (source/"SUMMARY.json").is_file() else []
    cases=sorted({r["case"] for r in reassessed}, key=lambda c: (index[(c,next(m for m in MODES if (c,m) in index))]["rows"],c))
    records=[]; paired=[]
    for case in cases:
        modes={m:index[(case,m)] for m in MODES if (case,m) in index}
        entry={"case":case,"modes":modes,"complete_modes":len(modes)==len(MODES)}
        if entry["complete_modes"]:
            entry["spai_cpu_over_gpu"]=modes["cpu_spai"].get("median_ms",0)/modes["gpu_spai"].get("median_ms",1) if modes["gpu_spai"].get("completed_trials") else None
            entry["fixed_gmres_cpu_over_gpu"]=modes["cpu_gmres_fixed"].get("median_ms",0)/modes["gpu_gmres_fixed"].get("median_ms",1) if modes["gpu_gmres_fixed"].get("completed_trials") else None
            entry["pipeline_cpu_over_gpu"]=modes["cpu_pipeline"].get("median_ms",0)/modes["gpu_pipeline"].get("median_ms",1) if modes["gpu_pipeline"].get("completed_trials") else None
            entry["gpu_spai_peak_device_bytes"]=raw_gpu_memory(source,modes["gpu_spai"])
            if all(modes[x].get("completed_trials") for x in MODES): paired.append(entry)
        records.append(entry)
    report={"schema_version":1,"purpose":"additive Stage 4.5B FP64 scalability aggregation","campaign":str(source),"records":records,"raw_summary":raw_summary,
            "notes":["Only complete independently reassessed CPU/GPU pairs receive a ratio.","GPU memory is source-issued GPU-SPAI peak allocation, vendor internal allocations excluded.","No runtime host-memory peak is available from the frozen stage45b harness; preflight snapshots are retained separately."]}
    (out/"SCALABILITY_SUMMARY.json").write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    def pairs(cpu,gpu): return [{"case":r["case"],"rows":r["modes"][cpu]["rows"],"cpu":r["modes"][cpu]["median_ms"],"gpu":r["modes"][gpu]["median_ms"]} for r in paired]
    plot_pairs(out/"spai_construction_vs_dimension.svg","CPU vs GPU SPAI construction median time",pairs("cpu_spai","gpu_spai"))
    plot_pairs(out/"fixed_p_gmres_vs_dimension.svg","CPU vs GPU fixed-P GMRES median time",pairs("cpu_gmres_fixed","gpu_gmres_fixed"))
    plot_pairs(out/"full_pipeline_vs_dimension.svg","CPU vs GPU native full-pipeline median time",pairs("cpu_pipeline","gpu_pipeline"))
    plot_scalar(out/"pipeline_speedup_vs_dimension.svg","Native full-pipeline CPU/GPU median ratio",[{"case":r["case"],"rows":r["modes"]["cpu_pipeline"]["rows"],"ratio":r["pipeline_cpu_over_gpu"]} for r in paired if r["pipeline_cpu_over_gpu"] is not None],"ratio","ratio")
    plot_scalar(out/"gpu_spai_memory_vs_dimension.svg","GPU SPAI source-allocation peak vs dimension",[{"case":r["case"],"rows":r["modes"]["gpu_spai"]["rows"],"bytes":r["gpu_spai_peak_device_bytes"]} for r in paired if r["gpu_spai_peak_device_bytes"] is not None],"bytes","bytes")
    print("cases=%d; complete_pairs=%d; output=%s" % (len(cases),len(paired),out))


if __name__=="__main__": main()
