"""Run exactly one root-locked Nsight Systems CUDA-SPAI diagnostic trace.

This is not a timing benchmark.  It preserves Nsight's report plus a durable
JSON manifest so a trace can be audited without relying on console output.
"""

import argparse
import json
from pathlib import Path
import subprocess
import time

from benchmark_experiment_lock import ExperimentLock


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=".")
    parser.add_argument("--nsys", required=True)
    parser.add_argument("--runner", required=True)
    parser.add_argument("--matrix", required=True)
    parser.add_argument("--precision", choices=("fp32", "fp64"), required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    parser.add_argument("--direct", action="store_true",
                        help="run one locked diagnostic harness invocation without Nsight")
    args = parser.parse_args()
    if args.timeout_seconds <= 0:
        parser.error("timeout-seconds must be positive")

    root = Path(args.root).resolve()
    output = (root / args.output_dir).resolve()
    if output.exists():
        raise SystemExit("refusing to overwrite trace output: " + str(output))
    output.mkdir(parents=True)
    report = output / ("stencil_8192_" + args.precision)
    runner = Path(args.runner).resolve()
    matrix = Path(args.matrix).resolve()
    harness = [str(runner), "--mode", "gpu_spai", "--matrix", str(matrix), "--rhs", "periodic7",
               "--epsilon", "0.3", "--alpha", "1024", "--beta", "8", "--innercap", "8192",
               "--outercap", "20", "--warmups", "1", "--trials", "1"]
    command = harness if args.direct else [str(Path(args.nsys).resolve()), "profile", "--force-overwrite", "true",
               "--trace", "cuda,cublas,cusolver", "--sample", "none", "--output", str(report), *harness]
    lock = ExperimentLock(root / "results", Path(__file__).resolve(), output).acquire()
    outcome = None
    try:
        started = time.time()
        child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        lock.update(active_case="stencil_8192", active_mode=args.precision + ":nsys_gpu_spai",
                    child_pid=child.pid, child_started_unix=started)
        try:
            stdout, stderr = child.communicate(timeout=args.timeout_seconds)
            outcome = {"status": "completed" if child.returncode == 0 else "process_exit_nonzero",
                       "pid": child.pid, "started_unix": started, "completed_unix": time.time(),
                       "returncode": child.returncode, "watchdog_timeout": False}
        except subprocess.TimeoutExpired:
            child.kill()
            stdout, stderr = child.communicate()
            outcome = {"status": "watchdog_timeout", "pid": child.pid, "started_unix": started,
                       "completed_unix": time.time(), "returncode": child.returncode,
                       "watchdog_timeout": True}
        (output / "MANIFEST.json").write_text(json.dumps({
            "schema_version": 1, "purpose": "Experiment 2A diagnostic constructor observation, not timing evidence",
            "precision": args.precision, "command": command, "matrix": str(matrix), "process": outcome,
            "stdout": stdout, "stderr": stderr, "report_basename": str(report),
            "sequential_child_only": True, "direct_harness": args.direct,
        }, indent=2) + "\n", encoding="utf-8")
        if outcome["returncode"] != 0:
            raise SystemExit(outcome["returncode"] or 1)
    finally:
        lock.update(child_pid=None, child_started_unix=None, last_exit=outcome)
        lock.release("completed" if outcome and outcome.get("returncode") == 0 else "failed")


if __name__ == "__main__":
    main()
