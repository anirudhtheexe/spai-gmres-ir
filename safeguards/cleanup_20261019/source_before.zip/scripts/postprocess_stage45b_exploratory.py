"""Reassess retained Stage 4.5B raw artifacts without rerunning samples.

Creates additive *.assessment.json sidecars and SUMMARY_REASSESSED.json.  Raw
JSONL timing records are read-only evidence and are never rewritten.
"""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_stage45b_exploratory as bench

def main():
    p=argparse.ArgumentParser(); p.add_argument('--output-dir',required=True); args=p.parse_args()
    out=Path(args.output_dir).resolve(); bench.decimal.getcontext().prec=80; summaries=[]
    for artifact in sorted(out.glob('*_*.jsonl')):
        if artifact.name.endswith('_fixed_p_preparation.jsonl'): continue
        rows=[json.loads(x) for x in artifact.read_text(encoding='utf-8').splitlines() if x]
        if not rows or rows[0].get('event')!='artifact_manifest': continue
        meta=rows[0]; records=rows[1:]; mode=meta['case'].get('id') and artifact.stem[len(meta['case']['id'])+1:]
        matrix=Path(meta['matrix']); n,_,a=bench.load_mm(matrix); b=bench.rhs(a,n,meta['case']['rhs']); fixed=None
        if mode.endswith('_fixed'):
            pfile=out/'fixed_p'/(meta['case']['id']+'.mtx');
            if pfile.exists(): _,_,fixed=bench.load_mm(pfile)
        assessed=[]
        for r in records:
            entry={'ordinal':r.get('ordinal'),'phase':r.get('phase'),'status':r.get('status'),'converged':r.get('converged')}
            if r.get('event')=='sample' and r.get('converged') and r.get('solution'):
                entry['independent_decimal80']=bench.decimal_diagnostics(a,b,r['solution'])
                r['independent_decimal80']=entry['independent_decimal80']
                if fixed is not None:
                    entry['independent_decimal80_gmres']=bench.decimal_fixed_gmres(a,fixed,b,r['solution'])
                    r['independent_decimal80_gmres']=entry['independent_decimal80_gmres']
            assessed.append(entry)
        sidecar=artifact.with_suffix('.assessment.json')
        sidecar.write_text(json.dumps({'artifact':artifact.name,'raw_sha256':bench.sha(artifact),'assessment_schema':1,'records':assessed},indent=2),encoding='utf-8')
        s=bench.summary(records,mode); s.update(case=meta['case']['id'],mode=mode,rows=n,nnz=len(a),raw_artifact=artifact.name,assessment_artifact=sidecar.name); summaries.append(s)
    index={(x['case'],x['mode']):x for x in summaries}
    for x in summaries:
        pair={'cpu_spai':'gpu_spai','cpu_gmres_fixed':'gpu_gmres_fixed','cpu_pipeline':'gpu_pipeline'}.get(x['mode'])
        y=index.get((x['case'],pair)) if pair else None
        if y and x.get('completed_trials') and y.get('completed_trials'): x['gpu_speedup_cpu_over_gpu']=x['median_ms']/y['median_ms']
    (out/'SUMMARY_REASSESSED.json').write_text(json.dumps(summaries,indent=2),encoding='utf-8')
    print(f'assessed_artifacts={len(summaries)}; output={out / "SUMMARY_REASSESSED.json"}')
if __name__=='__main__': main()
