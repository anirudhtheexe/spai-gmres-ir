"""Strictly serial Experiment 2A FP32/FP64 timing launcher.

It owns the existing root-level experiment lock and starts exactly one child at
a time.  Numerical checking is a separate, snapshot-only child started only
after a timed harness child exits and its JSONL artifact is durable.
"""
import argparse
import atexit
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from benchmark_experiment_lock import ExperimentLock

CASES = (
    ("stencil_8192", "data/stage45b_fp64_scalability_v1/stencil_8192.mtx"),
    ("irregular_8192", "data/stage45b_fp64_scalability_v1/irregular_8192.mtx"),
    ("stencil_12000", "data/stage45b_fp64_12000_v1/stencil_12000.mtx"),
    ("irregular_12000", "data/stage45b_fp64_12000_v1/irregular_12000.mtx"),
)
MODES = ("cpu_spai", "gpu_spai", "cpu_gmres_fixed", "gpu_gmres_fixed", "cpu_pipeline", "gpu_pipeline")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_dimension(path):
    with Path(path).open(encoding="utf-8-sig") as source:
        for line in source:
            if line and not line.startswith("%"): 
                n, m, _ = map(int, line.split())
                if n != m or not n:
                    raise ValueError("expected nonempty square Matrix Market input: " + str(path))
                return n
    raise ValueError("missing Matrix Market dimensions: " + str(path))


def write_jsonl_new(path, records):
    with Path(path).open("x", encoding="utf-8", newline="\n") as out:
        for record in records:
            out.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
        out.flush()
        os.fsync(out.fileno())


def parse_records(stdout):
    records = []
    ignored = []
    for line in stdout.splitlines():
        if not line.startswith("{"):
            ignored.append(line)
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError:
            ignored.append(line)
    return records, ignored


def run_one(command, timeout, lock, case, precision, mode):
    """Run one child synchronously; there are deliberately no sampler threads."""
    started = time.time()
    child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    lock.update(active_case=case, active_mode=precision + ":" + mode,
                child_pid=child.pid, child_started_unix=started, last_exit=None)
    try:
        stdout, stderr = child.communicate(timeout=timeout)
        outcome = {"status": "completed" if child.returncode == 0 else "process_exit_nonzero",
                   "pid": child.pid, "started_unix": started, "completed_unix": time.time(),
                   "returncode": child.returncode, "watchdog_timeout": False}
        return child.returncode, stdout, stderr, outcome
    except subprocess.TimeoutExpired:
        child.kill()
        stdout, stderr = child.communicate()
        outcome = {"status": "watchdog_timeout", "pid": child.pid, "started_unix": started,
                   "completed_unix": time.time(), "returncode": child.returncode, "watchdog_timeout": True}
        return None, stdout or "", stderr or "", outcome
    finally:
        lock.update(child_pid=None, child_started_unix=None, last_exit=outcome)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fp32-runner", required=True)
    parser.add_argument("--fp64-runner", required=True)
    parser.add_argument("--checker", required=True,
                        help="snapshot-only checker; receives --artifact --matrix --precision --mode [--fixed-p]")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--root", default=".")
    parser.add_argument("--timeout-seconds", type=int, default=1800)
    parser.add_argument("--cases", nargs="+", choices=[case[0] for case in CASES])
    args = parser.parse_args()
    if args.timeout_seconds <= 0:
        parser.error("--timeout-seconds must be positive")
    root = Path(args.root).resolve()
    output = (root / args.output_dir).resolve()
    if output.exists():
        raise SystemExit("refusing to overwrite evidence directory: " + str(output))
    output.mkdir(parents=True)
    (output / "fixed_p").mkdir()
    selected = set(args.cases or [case[0] for case in CASES])
    lock = ExperimentLock(root / "results", Path(__file__).resolve(), output).acquire()
    status = "interrupted_unclassified"
    atexit.register(lambda: lock.release(status))
    manifest = {"schema_version": 1, "experiment": "Experiment 2A FP32 vs FP64 timing",
                "started_unix": time.time(), "sequential": True, "exclusive_lock": str(lock.path),
                "warmups": 3, "measured_trials": 3, "timing_boundary": "one frozen public API call; GPU synchronizes immediately before and after",
                "precision_contracts": {"fp32": {"epsilon": .3, "beta": 8, "gmres_tolerance": 1e-4, "outer_be": "10*2^-24"},
                                        "fp64": {"epsilon": .3, "beta": 8, "gmres_tolerance": 1e-8, "outer_be": "10*2^-53"}},
                "runners": {"fp32": str(Path(args.fp32_runner).resolve()), "fp64": str(Path(args.fp64_runner).resolve())},
                "runner_sha256": {"fp32": sha(args.fp32_runner), "fp64": sha(args.fp64_runner)},
                "checker": str(Path(args.checker).resolve()), "checker_sha256": sha(args.checker),
                "notes": "One solver child at a time. P preparation is untimed. Every raw artifact is retained; the checker is snapshot-only and starts after the solver child terminates."}
    (output / "RUN_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    progress = output / "PROGRESS.jsonl"
    def log(event, **fields):
        with progress.open("a", encoding="utf-8", newline="\n") as out:
            out.write(json.dumps(dict(event=event, unix=time.time(), **fields), separators=(",", ":")) + "\n")
            out.flush(); os.fsync(out.fileno())
    summary = []
    for case, relative_matrix in CASES:
        if case not in selected:
            continue
        matrix = (root / relative_matrix).resolve()
        n = load_dimension(matrix)
        for precision, runner, tau in (("fp32", args.fp32_runner, "1e-4"), ("fp64", args.fp64_runner, "1e-8")):
            common = ["--matrix", str(matrix), "--rhs", "periodic7", "--epsilon", "0.3", "--alpha", str((n + 7) // 8),
                      "--beta", "8", "--innercap", str(n), "--outercap", "20", "--warmups", "3", "--trials", "3"]
            fixed_p = output / "fixed_p" / (case + "_" + precision + ".mtx")
            prepare = [runner, "--mode", "prepare_fixed_p", *common, "--p-output", str(fixed_p)]
            log("preparation_started", case=case, precision=precision)
            rc, stdout, stderr, process = run_one(prepare, args.timeout_seconds, lock, case, precision, "prepare_fixed_p")
            prep_records, ignored = parse_records(stdout)
            prep_path = output / (case + "_" + precision + "_fixed_p_preparation.jsonl")
            write_jsonl_new(prep_path, [{"event": "artifact_manifest", "command": prepare, "returncode": rc, "stderr": stderr, "process": process, "stdout_ignored": ignored}, *prep_records])
            prepared = rc == 0 and fixed_p.exists() and bool(prep_records) and prep_records[-1].get("construction_status") == "success"
            log("preparation_finished", case=case, precision=precision, returncode=rc, prepared=prepared)
            if not prepared:
                summary.append({"case": case, "precision": precision, "classification": "fixed_p_preparation_failure", "artifact": prep_path.name})
                continue
            for mode in MODES:
                command = [runner, "--mode", mode, *common]
                if mode.endswith("_fixed"):
                    command += ["--p", str(fixed_p)]
                log("configuration_started", case=case, precision=precision, mode=mode)
                rc, stdout, stderr, process = run_one(command, args.timeout_seconds, lock, case, precision, mode)
                records, ignored = parse_records(stdout)
                artifact = output / (case + "_" + precision + "_" + mode + ".jsonl")
                wrapper = {"event": "artifact_manifest", "case": case, "precision": precision, "mode": mode,
                           "matrix": str(matrix), "matrix_sha256": sha(matrix), "fixed_p": str(fixed_p) if mode.endswith("_fixed") else None,
                           "fixed_p_sha256": sha(fixed_p) if mode.endswith("_fixed") else None, "command": command,
                           "returncode": rc, "stderr": stderr, "stdout_ignored": ignored, "process": process}
                write_jsonl_new(artifact, [wrapper, *records] if records else [wrapper, {"event": "process_termination_unclassified", "process": process}])
                # This is explicitly out of the timed child and never launches a solver.
                check = [sys.executable, args.checker, "--artifact", str(artifact), "--matrix", str(matrix),
                         "--precision", precision, "--mode", mode]
                if mode.endswith("_fixed"):
                    check += ["--fixed-p", str(fixed_p), "--gmres-tolerance", tau]
                log("snapshot_check_started", case=case, precision=precision, mode=mode)
                check_rc, check_out, check_err, check_process = run_one(check, args.timeout_seconds, lock, case, precision, "snapshot_check:" + mode)
                check_records, check_ignored = parse_records(check_out)
                check_path = output / (case + "_" + precision + "_" + mode + "_decimal80.jsonl")
                write_jsonl_new(check_path, [{"event": "checker_manifest", "command": check, "returncode": check_rc, "stderr": check_err, "stdout_ignored": check_ignored, "process": check_process}, *check_records])
                accepted = check_rc == 0
                summary.append({"case": case, "precision": precision, "mode": mode, "raw_artifact": artifact.name,
                                "decimal80_artifact": check_path.name, "solver_returncode": rc, "checker_returncode": check_rc,
                                "accepted": accepted})
                log("configuration_finished", case=case, precision=precision, mode=mode, solver_returncode=rc, checker_returncode=check_rc)
                if accepted:
                    lock.update(last_successful_configuration={"case": case, "precision": precision, "mode": mode, "completed_unix": time.time()})
    (output / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    status = "completed"
    print(json.dumps({"output": str(output), "summary_records": len(summary)}))


if __name__ == "__main__":
    main()
