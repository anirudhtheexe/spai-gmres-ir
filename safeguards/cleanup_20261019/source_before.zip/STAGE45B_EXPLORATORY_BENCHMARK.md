# Stage 4.5B exploratory CPU/GPU benchmark

**Date:** 11 October 2026  
**Scope:** first host-wall-clock baseline for the frozen uniform-binary64 SPAI--GMRES--IR implementation. These are exploratory engineering measurements, not publication-ready performance claims, a mixed-precision reproduction, or an optimization study.

## Status and admission qualification

CUDA Release remains numerically admitted (CTest 5/5 plus the recorded Decimal checks). MSVC CPU Release is **not fully admitted**: its unchanged CTest result is 1/4 because the three suites require a wider built-in `long double` oracle that MSVC does not provide. The test-only Decimal80 snapshot path passes 16 snapshots / 500 checks, but does not replace every historical wider-oracle branch. This limitation is retained in every CPU/GPU comparison below; it is why these results must not be treated as publication-ready.

All selected timed solver samples were checked outside the timed interval. Fixed-`P` GMRES uses the exact same CPU-prepared `P` for CPU and GPU, and independently accepts only when Decimal80 recomputation gives `||P(b-Ax)||_2 / ||Pb||_2 <= 1e-8`. Native pipelines construct their own preconditioners and are accepted only when independently recomputed Decimal80 normwise backward error is at most `10u`. Native pipeline speedups are therefore workload-dependent, not equal-work comparisons.

## Environment and method

| Item | Recorded value |
|---|---|
| Host CPU | AMD Ryzen 7 7745HX, 8 cores / 16 logical processors |
| GPU | NVIDIA GeForce RTX 4060 Laptop GPU, 8,588,521,600 bytes (8 GiB reported) |
| OS / power plan | Windows 11 Home Single Language 10.0.26200 / Legion Balance Mode |
| Driver / toolkit | NVIDIA 616.92 / CUDA 13.4.59 |
| CPU build | MSVC 19.44.35228, `/O2 /Ob2 /DNDEBUG /fp:strict` |
| CUDA build | CUDA Release, SM 89, `--fmad=false`, `CUBLAS_EMULATE_DOUBLE_PRECISION=0` |
| CPU threading / BLAS | One benchmark process; the reference implementation does not link an external BLAS library. No BLAS threading is used. |
| GPU state sampled after campaign | P8, graphics/memory clocks 210/405 MHz, 51 C; `nvidia-smi` power-management query was deprecated and did not expose a power limit. |

The harness (`tests/stage45b_benchmark.cpp`) times only the frozen public API call with `std::chrono::steady_clock`; CUDA modes call `cudaDeviceSynchronize` immediately before and after that call. Thus allocations, transfers, host processing, synchronization, and cleanup observable through the public API are included. JSON serialization, independent checks, and memory queries are outside the interval. No component-level transfer/setup split was externally observable without altering the frozen call boundary.

Each inexpensive case used 3 warm-ups and 10 measured trials. `orsreg_1`, `sherman5`, `add32`, and the two 1024-dimensional synthetic cases used the predeclared 3 warm-ups and 3 measured trials. The per-configuration watchdog was 300 s. No unfavorable sample or failure was discarded.

## Inputs and retained records

The matrix/RHS/settings provenance is retained in each JSONL manifest. Application matrices are the Stage 4.5A provenance copies; synthetic inputs are deterministic stencil/irregular generators. Frozen settings are epsilon 0.3, beta 8, alpha `ceil(n/8)`, inner cap `n`, outer cap 20; application RHS is `equal_unit2`, synthetic RHS is `periodic7`.

Two campaigns contribute selected records:

- [original campaign raw records](results/stage45b_exploratory_20261011/) supplies complete six-mode sets for `cage5`, `gre_115`, `pores_3`, `steam1`, `saylr1`, `sherman4`, `orsreg_1`, and `sherman5`.
- [clean single-run continuation](results/stage45b_add32_synthetic_continuation_20261011/) supplies complete six-mode sets for `add32`, `stencil_256`, `stencil_1024`, `irregular_256`, and `irregular_1024`.

An early resume mechanism permitted overlapping runs. The raw evidence is retained, but all original-campaign `add32` pipeline records and all original synthetic records are explicitly excluded from summaries and plots. The continuation used an atomic `RUN_LOCK.json` and has one sequential, non-resumed runner: all 30 modes returned zero. The independent validator accepted its timing boundary, `P` hashes, status, and Decimal80 evidence.

The authoritative machine-readable aggregation is [SELECTED_SUMMARY.json](results/stage45b_selected_aggregation_20261011/SELECTED_SUMMARY.json). It contains all **78** selected CPU/GPU mode records, raw/sidecar hashes and paths, every sample-count/status count, and—per configuration—minimum, median, mean, standard deviation, IQR, completed-trial count, and CPU/GPU median ratio. All selected `completed_trials` equal independently accepted measured counts.

## Median timing overview

Times are milliseconds. `S` is CPU median / GPU median: below 1 means the GPU was slower. This compact table reports medians; the linked selected JSON supplies the requested min/mean/standard-deviation/IQR for every CPU and GPU configuration.

| Case | n / nnz | Trials | SPAI CPU / GPU / S | fixed-P GMRES CPU / GPU / S | native pipeline CPU / GPU / S |
|---|---:|---:|---:|---:|---:|
| cage5 | 37 / 233 | 10 | 1.284 / 39.476 / 0.033 | 0.123 / 21.986 / 0.006 | 1.761 / 84.354 / 0.021 |
| gre_115 | 115 / 421 | 10 | 69.328 / 372.967 / 0.186 | 0.788 / 42.994 / 0.018 | 71.665 / 482.588 / 0.149 |
| saylr1 | 238 / 1128 | 10 | 148.951 / 1215.048 / 0.123 | 7.348 / 267.681 / 0.027 | 164.605 / 2622.721 / 0.063 |
| steam1 | 240 / 2248 | 10 | 28.473 / 522.238 / 0.055 | 0.955 / 48.454 / 0.020 | 30.990 / 633.618 / 0.049 |
| stencil_256 | 256 / 1216 | 10 | 8.967 / 174.321 / 0.051 | 1.638 / 42.263 / 0.039 | 11.938 / 246.765 / 0.048 |
| irregular_256 | 256 / 1236 | 10 | 3.454 / 100.277 / 0.034 | 1.671 / 42.760 / 0.039 | 8.103 / 186.023 / 0.044 |
| pores_3 | 532 / 3474 | 10 | 469.895 / 2076.720 / 0.226 | 26.284 / 381.169 / 0.069 | 509.532 / 2950.762 / 0.173 |
| stencil_1024 | 1024 / 4992 | 3 | 90.297 / 723.312 / 0.125 | 16.025 / 61.471 / 0.261 | 151.530 / 897.872 / 0.169 |
| irregular_1024 | 1024 / 4951 | 3 | 39.162 / 333.530 / 0.117 | 17.634 / 73.709 / 0.239 | 95.616 / 526.378 / 0.182 |
| sherman4 | 1104 / 3786 | 10 | 205.579 / 1754.243 / 0.117 | 48.567 / 396.017 / 0.123 | 352.807 / 1818.868 / 0.194 |
| orsreg_1 | 2205 / 14133 | 3 | 889.606 / 1982.392 / 0.449 | 167.875 / 567.885 / 0.296 | 1191.852 / 4047.939 / 0.294 |
| sherman5 | 3312 / 20793 | 3 | 2050.626 / 3822.936 / 0.536 | 369.539 / 1815.854 / 0.204 | 3314.054 / 9613.348 / 0.345 |
| add32 | 4960 / 19848 | 3 | 2452.112 / 3271.312 / 0.750 | 296.077 / 390.099 / 0.759 | 4972.667 / 5703.956 / 0.872 |

Every selected measured run reported construction/solver success and convergence. The selected sidecars retain independently recomputed residual and backward-error values; e.g., `add32` CPU native-pipeline median-class samples have Decimal80 backward errors around `8e-17`, below the frozen `10u` threshold. This is numerical acceptance evidence, not a claim of CPU/GPU bitwise equality: native construction can select distinct patterns on documented sensitive inputs.

GPU free-memory samples across selected GPU SPAI records ranged from 7,449,083,904 to 7,451,181,056 bytes; source-reported GPU-SPAI peak device allocation ranged from 409,760 to 5,275,736 bytes. These are run-local observations on this machine, exclude vendor-internal allocations, and are not scalability bounds.

## Figures

- [CPU versus GPU SPAI construction](results/stage45b_selected_aggregation_20261011/spai_construction_selected.svg)
- [CPU versus GPU fixed-P GMRES](results/stage45b_selected_aggregation_20261011/fixed_p_gmres_selected.svg)
- [CPU versus GPU native pipeline](results/stage45b_selected_aggregation_20261011/full_pipeline_selected.svg)
- [Native-pipeline CPU/GPU median ratio versus dimension](results/stage45b_selected_aggregation_20261011/full_pipeline_speedup_selected.svg)

The plots intentionally include every selected case and show GPU-slower ratios. They are suitable as exploratory figures for later manuscript work only after the CPU Release admission and final benchmark protocol are resolved.

## Interpretation and limits

On this balanced laptop configuration, public-call GPU overhead plus the current host-controlled GPU-SPAI/CPU-staged IR design dominates these small-to-medium workloads. The data does **not** identify a crossover, prove GPU scalability, isolate an optimized kernel cost, or establish an equal-work native pipeline comparison. It also does not profile component costs; profiling and optimization remain outside this authorized campaign.

The next authorized work, if any, should first resolve the incomplete CPU Release admission, then pre-register a stable power/clock policy and expanded workload tier before treating comparisons as final. BSPAI, mixed precision, algorithmic changes, and performance optimization remain unimplemented.
