# CUDA SPAI Preconditioner Final-Assembly Audit

## Scope

Read-only audit of the current source tree. This report traces the native CUDA
SPAI construction path through the point at which GPU GMRES receives its
preconditioner. It distinguishes the production binary64 path from the
experimental binary32 path.

## Finding

The native CUDA binary64 path does **not** numerically form `P = N^T D` on the
CPU. The CPU controls adaptive metadata, packs final sparse data, and creates
canonical host CSR objects. A CUDA kernel computes the packed numerical values
of `P`; those values are then downloaded, canonicalized on the CPU, and
uploaded into GPU GMRES.

## 1. Per-column SPAI coefficients

`cuda_construct_spai()` is the CUDA-SPAI constructor in
[`src/cuda_spai.cu`](src/cuda_spai.cu).

- GPU QR and application of `Q^T`: lines 241-244.
- GPU triangular solve, leaving the coefficient vector in `slot.rhs`: line
  252.
- Device-to-host copy of that coefficient vector to `fit.coefficients`: lines
  256-261.
- Publication into `result.columns[k].coefficients`: line 264.

Therefore, coefficients are numerically produced on the GPU and retained on
the host for the adaptive control flow and final packing.

## 2. Explicit N

There are two explicit representations of `N` after construction:

1. The host packs final patterns and downloaded coefficients into the
   column-oriented `packed_rows`, `coefficients`, and `packed_offsets` arrays
   in `src/cuda_spai.cu`, lines 290-292.
2. The host creates `result.inverse`, the canonical CSR `N`, from those packed
   coefficients in lines 301-303.

The device also holds a transient packed coefficient buffer, `packed_n`,
created and uploaded at lines 293-295. Creating host `result.inverse` is a CSR
representation/canonicalization step; it does not recompute the least-squares
coefficients.

## 3. Where P = N^T D is formed

The CUDA kernel `assemble_p` performs the numerical operation:

- The mapping and formula are explicit in `src/cuda_spai.cu`, lines 136-142:
  a packed CSC column `k` of `N` becomes CSR row `k` of `P`, with
  `P[k,j] = N[j,k] * d[j]`.
- The kernel is launched at lines 295-298.
- Its packed `P` output is copied device-to-host at line 299.
- The CPU then creates `result.preconditioner`, the canonical CSR `P`, at
  lines 301-303.

## 4. Final-assembly ownership

Final assembly spans both processors:

| Work | Owner |
|---|---|
| Pack final row/pattern metadata and fitted coefficients | CPU |
| Upload packed metadata and N coefficients | CPU to GPU |
| Compute packed P values, including multiplication by D | GPU |
| Download packed P values | GPU to CPU |
| Build canonical CSR N and P | CPU |

Thus, it is inaccurate to describe the CUDA path as “CPU assembles N; forms
P = N^T D.” The CPU assembles/canonicalizes host sparse representations, but
the GPU performs the numerical `P = N^T D` calculation.

`CsrMatrix::from_entries()` sorts entries, sums duplicates, and drops stored
zeros in [`src/cpu.cpp`](src/cpu.cpp), lines 48-76.

## 5. Host round trip before GMRES

Yes. The completed preconditioner is copied from device to host, then uploaded
again to GMRES:

1. `host_p` receives GPU-computed packed values at
   `src/cuda_spai.cu`, line 299.
2. Host code creates canonical `result.preconditioner` at lines 301-303.
3. `cuda_gpu_spai_gmres_ir()` passes that exact host CSR object to
   `cuda_refine_with_preconditioner()` in [`src/cuda_ir.cpp`](src/cuda_ir.cpp),
   lines 82-92.
4. The persistent binary64 `CudaGmresContext` uploads canonical CSR `A` and
   `P`; its `Matrix` constructor uploads offsets, indices, and values in
   [`src/cuda_gmres.cu`](src/cuda_gmres.cu), lines 121-146.

This is the normal production handoff, not a validation-only copy and not a
device-to-device ownership transfer.

## 6. Exact transfer sequence before first GMRES iteration

Assuming the CPU outer-initialization check does not already converge:

1. CUDA SPAI uploads original CSR offsets, indices, and values for scaling and
   sparse `B` construction (`src/cuda_spai.cu`, lines 185-191).
2. During each adaptive fit, CPU metadata is uploaded and coefficients,
   diagnostics, statuses, and—when needed—scores are downloaded (lines
   235-271).
3. Once construction completes, CPU packs final N data (lines 290-292).
4. CPU uploads packed row indices and N coefficients (lines 293-295).
5. GPU launches `assemble_p` (lines 297-298).
6. CPU downloads the assembly status and packed P values (line 299).
7. CPU creates canonical CSR N and P (lines 301-303).
8. `cuda_gpu_spai_gmres_ir()` supplies that P to the refinement wrapper
   (`src/cuda_ir.cpp`, lines 86-91).
9. `CudaGmresContext` initializes and uploads canonical CSR arrays for both A
   and P. For nonempty matrices this is six CSR-array host-to-device uploads
   (`src/cuda_gmres.cu`, lines 124-129 and 218-231).
10. CPU computes `x0 = P*b` and outer diagnostics
    (`src/cuda_ir.cpp`, lines 33-43). If correction is required, the first
    GMRES call uploads the CPU residual and an explicit zero initial correction
    (`src/cuda_gmres.cu`, lines 175-177), then begins Arnoldi at line 190.

## 7. Report-text verdict

### “CPU assembles N; forms P = N^T D”

**Inaccurate for native CUDA SPAI.** CPU packs and canonicalizes N/P, but GPU
computes the numerical packed P values.

### “Once all columns are complete, it forms P; GPU GMRES corrections are checked by the CPU outer-refinement loop.”

**Accurate only with location clarified.** The combined host/GPU pipeline forms
P: host packing, GPU numerical assembly, then host CSR canonicalization. The
CPU outer loop performs original-residual/backward-error checks and correction
updates; GPU GMRES separately recomputes and checks its preconditioned residual.

## 8. Pseudocode verdict

“After all columns finish, assemble N and form P” is mathematically correct,
but implementation-incomplete. It misleadingly suggests CPU numerical P
assembly if presented as a CUDA execution-path description.

## FP32 distinction

The experimental FP32 CUDA-SPAI constructor specializes the same implementation
body through inclusion of `cuda_spai.cu`; therefore it has the same host
packing, GPU packed-P assembly, GPU-to-host P download, and host
canonicalization behavior. See [`src/fp32_cuda_spai.cu`](src/fp32_cuda_spai.cu),
lines 44-72 and 101-144.

The GMRES handoff differs. FP32 does not use the persistent binary64
`CudaGmresContext`: each FP32 correction constructs `Matrix A` and `Matrix P`
and uploads their CSR arrays anew. See [`src/fp32_cuda_gmres.cu`](src/fp32_cuda_gmres.cu),
lines 26-33 and 49-55.

## Factual summary

CUDA SPAI computes every least-squares column on the GPU and downloads fitted
coefficients for host-controlled adaptive pattern decisions. After all columns
complete, the CPU packs final sparse N metadata and coefficients, uploads that
packed representation, and the GPU computes packed `P = N^T D`. Packed P values
are downloaded, after which CPU code constructs canonical CSR N and P. In the
native binary64 pipeline, canonical A and this same canonical P are uploaded
once into a persistent GPU GMRES context; CPU-staged iterative refinement then
performs outer diagnostics and applies GPU-GMRES corrections.

## Replacement Figure 1 text

**Box:**

> CUDA SPAI finalization: CPU packs final sparse N metadata and fitted
> coefficients; GPU computes packed P = N^T D; CPU canonicalizes sparse N and
> P, then uploads canonical P to GPU GMRES.

**Caption:**

> After GPU QR-based column construction, fitted coefficients are staged on the
> host for adaptive control and final packing. The GPU forms packed
> preconditioner values P = N^T D; the host canonicalizes the resulting sparse
> CSR matrices before the FP64 persistent GMRES context uploads A and P.
> Iterative-refinement diagnostics and correction updates remain CPU-staged.

## Replacement algorithm sentence

> After all columns finish, pack the final sparse N representation on the host,
> compute packed P = N^T D on the GPU, and canonicalize the resulting sparse N
> and P on the host before GMRES setup.
