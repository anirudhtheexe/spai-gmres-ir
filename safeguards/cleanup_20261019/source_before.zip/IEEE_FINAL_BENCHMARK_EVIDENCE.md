# PCAP IEEE final benchmark evidence

## Outcome

The fresh Stage-A-current CPU/GPU scalability campaign is complete and numerically accepted. It covers stencil and irregular systems at `n=1024, 2048, 4096, 8192, 12000`, in uniform FP64 and uniform FP32, for six explicitly separated scopes: CPU/GPU SPAI construction, CPU/GPU fixed-`P` GMRES, and CPU/GPU public SPAI--GMRES--IR pipeline.

The report package is [results/ieee_final_evidence_20261012](results/ieee_final_evidence_20261012). It retains raw source locations, all individual measurement values, derived CSV/JSON tables, saved-snapshot Decimal80 verdicts, reproducibility details, and vector SVG figures. No solver policy, CUDA algorithm, or benchmark input was changed for this work.

## Campaign protocol and acceptance

The FP64 series ran first, followed by FP32 only after the complete FP64 series had passed. Each precision contains 60 configurations: 10 immutable cases × 6 modes, each with three warm-ups and three measured host-wall-clock trials. That yields 120 accepted configurations, 360 reported measured trials, and 720 total saved samples including warm-ups. The root-lock-owning runner launched solver and checker children serially; the checker consumed only saved JSONL snapshots after each solver exited.

Validation independently audited both collections: every configuration has its raw artifact and Decimal80 sidecar; every solver and checker returned zero; every sample was successful and converged; and every sidecar accepted its three measured records with zero failures. Thus there are 360 accepted Decimal80 measured-record assessments. The frozen FP64 pipeline target is `1.11022302462516e-15`; its worst independently checked pipeline BE was `1.58926882420807e-16` (6.99× margin). The FP32 target is `5.96046447753906e-7`; worst pipeline BE was `7.55714389631574e-8` (7.89× margin). The corresponding maximum observed pipeline forward errors were `1.48916186954622e-16` (FP64) and `9.28645400691408e-8` (FP32).

Fixed-`P` GMRES is accepted against its preconditioned-residual condition, not the IR outer backward-error condition; its original-system BE must therefore not be compared with the pipeline target.

## Fresh FP64 result and scaling change

The fresh evidence corroborates a **family-dependent construction crossover/change in scaling**, not a universal GPU crossover. GPU SPAI is slower through 4k for both families. At 8k it is slightly faster for stencil (`1.065×` CPU/GPU) but still slower for irregular (`0.758×`); at 12k it is faster for both (`1.449×` stencil, `1.116×` irregular). GPU fixed-`P` GMRES remains slower at every tested size. Native-pipeline direction depends on family: GPU wins for FP64 stencil at 8k/12k (`1.161×`/`1.234×`), but remains slower for irregular at all points (12k `0.763×`).

| FP64 case | SPAI CPU / GPU ms | SPAI CPU/GPU | fixed GMRES CPU/GPU | pipeline CPU/GPU |
|---|---:|---:|---:|---:|
| stencil 8192 | 2187.741 / 2053.600 | 1.065× | 0.696× | 1.161× |
| irregular 8192 | 849.542 / 1120.641 | 0.758× | 0.668× | 0.851× |
| stencil 12000 | 4378.242 / 3020.985 | 1.449× | 0.736× | 1.234× |
| irregular 12000 | 1817.333 / 1628.220 | 1.116× | 0.784× | 0.763× |

All sizes and individual trial values are in [fresh_median_results.csv](results/ieee_final_evidence_20261012/summaries/fresh_median_results.csv) and [fresh_cpu_gpu_speedups.csv](results/ieee_final_evidence_20261012/summaries/fresh_cpu_gpu_speedups.csv). This resolves the historical ambiguity: the retained original FP64 data showed a trend but lacked a single fully comparable series because 2k--8k included preflight aborts and later continuations without all sidecars. The fresh controlled current series establishes the stated, bounded result.

## Fresh FP32 comparison

Uniform FP32 is faster in absolute CPU and GPU wall time than FP64 across the measured native pipelines, but its GPU implementation does **not** cross CPU through 12k for these cases. At 12k, CPU/GPU pipeline ratios are `0.863×` (stencil) and `0.914×` (irregular); the corresponding SPAI ratios are `0.871×` and `0.846×`. GPU fixed-`P` GMRES closes toward parity but remains slower (`0.871×`/`0.913×` at 12k). This is a performance observation under the frozen uniform-precision policies, not an equivalence claim between FP32 and FP64 iteration paths.

| FP32 case | SPAI CPU / GPU ms | SPAI CPU/GPU | fixed GMRES CPU/GPU | pipeline CPU/GPU |
|---|---:|---:|---:|---:|
| stencil 8192 | 1228.702 / 2063.094 | 0.596× | 0.862× | 0.634× |
| irregular 8192 | 656.042 / 1089.374 | 0.602× | 0.976× | 0.642× |
| stencil 12000 | 2621.653 / 3011.050 | 0.871× | 0.871× | 0.863× |
| irregular 12000 | 1410.285 / 1667.434 | 0.846× | 0.913× | 0.914× |

## Optimization evidence retained separately

The report chronology is: historical FP64 scaling → fresh controlled CPU/GPU recovery and FP32 extension → CUDA profiling → synchronization batching → Stage A transfer consolidation.

- Batching reduced retained `cudaStreamSynchronize` calls from `373,606` to `130,126` per comparable stencil-8192 trace, a `65.17%` reduction; async copies remained `276,008` and launches `357,658`.
- Stage A packed score/status/clamp transfers and reduced `cudaMemcpyAsync` calls from `276,008` to `243,748` per two-construction trace (`-32,260`, `-11.688%`); launches and synchronizations remained `357,658` and `130,126`. It also reduced `cudaMalloc/cudaFree` counts from `1,136/1,184` to `924/972`.
- These count reductions are valid. The retained Stage-A wall-clock results are mixed, particularly FP64 pipeline regressions, so Stage A is not credited with a uniform end-to-end speedup. The full source and values are [EXPERIMENT2A_GPU_SPAI_STAGE_A.md](EXPERIMENT2A_GPU_SPAI_STAGE_A.md).

## Evidence map

- Historical classification and limits: [HISTORICAL_BENCHMARK_INVENTORY.md](results/ieee_final_evidence_20261012/inventory/HISTORICAL_BENCHMARK_INVENTORY.md).
- Fresh raw samples: [fresh_all_samples.csv](results/ieee_final_evidence_20261012/raw/fresh_all_samples.csv).
- Fresh medians and diagnostics: [fresh_median_results.csv](results/ieee_final_evidence_20261012/summaries/fresh_median_results.csv).
- CPU/GPU speedups: [fresh_cpu_gpu_speedups.csv](results/ieee_final_evidence_20261012/summaries/fresh_cpu_gpu_speedups.csv).
- Snapshot verification: [decimal80_snapshot_validation.csv](results/ieee_final_evidence_20261012/validation/decimal80_snapshot_validation.csv).
- Exact commands, inputs, versions and limits: [REPRODUCIBILITY_MANIFEST.md](results/ieee_final_evidence_20261012/manifests/REPRODUCIBILITY_MANIFEST.md).
- Figures: [FP64 CPU/GPU time](results/ieee_final_evidence_20261012/figures/fp64_cpu_gpu_time.svg), [FP64 speedup](results/ieee_final_evidence_20261012/figures/fp64_speedup.svg), [FP32 vs FP64](results/ieee_final_evidence_20261012/figures/fp32_fp64_pipeline.svg), [CUDA API calls](results/ieee_final_evidence_20261012/figures/cuda_api_counts.svg), and [Stage-A wall time](results/ieee_final_evidence_20261012/figures/stage_a_walltime.svg).

## Limits and next state

This package is report evidence, not a publication-quality statistical performance claim beyond its stated machine/protocol. Native pipeline comparisons are public API comparisons and can have unequal internal iteration/construction work. The existing MSVC CPU Release wider-oracle limitation remains documented in the historical record, so older timing evidence stays explicitly exploratory. The new series is fully snapshot-validated but does not erase historical qualifications.

No further optimization, BSPAI, mixed-precision implementation, solver change, benchmark, or profiling run was started after this evidence package was generated.

