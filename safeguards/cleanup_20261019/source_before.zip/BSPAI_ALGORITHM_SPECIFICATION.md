# Published BSPAI–GMRES–IR reconstruction

Research date: 13 October 2026. Documentation only; no implementation, solver,
benchmark, or numerical validation was executed. This specification identifies
verified mathematical requirements and explicitly incomplete source equivalence.
It does not amend the frozen uniform FP64/FP32 contracts.

## Sources and authority

- **K25**: Khan–Carson, *Mixed precision iterative refinement with adaptive
  precision sparse approximate inverse preconditioning*, Engineering with
  Computers 41, 3833–3846 (2025), [published full text](https://link.springer.com/article/10.1007/s00366-025-02187-z),
  [PDF](https://link.springer.com/content/pdf/10.1007/s00366-025-02187-z.pdf).
  Full HTML prose/equations and extracted PDF text were inspected. Algorithms
  are images in the publisher HTML and absent from extracted PDF text.
- **Kpre**: [arXiv:2307.03914v1 HTML](https://arxiv.org/html/2307.03914v1).
  Full text and machine-readable Algorithms 2.1–3.1 were inspected. Use this
  source explicitly for algorithm lines not visually recovered from K25.
  Its rendered title reports a 2026 version date despite the v1 identifier;
  do not silently treat that rendering as immutable 2023 source bytes.
- **C23**: Carson–Khan, DOI [10.1137/22M1487709](https://doi.org/10.1137/22M1487709),
  [arXiv:2202.10204v2 full text](https://arxiv.org/html/2202.10204v2),
  especially SPAI construction, Algorithm 3 and §4.
- **G23**: Graillat–Jézéquel–Mary–Molina, author manuscript dated 12 May 2023,
  [full PDF](https://perso.lip6.fr/Theo.Mary/doc/adaptSpMV.pdf), §§2–3,
  Algorithm 3.1, Theorem 3.1, Remarks 3.1–3.2. Published as DOI
  [10.1137/22M1522619](https://doi.org/10.1137/22M1522619) in 2024.
  This manuscript is not asserted byte-equivalent to the publisher version.
- **M23**: [official uniform SPAI MATLAB code](https://github.com/Noaman67khan/SPAI-GMRES-IR/tree/b25e6f7c1cf1c3035686e9adb5ef9f35e2256ae1).
  Pin independently reverified through GitHub API on the research date.
  The official adaptive repository is unavailable; see the inventory.

## SPAI construction and orientation

K25 §2.2, (2.1)–(2.2), minimizes `||I-AM||_F²` by independent
column least-squares problems `min ||e_k-A*m_k||_2²`. Given pattern `J_k`,
the shadow `I_k` includes rows with a nonzero in `A(:,J_k)`. Fit
`A(I_k,J_k)*m_k(J_k)` to `e_k(I_k)` by QR. Construction tolerance
`varepsilon`, pattern-growth budget `alpha`, and growth width `beta` are
distinct from the later bucketing tolerance `epsilon_b`.

Kpre Algorithm 2.1 starts each column from the supplied pattern, performs
QR fits, evaluates the restricted residual, and grows candidate indices from
rows `I_k union {k}`, excluding indices already in `J_k` as specified in
the accompanying prose. Its candidate score is

`rho_jk = sqrt(||s_k||_2² - (s_k^T*A(I_k,j))² / ||A(I_k,j)||_2²)`.

Use the restricted denominator, not the full column. Up to `beta` candidates
whose score is at most the candidate mean are added, selecting smallest
scores. Kpre prints an inclusive `0:alpha` fit loop and a strict residual
test. The pinned `spai_dd.m` instead uses `1:alpha`, an unconditional
absolute value in the square root, and can attempt to select more candidates
than remain. The frozen project deliberately resolves these differences in
[PHASE2A_ALGORITHM_SPEC.md](docs/PHASE2A_ALGORITHM_SPEC.md). These are
documented finite-precision differences, not evidence of exact MATLAB parity.

For the experiments, K25 §4 and C23 §4 scale the transpose before construction.
Write `d_i=1/max_j|A_ij|`, `D=diag(d)`, `B=A^T D`, fit `N` as a right
approximate inverse of `B`, and assemble the final left preconditioner
`P=N^T D`. Then `(B*N)^T=P*A`. K25 uses `M` for this final left
preconditioner; this specification uses `P` to avoid its overwritten notation.
The identity pattern and nonzero diagonals are experimental assumptions;
`beta=8` is stated in K25. C23 §4 states `alpha=ceil(n/beta)`; K25's
experiment prose does not independently fix that budget. Preserve this distinction.

## Bucket representation and exact classification

Bucket the **final scaled left preconditioner P**, after ordinary SPAI
construction. K25 §§3,5 identify bucketing as a subsequent operation on M;
the normwise partition comes from §2.3, (2.4). This is an inference joining
the experiment's scaled construction with the stated post-construction rule,
not verified adaptive-source execution order.

Let `S=||P||_infinity=max_i sum_j |P_ij|` and
`u_1 < u_2 < ... < u_q`, where smaller unit roundoff means higher precision.
K25 §2.1 and G23 §2 explicitly define the unsubscripted norm as infinity.
Set `T_k=epsilon_b*S/u_k` for `k=2..q`, with `epsilon_b>=u_1`.
For each original nonzero in row i:

| Bucket | Exact magnitude interval | Arithmetic/storage |
|---|---|---|
| 1 | `|P_ij| > T_2` | highest precision `u_1` |
| k, `2<=k<q` | `T_(k+1) < |P_ij| <= T_k` | precision `u_k` |
| q | `0 <= |P_ij| <= T_q` | precision `u_q`, or dropping when `u_q=1` |

Equality belongs to the lower-precision side of each boundary. Sign does not
affect membership. The matrix norm is global, not a per-row maximum or
`max_ij|P_ij|`. The row sets `B_ik` partition existing nonzeros; explicit
zeros need not be stored. Classification uses the unconverted P values;
rounding an entry into its assigned storage format is subsequent to
classification (G23 Algorithm 3.1 and (3.1)). Do not recalculate the norm
from rounded/dropped entries or reclassify after conversion.

The selected normwise scheme has no dependence on the incoming vector.
G23 (3.9)–(3.10) describes a different componentwise scheme dependent on
`|P_ij*v_j|`; K25 explicitly excludes that choice for practical reuse.

K25 §4 uses four buckets for double working precision:
`(binary64,binary32,binary16,drop)` with
`(u_1,u_2,u_3,u_4)=(2^-53,2^-24,2^-11,1)`.
For single working precision it uses three:
`(binary32,binary16,drop)` with `(2^-24,2^-11,1)`.
The sentinel `1` is a relative perturbation model for replacing a value by
zero, not an IEEE arithmetic format. K25's prose `u_1=1` is inconsistent
with its own ordered list; G23 Remark 3.2 expressly specifies `u_q=1`.
Quadruple (`u=2^-113`) is used for residuals, not a bucket in these experiments.
Bfloat16 is background discussion, not a tested substitution for binary16.

Conceptually, store one disjoint sparse matrix per surviving format, with
`P^(k)_ij=round_uk(P_ij)` on its row sets and zero elsewhere. Reconstruction
is the highest-precision sum of those matrices, omitting the drop set.
No residual correction matrix, exponent scale, or decomposed-value encoding
is specified. CSR/CSC layouts, index widths, aligned buffers, and ownership
are CUDA engineering decisions; the publication does not mandate them.

## Application and rounding sequence

K25 Algorithm 2.3 (recovered through Kpre), and independently G23 Algorithm
3.1 and (3.1)–(3.4), specify rowwise partial dot products, followed by a
highest-precision sum. G23's `(1+u_k)^2` term accounts for conversion of
**both matrix entries and vector operands** to `u_k`.

```text
classify canonical P once using S and exact interval endpoints
store each surviving entry in its assigned format
apply(v):
  for each row i:
    for each surviving bucket k:
      partial[k] = 0 in format k
      for j in B[i,k] in a recorded traversal order:
        vk = round_k(v[j])
        product = round_k(stored_P[k,i,j] * vk)
        partial[k] = round_k(partial[k] + product)
    z[i] = sum of widened partial[k] in format 1
  return z
```

This pseudocode chooses separate rounded multiplication/addition as a
reproducible realization of the published dot-product step. The papers do
not fix fused versus unfused instructions or a parallel reduction tree;
those must be recorded and independently tested rather than claimed bitwise
author-source parity. Widening an IEEE lower-format partial to the nested
higher format is exact when finite and representable (G23 (3.3) commentary).

There are distinct mathematical partial products, but no requirement for
separate GPU launches or full intermediate output vectors. A fused kernel
can implement the same required formats; several sparse-library calls may
implement them only if their arithmetic/accumulation contracts match.
FP16 storage with FP32 products/accumulation is the separate scenario of
G23 Remark 3.1, not the baseline above. In general
`apply(v) != round_1(P*v)` and can also differ from applying the reconstructed
matrix uniformly in `u_1`, because operands and partial sums are rounded
within each bucket. Consequently, operator application is a floating-point
procedure, not a single exact linear map independent of v.

## GMRES and refinement precision contract

Kpre Algorithm 3.1 lines 3–8 explicitly supplies the following roles;
C23 Algorithm 3 supplies the same initial/residual/update roles.

| Operation | Precision |
|---|---|
| SPAI QR fitting and construction | `u_f` |
| Initial solution `x0=P*b` | uniform `u_f`, then store in `u` |
| Original residual `r=b-A*x` | `u_r`, then store in `u` |
| GMRES MGS and other working arithmetic | `u_g` |
| GMRES `A*v` | uniform `u_p` |
| GMRES preconditioning of `A*v` and correction RHS | bucket `u_k`; final sum `u_1` |
| Returned correction | store in `u` |
| Outer update `x=x+d` | `u` |

Initialization precedes bucketed GMRES and is explicitly uniform in `u_f`.
Retaining access to canonical P is therefore needed for that interpretation;
automatically using bucket application for initialization changes this step.
The pseudocode does not expressly show a call to construct buckets; §§2.3,3,5
provide the partition/application requirement. Exact lifecycle in adaptive
source remains unavailable.

At each refinement step, solve `P*A*d=P*r` with left-preconditioned GMRES,
applying A then P as separate operators. K25 §4 sets `u_g=u_p=u`,
unrestarted GMRES, and `tau=1e-8` (double) or `1e-4` (single).
Do not assemble a rounded `P*A` to replace this arithmetic sequence.

The printed outer algorithm has an iteration cap but no executable outer
stopping test, happy-breakdown branch, singular-P certificate, or nonfinite
recovery rule. Published experiments discuss forward/backward errors at
working accuracy. The unavailable adaptive driver prevents exact stopping
reconstruction. Uniform M23 source is supporting evidence only: it normalizes
the residual by its infinity norm before GMRES, uses zero correction guesses,
rescales correction afterward, stops on the maximum of forward/normwise/
componentwise errors at MATLAB `eps`, and replaces an infinite initial guess
with zero. Its GMRES normalizes by the initial preconditioned residual and
accepts the projected estimate. Those rules do not establish adaptive behavior.
The project's `10*u` outer test, no initial fallback, and recomputed inner
criterion remain project choices documented in the frozen contract.

## Error bounds, assumptions, and discrepancies

G23 Theorem 3.1, (3.12), and (3.16)–(3.17) give the normwise SpMV bound

`||z-P*v||∞/(||P||∞*||v||∞) <= (q-1)*u_1 + c_G*epsilon_b`,

where `c_G=(1+(q-1)*u_1)*max_i sum_k p_ik²*(1+u_k)²`,
and `p_ik=|B_ik|`. This is an order bound with a sparsity-dependent constant,
not a promise of error at most exactly `epsilon_b`.
K25 (2.6) prints **addition** before the maximum rather than G23's
**multiplication**; K25 (2.3) also prints `||y||*||x||` in the denominator
instead of G23 (2.4)'s `||P||*||v||`. Preserve these source discrepancies;
use the underlying derivation for an independently worked oracle, and do
not attribute the corrected formulas verbatim to K25.

K25 (3.5) bounds correction-system backward error by
`f(n,k)*(u_g + (q*u_p+(q-1)*u_1+c*epsilon_b)*kappa∞(P))`,
with `f(n,k)=k*n²`; (3.6) multiplies this by `kappa∞(P*A)` for correction
forward error. These rely on the preceding MGS-GMRES stability condition
involving the smallest singular value of `P*A`, dimension-dependent terms,
and nonsingularity. The stated comparison `u_1≈epsilon_b≈u_p` is conditional,
not a universal convergence/iteration guarantee. K25's first-order product
expansion is `P*DeltaA+DeltaP*A`; its following `f_j` line prints a different
order/perturbation symbol. Do not implement those typographical lines as
algorithmic operations. Bucketing A also is analyzed in (3.7)–(3.8), but is
not the primary experimental baseline.

G23 §2 assumes a standard relative rounding model. Its interval analysis
assumes sufficiently accurate threshold computation (§3, p.5). The inspected
sources do not give a native-CUDA policy for underflow, overflow, signed zero,
flush-to-zero, or FP16 vector conversion. Smaller entries do not imply that
the corresponding vector operands fit FP16. Example derived here:
`P=diag(1,2^-42)`, double configuration with `epsilon_b=2^-53`, has `S=1`
and places `2^-42` in the half bucket at its upper boundary. Binary16's
smallest subnormal is `2^-24`, so that value rounds to zero. The standard
relative conversion model does not cover this event. Silent promotion,
rescaling, dropping beyond the sentinel bucket, or FTZ are changed policies
until investigated and recorded; no source-backed choice is asserted here.

## Mandatory facts versus project engineering

Mandatory for a claimed reconstruction: final-P normwise buckets and endpoints;
separate construction/bucket tolerances; assigned-format operand conversion
and partial arithmetic; highest-format combining; uniform initial solve in
`u_f`; original residual in `u_r`; stated GMRES precision roles and ordering;
explicit source/version/provenance and publication discrepancies.

Engineering choices needing a future written validation decision: CSR layout,
parallel row/reduction scheduling, FMA policy, range guards, failure/status
API, threshold evaluation precision, allocator/stream ownership, and how a
shared uniform/bucketed application interface exposes the initialization path.
No production changes or optimization recommendation is made by this record.

## Unverified / Needs Full-Text / Needs Reproduction

Published algorithm images still need direct visual comparison against Kpre.
Adaptive author code, driver parameters, license and immutable commit are
unavailable. Published exact outer test/caps, alpha, rounding order, FP16
range policy, storage accounting and stopping histories remain unverified.
The 2024 final Graillat paper must be compared with G23 before claiming
publication-version equivalence. No published experiment, CUDA arithmetic
semantics, or theoretical assumption has been independently reproduced here.
