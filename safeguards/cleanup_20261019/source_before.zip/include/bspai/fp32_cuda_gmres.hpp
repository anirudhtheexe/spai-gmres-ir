#ifndef BSPAI_FP32_CUDA_GMRES_HPP
#define BSPAI_FP32_CUDA_GMRES_HPP
#include "bspai/fp32.hpp"
namespace bspai {
// Uniform-FP32 GPU-resident Arnoldi/vector path. Matrices and Krylov vectors
// stay on device for one solve; only scalar Hessenberg data is observed on host.
Fp32GmresResult fp32_cuda_left_preconditioned_gmres(const Fp32CsrMatrix&, const Fp32CsrMatrix&,
    const std::vector<float>&, const Fp32GmresOptions&, const std::vector<float>& initial_guess={}, int device=0);
// CPU-staged uniform-FP32 outer refinement reusing the GPU-resident inner
// GMRES above.  P is supplied explicitly; no GPU SPAI construction is implied.
Fp32IrResult fp32_cuda_refine_with_preconditioner(const Fp32CsrMatrix&, const Fp32CsrMatrix&,
    const std::vector<float>&, const Fp32IrOptions&, int device=0);
}
#endif
