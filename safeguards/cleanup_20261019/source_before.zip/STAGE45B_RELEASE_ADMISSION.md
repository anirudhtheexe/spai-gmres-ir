# Stage 4.5B Release numerical admission

**Date:** 11 October 2026  
**Status:** CUDA Release admitted; CPU Release remains incomplete for fair benchmark reporting. No benchmark was run.

## Original limitation

MSVC 19.44 Release builds with `/O2 /Ob2 /DNDEBUG /fp:strict`, but has binary64-compatible 53-bit `long double`. The original CPU tests deliberately retain wider-oracle availability checks at `tests/test_spai.cpp:138`, `tests/test_gmres.cpp:137`, and `tests/test_ir.cpp:108`. CPU Release CTest was 1/4: `cpu_core_tests` passed; the other suites each failed only that required availability assertion after completing their diagnostics. Those original assertions were not changed.

## Replacement-oracle evidence

The test-only `cpu_release_snapshot` target uses `tests/release_cpu_snapshot.cpp`. Its schema-2 records include finite binary64 values as C99 hexadecimal strings and raw IEEE payloads. `tests/check_release_cpu_decimal.py` first verifies payload round trips, then independently reconstructs selected SPAI QR/scaling/residual/selection/P assembly, GMRES Arnoldi/Hessenberg and true residuals, and IR diagnostics/correction/update histories with Decimal80. It passed **16 snapshots, 500 checks, zero failures**.

The coverage includes direct and near-dependent SPAI construction; finite GMRES and IR correction histories; selected zero/exact/cap/epsilon/beta/rank/range status cases; and IR iteration-limit no-update behavior. It does not change production numerical code, tolerances, precision, stopping criteria, or benchmark inputs.

## Release executions

| Check | Result |
|---|---|
| CPU Release CTest | 1/4, with the three unchanged wider-oracle availability failures described above. |
| CPU Decimal80 snapshot assessor | 16 snapshots, 500 checks, 0 failures. |
| CUDA Release CTest | 5/5 passed. |
| CUDA Release Decimal GMRES | 48 solver snapshots, 125 norm fixtures, 383 checks, 0 failures. |
| CUDA Release Decimal sparse-SPAI / IR | Existing release execution completed; IR: 3 snapshots, 208 checks, 0 failures. |

CUDA used the documented CUDA 13.4/MSVC Release environment and `CUBLAS_EMULATE_DOUBLE_PRECISION=0`. These are correctness executions, not timing measurements.

## Remaining limitations and decision

The CPU snapshot is not a fixture-for-fixture replacement for every historical wider-long-double branch. Missing finite snapshot coverage includes some GMRES zero-preconditioned, happy/unhappy breakdown, nonzero-initial-guess and estimate-gap paths, and IR cap/stagnation/construction-failure/diagnostic-overflow/outer-ULP paths. Existing CPU tests still execute their operational assertions, but lack a wider built-in oracle on MSVC.

Therefore, **CUDA Release is ready for the later benchmark gate; CPU Release is not yet fully admitted for CPU/GPU benchmark comparison.** No Stage 4.5B timing, profiling, BSPAI, mixed precision, or optimization is authorized by this record.
