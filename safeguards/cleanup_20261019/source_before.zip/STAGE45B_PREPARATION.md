# Stage 4.5B preparation checkpoint

**Date:** 11 October 2026  
**Status:** blocked before benchmark timing; no benchmark or profile sample was collected.

## Preserved baseline

The accepted Stage 4.5A state was committed on `stage4-scalable-spai` as `8eac10eec719bf24d55e219884d7a35bcd25aaaa` with message `Validated Stage 4.5A numerical baseline`. Annotated tag `stage45a-validated-baseline` peels to the same commit. The earlier `gate3-working-baseline` tag remains at `581e75e66e45d8d2e789d9898d3ef2987c66b509`.

The Stage 4.5A reports, provenance directories, and 22 extension raw JSONL artifacts were present before checkpoint creation. No validated evidence was discarded. Stage 4.5B remains on the existing `stage4-scalable-spai` branch.

## Fresh Release builds

Fresh ignored build directories were used; existing Debug trees were not reused.

| Build | Directory | Toolchain/configuration | Result |
|---|---|---|---|
| CPU Release | `build/cpu-release-ninja` | MSVC 19.44.35228, Ninja, `/O2 /Ob2 /DNDEBUG /fp:strict`, `BUILD_TESTING=ON` | Builds successfully; CTest admission fails as described below. |
| CUDA Release | `build/cuda-release-ninja` | MSVC 19.44.35228, nvcc/CUDA 13.4.59, architecture 89, `/O2 /Ob2 /DNDEBUG /fp:strict`, custom CUDA arithmetic `--fmad=false`, `CUBLAS_EMULATE_DOUBLE_PRECISION=0`, `BUILD_TESTING=ON` | Builds successfully; CTest 5/5 passes. |

The initial CUDA configuration attempt failed before project compilation because command-shell expansion hid `cl.exe` from `nvcc`; only the incomplete ignored Release build directory was removed and recreated. The successful build used the `vcvars64.bat` environment unchanged. CUDA header deprecation and nvcc-generated stub warnings were emitted but did not fail the build.

## Release numerical admission

CUDA Release CTest passed all five suites: `cuda_spai_tests`, `cuda_spai_sparse_tests`, `cuda_ir_tests`, `cuda_gmres_tests`, and `cuda_spmv_tests`.

CPU Release CTest ran all four suites. `cpu_core_tests` passed, while `spai_tests`, `gmres_tests`, and `ir_tests` each report exactly one failure: `wider reference mantissa available` / `wider oracle available`. The printed numerical diagnostics otherwise completed. This is a toolchain limitation: MSVC uses binary64-compatible `long double` on this target, whereas the CPU validation tests require a wider built-in oracle. It is not evidence that the frozen solver tolerances or algorithms changed, but it prevents the MSVC CPU Release configuration from satisfying the project’s full Release numerical-admission gate.

No timing, warm-up, repetition, profiler run, solver benchmark, tolerance change, fallback, BSPAI, mixed precision, or performance interpretation occurred.

## Required gate before benchmark campaign

Before Stage 4.5B timing may start, select and validate a CPU Release toolchain that provides the required independent wider oracle, or separately approve and validate a replacement independent CPU oracle. Then:

1. rerun CPU Release CTest 4/4 and CUDA Release CTest 5/5;
2. run the retained Decimal/CLI numerical-oracle scripts against the accepted Release executables;
3. re-screen every proposed benchmark configuration with retained input/RHS/P/build hashes and independent Decimal assessment;
4. add fixed-`P` Release validation for every CPU/GPU solve comparison, while keeping native pipelines separate; and
5. predeclare API boundaries, warm-ups, trial counts, watchdog/budget, matrix subset, raw JSONL paths, and environment/power/clock metadata.

No speedup, scalability, equal-work, CPU/GPU equivalence, or profile claim is authorized by this checkpoint.
