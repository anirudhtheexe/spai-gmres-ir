# Standalone BSPAI numerical reproduction plan

13 October 2026. A plan only; none of these tests, solvers, or experiments
were run. The scope requested here ends at research/specification.
Use [the specification](BSPAI_ALGORITHM_SPECIFICATION.md) and
[the source inventory](BSPAI_LITERATURE_AND_CODE.md) together.

## Acceptance stages and isolation

1. Preserve the complete active project and verify destination SHA-256 values
   before implementation, according to the current preservation record.
   Keep solver sources, tolerance contracts and historical evidence frozen.
2. Reconstruct buckets from a fixed serialized canonical P. Validate membership,
   payload conversion and independent application; no GMRES/IR integration.
3. Validate all rounding roles against an independent exact-rational or
   arbitrary-precision oracle. Compare reconstructed-P uniform application
   separately from assigned-precision partial products.
4. Only after documented standalone acceptance and separate implementation
   authorization, test fixed-P GMRES and then refinement with the specified
   initial-solve, residual and update roles. Do not infer that passing storage
   tests certifies mixed-precision GMRES.
5. Recover author code/settings before claiming exact table reproduction.
   Compare a source-faithful experiment separately from project-policy variants.

Each stage must retain raw inputs, exact payloads, independently checked errors,
failure diagnostics and an immutable manifest. Performance measurement requires
a later authorized methodology, serialized campaigns, and whole-application
costs as well as standalone kernels.

## Independent hand-worked examples

These examples are derived from the verified intervals; they are not published
test cases. Powers of two make expected results independently checkable.

### A. Three buckets, exact endpoint ownership and dropping

`P=diag(1,2^-13,2^-24)`, `v=(1,1,1)`,
`u=(2^-24,2^-11,1)`, `epsilon_b=2^-24`.
The infinity norm is exactly 1; thresholds are `T_2=2^-13`, `T_3=2^-24`.
Entry 1 goes to single; entry `2^-13` goes to half by upper-endpoint
inclusion; entry `2^-24` is dropped by lower-endpoint inclusion.
Expected payload-preserving reconstruction is `diag(1,2^-13,0)` and
expected application is `(1,2^-13,0)` exactly. The normwise application
error relative to original P is exactly `2^-24` because `||v||∞=1`.
Replacing any entry by its negative preserves membership and negates its
contribution. Explicit structural zeros add no stored entries.

At `T_2`, test the boundary and its immediate original-format neighbours:
below belongs to half; equal belongs to half; above belongs to single.
At `T_3`, below/equal belong to drop; above belongs to half. An above-boundary
value may round onto the boundary in its storage format without changing
its pre-conversion membership. Preserve that original classification.

### B. Global matrix norm, not maximum entry or row-local norm

`P=[[1,1],[0,2^-12]]`, same three formats and epsilon as A.
`S=2`, so `T_2=2^-12`, `T_3=2^-23`.
Both row-1 entries are single; row-2's `2^-12` is half, exactly at `T_2`.
For `v=(1,1)`, expected result is `(2,2^-12)` exactly.
Using max-entry norm 1 would misclassify the last entry as single.
Changing the vector to `(2,-3)` must preserve all bucket indices while
changing the exact output to `(-1,-3*2^-12)`.

### C. Partial arithmetic is different from widened arithmetic

Use `P=[[1,0,0],[0,2^-14,2^-14],[0,0,1]]`,
`S=1`, `epsilon_b=2^-24`, three formats as A. Row 2 has two half entries.
Take `v=(0,1+2^-11,1+2^-11)` represented exactly in single precision.
Under IEEE round-to-nearest ties-to-even, each half vector operand rounds
to 1: `1+2^-11` is the midpoint between half values 1 and `1+2^-10`.
Both half products are `2^-14`, and their half sum is `2^-13` exactly.
Expected bucketed row-2 output is `2^-13`.
Using unconverted vector operands and single accumulation gives
`2^-13+2^-24` exactly instead. This test rejects a storage-only emulation
of the published arithmetic. Record fused/unfused policy separately.

### D. Half-range discrepancy, not a hidden success fixture

Double-working buckets `(2^-53,2^-24,2^-11,1)`, `epsilon_b=2^-53`,
`P=diag(1,2^-42)`, `v=(1,1)` give `S=1` and
`T_2=2^-29`, `T_3=2^-42`, `T_4=2^-53`.
Thus `2^-42` belongs to half. IEEE binary16 rounds it to zero because
the minimum subnormal is `2^-24`. Expected native-half reconstructed output
is `(1,0)`, whereas uniform-double output is `(1,2^-42)`.
This discrepancy is a range-policy investigation: the standard relative
conversion assumption fails. Do not hide it with a tolerance, promote it,
or relabel it as sentinel dropping without a documented policy decision.
Likewise test `P=diag(1,2^-13)` in the single configuration with
`v=(1,65536)`: the half vector operand overflows binary16 although the
exact second output is only 8. Magnitude-based matrix bucketing alone does
not guarantee safe vector conversion.

### E. Construction and initialization components

For `A=diag(2,4)`, exact row scaling yields `D=diag(1/2,1/4)`,
`B=A^T D=I`, identity-pattern QR gives `N=I`, and `P=diag(1/2,1/4)`.
For `b=(2,8)`, the uniform initial solution is `(1,2)` exactly and the
original residual is zero. This verifies orientation and initial precision
independently of bucket classification. Also retain a nontrivial case where
uniform `u_f` initialization differs from bucket initialization; compare
both against their distinct contracts rather than requiring equality.

## Numerical oracle and invariants

Use exact rational arithmetic for dyadic input/payload decoding and a separately
implemented correctly rounded binary16/binary32/binary64 emulator for every
operand conversion, multiplication, addition, widening and combining step.
Use at least 80 decimal digits for non-dyadic residual and norm diagnostics,
raising precision until reported comparisons stabilize. Hardware float/double
alone cannot be the independent oracle for their own arithmetic.

Required invariants: unique original nonzero ownership; disjoint row sets;
union equals original support including a recorded drop set; assigned payload
equals correctly rounded original value; immutable canonical P/norm/tolerances;
identical classification for different v; valid index ordering/dimensions;
same rounding mode and recorded traversal order; finite output or named range
failure. Keep dropped counts distinct from entries that become zero through
underflow. No silent fallback or mixed accumulator substitution is accepted.

Assess `eta_spmv=||z-P*v||∞/(||P||∞*||v||∞)` against the G23 Theorem 3.1
constant only on fixtures satisfying its rounding-model assumptions. Do not
use K25's printed denominator typo. For zero vector/matrix, define exact-zero
diagnostics explicitly; otherwise a zero denominator is a separate case.
Report componentwise errors too, without claiming the selected normwise
partition bounds them at the target. Track p_ik and calculate the bound
independently; no tolerance tuning based on observed failures.

Edge coverage includes empty rows/buckets, all drop, no drop, q=2 partition,
negative entries, exact endpoints, duplicate input rejection/canonicalization,
signed zeros, minimum normals/subnormals, cancellation, large finite inputs,
nonfinite rejection, overflow in norm/threshold/intermediate computation,
threshold rounding near equality and very uneven row lengths. The published
experiment includes at least two actual arithmetic formats plus dropping;
other q/layout choices must be labelled extensions.

## Minimal published reproduction experiments

Start with **cage5**, SuiteSparse 37x37/233, published Table 4:
single/single/double, varepsilon=.1, beta=8, equal-unit2 RHS,
unrestarted GMRES tau=1e-4, epsilon_b in `{2^-24,2^-18}`.
Published constructed P has 511 entries; bucket counts are `(504,7,0)`
and `(271,239,1)`; both adaptive cases and SPAI total 8 GMRES iterations
with per-refinement `(4,4)`. These are reproduction targets only after
matching source settings and stopping, not acceptance requirements for the
frozen project constructor or standalone fixed-P tests.

Then **steam1**, 240x240/2248, Table 3:
double/double/quad, varepsilon=.1, beta=8, tau=1e-8,
epsilon_b in `{2^-53,2^-37}`. Published P count 1105 and bucket counts
`(556,537,12,0)` and `(242,284,347,232)`; adaptive iterations `21=(7,7,7)`
versus uniform `14=(7,7)`. Include the unfavourable single/single/double
steam1 case (Table 4, 244 versus 8 iterations) so reproduction does not
select only favourable examples. Resolve all source precision/range/stop
questions before interpreting disagreement.

Retain raw and rounded A, RHS, D, canonical P, all payloads, bucket counts,
conversion losses, inner histories, correction norms, original residuals,
normwise/componentwise backward error and independently computed forward
error. Separate same-P comparisons from native-construction comparisons.
Verify SuiteSparse group/ID, file hash, exact precision of loading/scaling,
alpha semantics, author stopping and every tool dependency version. Use
quadruple residuals or a documented accurate emulation for the double
publication setup; uniform FP64 residuals do not reproduce it.

## Reproducibility and completion criteria

Manifest each matrix/source SHA-256; repo commit/license; manuscript version;
precision unit roundoffs, exponent ranges, subnormal/FTZ/FMA settings; norm and
threshold evaluation method; bucket endpoints; constructor epsilon/alpha/beta;
GMRES restart/cap/tolerance and normalization; outer test/cap; compiler/library/
hardware versions; commands; exact seed (or deterministic/no randomness);
oracle precision; raw outcomes and all failed cases. Actual storage includes
values, indices, offsets, metadata and workspace. Published percentage estimates
must remain separate from measured CUDA allocations and runtime.

Standalone completion means exact bucket/payload checks and independent
application comparisons pass on the supported-range fixtures, all range cases
are explicitly classified, and unresolved semantics have written decisions.
End-to-end publication reproduction remains incomplete until missing author
settings/code or adequate authoritative clarification is obtained. This plan
does not authorize executing its stages.

## Unverified / Needs Full-Text / Needs Reproduction

No standalone or publication reproduction was performed. Native CUDA format
semantics, overflow/underflow handling, exact adaptive outer/inner stopping,
alpha, matrix spelling/provenance, immutable author source and published
algorithm images remain prerequisites described in the companion documents.
